package src

import (
	"fmt"
	"log"

	"Martian/src/config"
	"Martian/src/ssh"
)

// Startup creates the entire environment ready
func Startup(sys *Config.MartianConfig) error {

	fmt.Printf(Config.HEADER + "\r\n") // Writes our header from the Configuration

	// Prints the version
	fmt.Print(" "); log.Printf("\x1b[0m[\x1b[38;5;10mSUCCESS\x1b[0m] \x1b[0m[\x1b[38;5;9mSYS\x1b[0m] Running %s of MartianCNC", Config.VERSION)


	// OpenJsonConfig will parse the configuration
	if err := sys.DB.OpenJsonConfig(); err != nil {
		return err
	}

	// Success message for the terminal
	fmt.Print(" "); log.Printf("\x1b[0m[\x1b[38;5;10mSUCCESS\x1b[0m] \x1b[0m[\x1b[38;5;105mUSR\x1b[0m] User database has been parsed from the file: %s", sys.DB.UserFile)

	// CreateConfig will setup the environment for the server
	if err := ssh.CreateConfig(sys.SSH); err != nil {
		return err
	}

	// Success message for the creation of the environment creation with SQL
	// Other Success message for ssh listener started is found inside ./src/ssh/listener.go
	fmt.Print(" "); log.Printf("\x1b[0m[\x1b[38;5;10mSUCCESS\x1b[0m] \x1b[0m[\x1b[38;5;72mSSH\x1b[0m] SSH environment has been startup ready for connection watcher on [:%d]", sys.SSH.Listener)

	return nil
}