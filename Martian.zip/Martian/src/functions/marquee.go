package functions

import (
	"errors"
	"strconv"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
)

var (
	// ErrTickerUnwantedExit when the marquee function closure happens to exit
	ErrTickerUnwantedExit error = errors.New("unwanted ticker caused exit")
)

// MarqueeText will run inside a seperate goroutine for scrolling text
func MarqueeText(channel ssh.Channel, boundary string, target_text string, line, column, length, takes int, exit string, cancel chan struct{}) error {

	CurrentPos  := 0 - len(target_text)					// Holds the current banners position

	// Sleep period inbetween each rotation of frame
	sleep := time.NewTicker(time.Duration(takes) * time.Millisecond)


	for {
		select {

		case <-sleep.C: // New Frame tick

			// Allows for the frames to reset
			if CurrentPos + len(target_text) > length {
				CurrentPos = 0 - len(target_text) //resets position
			}

			// Starts to make the branding reappear
			if CurrentPos == 0 - len(target_text) {
	
				position := 0 - len(target_text)										// Stores our current position within the rotation
				ticker 	 := time.NewTicker(time.Duration(takes) * time.Millisecond)		// Stores our time inbetween each spindable of rotation

				for {
					select {

					case <- ticker.C: // New rotation tick

						// Ensures its within exit
						if position >= 0 { //moes to position
							goto broken //breaks from the system
						}

						// Writes the new marquee position on the line
						channel.Write([]byte("\x1b[s\x1b["+strconv.Itoa(line)+";"+strconv.Itoa(column)+"f\033[K"+boundary + "\x1b[38;5;11m\x1b[4m"+string(target_text[position*-1:])+"\x1b[0m\x1b[38;5;105m" + strings.Repeat(" ", length-len(target_text[position*-1:])) + exit+"\x1b[u"))
						position++

					case <-cancel: // Cancel call has been performed
						return nil
					}
				}

				broken: //broken down pointer segmant
				CurrentPos = 0
			}
			
			// Writes the block of formatted information towards the client
			channel.Write([]byte("\x1b[s\x1b["+strconv.Itoa(line)+";"+strconv.Itoa(column)+"f\033[K"+boundary+strings.Repeat(" ", CurrentPos)+"\x1b[38;5;11m\x1b[4m"+string(target_text)+"\x1b[0m\x1b[38;5;105m"+strings.Repeat(" ",length-CurrentPos-len(target_text))+exit+"\x1b[u"))

			// End of line has been detected as thie point
			if CurrentPos + len(target_text) == length {
				//for pos := len(target_text); pos > 0; pos-- {
				//	channel.Write([]byte("\x1b["+strconv.Itoa(line)+";"+strconv.Itoa(column)+"f\033[K"+boundary+strings.Repeat(" ", length-len(target_text[:pos]))+"\x1b[38;5;11m\x1b[4m"+target_text[:pos]+"\x1b[0m\x1b[38;5;105m"+exit+""))
				//	time.Sleep(time.Duration(takes) * time.Millisecond)
				//} 

				position := len(target_text)											// Stores our current position within the rotation
				ticker 	 := time.NewTicker(time.Duration(takes) * time.Millisecond)		// Stores our time inbetween each spindable of rotation

				for {
					select {

					case <- ticker.C: // New rotation tick

						// Ensures its within exit
						if position <= 0 { //moes to position
							goto broken1 //breaks from the system
						}

						// Writes the new marquee position on the line
						channel.Write([]byte("\x1b[s\x1b["+strconv.Itoa(line)+";"+strconv.Itoa(column)+"f\033[K"+boundary+strings.Repeat(" ", length-len(target_text[:position]))+"\x1b[38;5;11m\x1b[4m"+target_text[:position]+"\x1b[0m\x1b[38;5;105m"+exit+"\x1b[u"))
						position--

					case <-cancel: // Cancel call has been performed
						return nil
					}
				}

				broken1: //broken down pointer segmant
			}

			CurrentPos++ // Pushes one edition forward

		case <-cancel: // Marquee stop
			return nil
		}
	}
}


