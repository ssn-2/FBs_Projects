package functions

import (
	"strconv"
	"golang.org/x/crypto/ssh"
)

var (
	MaskCharater string = "●"
	WriteColour  string = "\x1b[0m"
)

// This will read from the channel any inputs with possible masking
func ReadFromChannel(channel ssh.Channel, virtualLength int, masking bool, line, col int, pre string) (string, error) {

	message			:= pre			// Stores our future message which we will mask with


	if len(pre) <= 0 {
		// Removes anything which is inside the vlength
		for fill := 0; fill < virtualLength; fill++ {
			channel.Write([]byte("\033["+strconv.Itoa(line)+";"+strconv.Itoa(col+fill)+"f "))
		}


		// Repositions the cursor position inside the targeted area
		if _, err := channel.Write([]byte("\033["+strconv.Itoa(line)+";"+strconv.Itoa(col)+"f")); err != nil {
			return "", err
		}
	} else {
		// Repositions the cursor position inside the targeted area
		if _, err := channel.Write([]byte("\033["+strconv.Itoa(line)+";"+strconv.Itoa(col+len(message))+"f")); err != nil {
			return "", err
		}
	}

	for {
		Charater		:= make([]byte, 1) 					// Stores the current charaters byte format
		if _, err := channel.Read(Charater); err != nil {	// Reads into the Charater buffer from the channel
			return "", err
		}
		
		switch Charater[0] {


		case 13: // Enter key detection
			return message, nil

		case 127: // Backspace support
			if len(message) <= 0 {
				continue
			}

			// Removes one seg from string
			message = message[:len(message)-1]

			// Prints the backspace byte code
			if _, err := channel.Write([]byte{127}); err != nil {
				return "", err
			}

		case 11, 12, 5, 8: // Possible mal codes
			continue

		case 27: // Sequentially starting point for most blocked inputs
			Seq := make([]byte, 6) // New Buffer
			if _, err := channel.Read(Seq); err != nil {
				return "", err
			}

		default:
			message += string(Charater[0]) 		// Adds onto the end of the message

			// Checks within text quidelines
			if len(message) > virtualLength {
				continue
			}

			if masking {
				// Writes the masked charater
				if _, err := channel.Write([]byte(WriteColour+MaskCharater)); err != nil {
					return "", err
				}
			} else {
				// Writes the masked charater
				if _, err := channel.Write([]byte(WriteColour+string(Charater[0]))); err != nil {
					return "", err
				}
			}
		}
	}

}