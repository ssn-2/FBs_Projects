package database

import (
	"encoding/json"
	"io/ioutil"
)

type JsonConfig struct {
	UserFile string `json:"user"`



	privateUsers []UserConfiguration // Configuration stores the private users
}

var (
	// Stores the system information
	System *JsonConfig = nil
)

// OpenJsonConfig will open all the config files
func (J *JsonConfig) OpenJsonConfig() error {

	// Parses the configuration for the user system
	if err := ParseConfig(J.UserFile, &J.privateUsers); err != nil {
		return err
	}

	System = J // Sets the storage level
	return nil
}

// ParseConfig will parse the configuration
func ParseConfig(path string, b interface{}) error {

	// ReadFile will read the configuration file
	render, err := ioutil.ReadFile(path)
	if err != nil {
		return err
	}

	return json.Unmarshal(render, &b)
}