package database

import (
	"crypto/sha256"
	"encoding/hex"
	"strings"
)

func Hash(s ...string) string { // Returns the source string
	return hex.EncodeToString(sha256.New().Sum([]byte(strings.Join(s, ""))))
}