package Config

import (
	"Martian/src/database"
	"Martian/src/ssh"
)



type MartianConfig struct {
	// Configuration for Martians SSH server
	SSH	 	 	        *ssh.ServerConfig

	// Configuration for the data storage file
	DB					*database.JsonConfig
}