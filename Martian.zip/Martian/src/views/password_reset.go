package views

import (
	"GoEYE"
	"Martian/src/database"
	"Martian/src/functions"
	"math/rand"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
)

// NewPasswordReset will reset the users password inside the system
func NewPasswordReset(channel ssh.Channel, conn *ssh.ServerConn, user *database.UserConfiguration) error {

	eye := GoEYE.GoEYE(channel, channel, GoEYE.DefaultStyle) // Creates our terminal style



	rand.Seed(time.Now().Unix()) // randomizes the seed for the random selection process
	question := user.Profile.SecurityQuestions[rand.Intn(len(user.Profile.SecurityQuestions))]

	eye.MakeButton(true,  15, 20, 61, question.Question,    "", "", GoEYE.DefaultStyle)
	eye.MakeButton(true,  18, 20, 61, "type password here", "", "", GoEYE.DefaultStyle) // Password box
	eye.MakeButton(true,  18, 63, 65, "x", 				    "", "", GoEYE.DefaultStyle)	// Show password
	eye.MakeButton(true,  22, 29, 52, "SUBMIT",    "\x1b[48;5;10m\x1b[38;5;16m", 	"\x1b[0m", GoEYE.DefaultStyle) // Exit button

	// Makes the box with the position
	if err := eye.Init(80, 80); err != nil {
		return err
	}

	channel.Write([]byte("\033[4;20f                       _   _             "))				// Little login banner
	channel.Write([]byte("\033[5;20f                      | | (_)            "))				// Little login banner
	channel.Write([]byte("\033[6;20f  _ __ ___   __ _ _ __| |_ _  __ _ _ __  "))				// Little login banner
	channel.Write([]byte("\033[7;20f | '_ ` _ \\ / _` | '__| __| |/ _` | '_ \\ "))				// Little login banner
	channel.Write([]byte("\033[8;20f | | | | | | (_| | |  | |_| | (_| | | | |"))				// Little login banner
	channel.Write([]byte("\033[9;20f |_| |_| |_|\\__,_|_|   \\__|_|\\__,_|_| |_|"))				// Little login banner
	channel.Write([]byte("\033[10;20f    \x1b[4mchange your account password below\x1b[0m"))	// Little login banner

	// Writes the marquee system for the element
	channel.Write([]byte("\033[28;0f├"+ strings.Repeat("─", 78)+"┤"))
	channel.Write([]byte("\033[0;3f \x1b[4mMartian\x1b[0m "))


	// Cancel and grab event channels stored inside here
	listen, breakp := make(chan *GoEYE.Event), make(chan struct{})
	go eye.WaitEvent(listen, breakp) // Event listener

	var (
		Answer 	         string = "" // Stores the answer
		Password 		 string = "" // Stores the password

		ShowingPass        bool = false // Stores if we are showing the password
	)

	for {
		systemEvent := <- listen // Awaits the listener

		// Only allows for valid cursor clicking on the home page buttons
		if systemEvent.Type != GoEYE.LeftClick && systemEvent.Type != GoEYE.RightClick {
			continue
		}

		// Control the event handler within net
		switch systemEvent.ButtonOccured.Label {

		case "SUBMIT": // Submits the details given for the current resp


			// Checks for an invalid question answer for the security question
			if question.CapitalSensitive && question.Answer != Answer || !question.CapitalSensitive && strings.ToLower(question.Answer) != strings.ToLower(Answer) {
				channel.Write([]byte("\033[15;33f\x1b[48;5;9m\x1b[38;5;16m Unknown answer \x1b[0m")); continue
			}

			// Tries to update the users password interface
			if err := database.System.ChangePassword(Password, user); err != nil {
				channel.Write([]byte("\033[15;32f\x1b[48;5;9m\x1b[38;5;16m invalid password \x1b[0m")); continue
			}

			breakp <- struct{}{}
			return nil
		case question.Question: // Stores the question for the system
			breakp <- struct{}{} // Stops cursor callback

			// Reads the username from the channel and ensures its done
			Ans, err := functions.ReadFromChannel(channel, 40, false, 15, 21, Answer)
			if err != nil {
				breakp <- struct{}{}
				return err
			}

			Answer = Ans // Updates the store

			// Runs the mouse cursor event
			go eye.WaitEvent(listen, breakp) 

		case "type password here": // Password collection system
			breakp <- struct{}{} // Stops cursor callback

			// Reads the username from the channel and ensures its done
			Pass, err := functions.ReadFromChannel(channel, 40, !ShowingPass, 18, 21, Password)
			if err != nil {
				breakp <- struct{}{}
				return err
			}

			Password = Pass // Updates the store

			// Runs the mouse cursor event
			go eye.WaitEvent(listen, breakp)
			
		case "x":

			if !ShowingPass {
				systemEvent.ButtonOccured.UpdateLabel(" ", "")
				ShowingPass = true

				channel.Write([]byte("\x1b[s\x1b[18;21f"+Password+"\x1b[u"))
			} else {
				systemEvent.ButtonOccured.UpdateLabel("x", "")
				ShowingPass = false

				channel.Write([]byte("\x1b[s\x1b[18;21f"+strings.Repeat(functions.MaskCharater, len(Password))+"\x1b[u"))
			}
		}
	}
}