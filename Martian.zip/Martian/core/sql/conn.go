package sql

import (
	"database/sql"
	_ "github.com/go-sql-driver/mysql"

	"martian/core/config"
)

var SQL *sql.DB = nil

// Connect will open the connection to the database
func Connect() error {

	// Open will open the connection with the database
	connection, err := sql.Open("mysql", Config.SQLUser + ":" + Config.SQLPassword + "@tcp(" + Config.SQLServer + ")" + "/" + Config.SQLName)
	if err != nil {
		return err
	}

	// Pings the connection with the database
	if err := connection.Ping(); err != nil {
		return err
	}

	SQL = connection // Sets the SQL connection

	return nil
}