package Config


const (

	// VERSION header for the program
	VERSION string = "v1.0"
)