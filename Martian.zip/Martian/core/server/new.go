package server

import (
	"martian/core/config"
	"martian/core/server/views"
	"time"

	"strconv"

	"golang.org/x/crypto/ssh"
)

// HandleNewConnection will create the new guidelines for the remote conn
func HandleNewConnection(channel ssh.Channel, conn ssh.ServerConn) error {

	// Adjusts the window screen size to the size wanted
	if _, err := channel.Write([]byte("\033c\x1b[8;"+strconv.Itoa(Config.ScreenY)+";"+strconv.Itoa(Config.ScreenX)+"t")); err != nil {
		return err
	}

	// Allows time for the client to reallocate the screen size
	time.Sleep(50 * time.Millisecond)

	// Returns the new connection
	return views.MakeNewConnection(channel, &conn)
}