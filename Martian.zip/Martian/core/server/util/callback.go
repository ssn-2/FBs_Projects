package util

import (
	"golang.org/x/crypto/ssh"
)

// MouseEventCallback will listen for mouse events from the server
func MouseEventCallback(channel ssh.Channel) (*MouseAlert, error) {

	// Writes the need XTerm for enabled the mouse events
	if _, err := channel.Write([]byte("\033[?1000h\033[?25h\033[?25l")); err != nil {
		return nil, err
	}

	for {
		buf := make([]byte, 6)
		// Read will read the data from conn clients
		if _, err := channel.Read(buf); err != nil {
			return nil, err
		}

		// Only accepts mouse events from the client
		if buf[0] != 27 || buf[1] != 91 || buf[2] != 77 {
			continue
		}

		// Stores the key detection type
		var MouseEventType MouseEvent = 0
		
		// Different events
		switch buf[3] {

		case 32: // LeftClick detection
			MouseEventType = LeftClick
		case 33: // ScrollClick detection
			MouseEventType = ScrollClick
		case 34: // RightClick detection
			MouseEventType = RightClick
		case 35: // MouseRelease detection
			MouseEventType = MouseRelease
		case 96: // ScrollUp detection
			MouseEventType = ScrollUp
		case 97: // ScrolDown detection
			MouseEventType = ScrollDown
		}

		return &MouseAlert{
			Alert: 				MouseEventType, // Stores the mouse click event details
			X:					ConvertPosition(buf[4]), // X but with the offset removed
			Y: 					ConvertPosition(buf[5]), // Y but with the offset removed
			String: 			MouseEventType.ToString(),
		}, nil
	}
}