package util

import "golang.org/x/crypto/ssh"

// This will read from the channel any inputs with possible masking
func ReadFromChannel(channel ssh.Channel, virtualLength int, masking bool) (string, error) {

	message			:= ""			// Stores our future message which we will mask with


	for {
		Charater		:= make([]byte, 1) 					// Stores the current charaters byte format
		if _, err := channel.Read(Charater); err != nil {	// Reads into the Charater buffer from the channel
			return "", err
		}

		
		switch Charater[0] {



		default:
			message += string(Charater) 		// Adds onto the end of the message
		}
	}

}