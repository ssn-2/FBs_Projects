package ssh

import (
	"fmt"
	"log"
	Config "martian/core/config"
	"net"

	"golang.org/x/crypto/ssh"
)

// ListenAddress will start the listener for the server
func ListenAddress(config *ssh.ServerConfig) error {

	// Listens for incoming connections on the server
	listener, err := net.Listen("tcp", Config.MasterServer)
	if err != nil {
		return err
	} else {
		// Success message for the server starting
		fmt.Print(" \x1b[0m"); log.Printf("[\x1b[38;5;10mSUCCESS\x1b[0m] [\x1b[38;5;26mSSH\x1b[0m] ssh connection watcher has been established at %s\r\n", Config.MasterServer)
	}

	for {
		// Accepts incoming connections
		connection, err := listener.Accept()
		if err != nil {
			return err
		}

		// Handles the incoming connection
		go NewClientConnectionOrigin(connection, config)
	}

}