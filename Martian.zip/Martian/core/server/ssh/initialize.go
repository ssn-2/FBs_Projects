package ssh

import (
	"io/ioutil"
	"golang.org/x/crypto/ssh"

	"martian/core/config"
)

// initalize will start our server process
func Initalize() error {

	// severSettings stores our chosen options
	serverSettings := &ssh.ServerConfig{
		MaxAuthTries: 		1,			// only allow 1 authentication attempt per connection
		NoClientAuth: 		true,		// disable any builtin client authentication from the server
	}

	// Tries to load our servers private key file
	privatekeyfile, err := ioutil.ReadFile(Config.ServerPrivateKey)
	if err != nil {
		return err
	} 

	// ParsePrivateKey will parse the private key bytes from the file
	privateSignature, err := ssh.ParsePrivateKey(privatekeyfile)
	if err != nil {
		return err
	}

	// Syncs the private key with the server
	serverSettings.AddHostKey(privateSignature)


	// ListenAddress will start tcp process with the configuration
	return ListenAddress(serverSettings)
}