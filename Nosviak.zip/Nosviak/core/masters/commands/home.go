package commands

import (
	"Nosviak/core/masters/sessions"
	"Nosviak/core/models/views"
)

func init() {
	NewCommand(&Command{
		//resets the client to the welcome.dtx
		//this menu will completely reset the users screen
		Name:           "home",
		Desciption:     "redirects you back to the home splash",
		MinPermissions: make([]string, 0),
		ZeroArguments: func(session *sessions.Session, args []string) error {

			return views.NewDTX("welcome.dtx", session.Write).Template(session, session.Channel)
		},
	})
}