package commands

import (
	"Nosviak/core/deployment"
	"Nosviak/core/masters/sessions"
	"Nosviak/core/masters/users/ranks"
	"Nosviak/core/models/configs/json"
	"Nosviak/core/models/configs/toml"
	"Nosviak/core/models/views"
	"log"
	"strconv"
)

func init() {
	NewCommand(&Command{
		//this command allows you to reload your branding items
		//you can completetly reload all assets folder
		Name:           "reload",
		Desciption:     "completetly reloads all assets",
		MinPermissions: []string{"admin"},
		ZeroArguments: func(session *sessions.Session, args []string) error {

			//ranges through all the current active toml ranks
			//this will delete any toml ranks (external rank commands)
			for name, rankCurrent := range Toml.RanksToml.Ranks {
				//loops again if the rank isn't active
				//if the rank isn't active we will ignore it
				if !rankCurrent.Status {
					continue
				}

				//gets the user command
				//this allows us to safely modify it
				c := GetCommand("users")

				//ranges through all the subfeatures of a command
				//every subcommand which is a rank command will be deleted
				for index, feature := range c.NonBody {
					//compares the name safely
					//makes sure we are removing the correct object
					if feature.Name == name {
						//completetly updates the array
						//this will remove the subcommand information from the array
						c.NonBody = RemoveIndex(c.NonBody, index)
					}

				}
			}

			views.ScrapBranding()

			//reloads all branding
			//this will force the parser to completetly reload everything
			if err := views.FetchBranding(deployment.View); err != nil {
				session.Write([]byte("Hmmm, it seems there was an issue when reloading you're branding!\r\n"))
				session.Write([]byte("This issue has been logged into the terminal stream, check for more information\r\n"))
				log.Printf("ErrPointer [branding]: %s\r\n", err.Error())
				return err
			}

			//trys to completetly reload the toml information
			if err := Toml.MakeToml(deployment.Assets).RunParser(); err != nil {
				session.Write([]byte("Hmmm, it seems there was an issue when reloading you're Toml configuration!\r\n"))
				session.Write([]byte("This issue has been logged into the terminal stream, check for more information\r\n"))
				log.Printf("ErrPointer [toml]: %s\r\n", err.Error())
				return err
			}

			//gets the users command information
			cTest := GetCommand("users")
			//completetly clears the nonbody feature
			cTest.NonBody = make([]NonBodyFeature, 0)
			//array which contains our information on the body
			var StoreNonBody []NonBodyFeature = make([]NonBodyFeature, 0)
			//merges the internal map with the external map
			ranks.MergeToml()

			//ranges through all the toml ranks correctly
			//we do it at this point to stop us from registering the internal roles
			for name, rank := range Toml.RanksToml.Ranks {

				//doesn't register inactive commands
				//makes sure every role we register is active
				if !rank.Status {
					continue
				}

				if name == "admin" || name == "banned" {
					continue
				}

				//correctly stores the information as a command
				StoreNonBody = append(StoreNonBody, NonBodyFeature{
					Name: name,
					Description: rank.Description,
					Permissions: rank.PermissionsPromote,
				})

				StoreNonBody = append(StoreNonBody, NonBodyFeature{
					Name: name+"=true",
					Description: "promote a user to vipplus status",
					Permissions: rank.PermissionsPromote,
				})

				StoreNonBody = append(StoreNonBody, NonBodyFeature{
					Name: name+"=false",
					Description: "demote a user from vipplus status",
					Permissions: rank.PermissionsPromote,
				})
			}

			//ranges through all the registered commands
			for index, command := range Container {
				//checks if the commandName is the users information
				if command.Name != "users" {
					//loops again correctly
					continue
				}
				//updates the command inside the array properly
				Container[index].NonBody = StoreNonBody
			}

			//trys to completetly reload the json information
			if err := json.MakeJson(deployment.Assets).RunParser(); err != nil {
				session.Write([]byte("Hmmm, it seems there was an issue when reloading you're Json configuration!\r\n"))
				session.Write([]byte("This issue has been logged into the terminal stream, check for more information\r\n"))
				log.Printf("ErrPointer [json]: %s\r\n", err.Error())
				return err
			}
			
			session.Write([]byte("success!, the reload sequence has been completed.\r\n"))
			session.Write([]byte(strconv.Itoa(len(views.Store))+" branding objects have been reloaded correctly!\r\n"))
			session.Write([]byte("You're Json & Toml configuration's have been reloaded aswell!\r\n"))



			return nil
		},
	})
}

//removes an object from an array correctly
func RemoveIndex(s []NonBodyFeature, index int) []NonBodyFeature {
    return append(s[:index], s[index+1:]...)
}