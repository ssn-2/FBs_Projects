package commands

import (
	"Nosviak/core/masters/sessions"
	"Nosviak/core/models/dtx"
	"Nosviak/core/models/views"
	"strconv"
	"strings"
	"unicode/utf8"
)

func init() {

	//registers a new command into the array
	NewCommand(&Command{
		//displays all possible options inside dtxtokens inside a file
		//this displays the token assembly of any file selected
		//mainly used for advanced debugging
		Name:           "dtxtokens",
		Desciption:     "displays the dtxToken assembly",
		MinPermissions: []string{"admin"},
		ZeroArguments:  func(session *sessions.Session, args []string) error {

			if len(args) <= 1 {
				//displays the missing arguments issue
				return views.NewDTX("dtx-arguments.dtx", session.Write).Template(session, session.Channel)
			}

			//gets the branding item from the map
			piece, err := views.SearchPiece(args[1])
			if err != nil {
				return views.NewDTX("dtx-invalid.dtx", session.Write).Template(session, session.Channel)
			}

			//the array we will save everything into
	        var LexerInput [][]string = make([][]string, 0)
        
	        //ranges through the object we have correctly
	        for _, Line := range piece.Source {
				//we won't amplify the ansi
	        	LexerInput = append(LexerInput, strings.Split(Line, ""))
	        }

			lex := dtx.CreateLexer(LexerInput)

			if _, err := lex.PerformLexer(); err != nil {
				return views.NewDTX("dtx-lexer.dtx", session.Write).Template(session, session.Channel)
			}

			for Pos, Token := range lex.GetTokens() {
				if _, err := session.Write([]byte("\x1b[0m"+Filler(strconv.Itoa(Token.StartPos().Row)+":"+strconv.Itoa(Token.StartPos().Col), 7)+"|   "+Filler(Token.VType, 15)+Token.Literal())); err != nil {
					return err
				}

				if Pos < len(lex.GetTokens()) {
					session.Write([]byte("\r\n"))
				}
			}


			return nil
		},
	})
}

func Filler(Object string, want int) string {

	var Correction = Object

	for Length := utf8.RuneCountInString(Object); Length < want; Length++ {
		Correction += " "
	}

	return Correction
}