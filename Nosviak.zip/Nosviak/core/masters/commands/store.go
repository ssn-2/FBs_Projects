package commands

import (
	"Nosviak/core/masters/sessions"
	"sync"
)

var (
	//stores the command array
	//where all commands are registered into
	Container []Command = make([]Command, 0)
	Mux sync.Mutex
)

//stores the command structure
//this can be used to store in an array for easy access
type Command struct {
	//stores the main command name
	//this is what we will use to access this command at anyTime
	Name string

	//stores all the permissions needed for this command
	//this is used mainly for the user management commands
	MinPermissions []string

	//stores information about the command
	//this is used so users can find out what each commands do
	Desciption string

	//please not that any subcommands which don't exist inside the subfeature array will trigger this
	//stores what the command handler will execute when the function has 0 arguments
	ZeroArguments func(session *sessions.Session, args []string) error

	//stores all subfeatures the command has
	//we store subfeatures like this so we can access them easier and they are easier to access
	SubFeatures []SubFeature

	//this is executes only when the function isn't equal to nil and the subcommand is invalid
	//mainly used for adding the custom role handler meaning users can be promoted and demoted easily 
	InvalidSubCommand func(session *sessions.Session, args []string) error

	NonBody []NonBodyFeature
}

type SubFeature struct {
	//stores the SubCommand name
	//this is what we will use to access this subcommand at any time
	Name string

	//if this is set to true
	//we will split everything inside the name
	SplitName bool

	//stores the object we will split by
	//this can be anything as we will get the first position out of this
	SplitCharater string

	//stores all the permissions needed for this command
	//this is used mainly for the user management commands
	MinPermissions []string

	//stores information about the subcommand
	//this is used so users can find out what each subcommands do
	Desciption string

	//stores what the command handler will execute
	ExecutionBody func(session *sessions.Session, args []string) error
}

//used for dynamic commands which require a field
type NonBodyFeature struct {
	//stores the information name
	//this is mainly used for dynamic commands inside the handler
	Name string

	//the description of the subcommand
	//information about the nonbodyfeature
	Description string

	//stores all the permissions needed for the command
	//this won't be inforced unless there is a handler function inside the function
	Permissions []string
}