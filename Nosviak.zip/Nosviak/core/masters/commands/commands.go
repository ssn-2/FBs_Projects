package commands

import (
	"Nosviak/core/masters/sessions"
	"Nosviak/core/masters/users/pager"
	"Nosviak/core/masters/users/ranks"
	"Nosviak/core/models/configs/toml"
	"Nosviak/core/models/util"
	"Nosviak/core/models/views"

	"strconv"

	"github.com/alexeyco/simpletable"
)

func init() {
	NewCommand(&Command{
		//this command will list all commands
		//used as an basic menu to view all commands possible
		Name:           "commands",
		Desciption:     "lists all commands registered",
		MinPermissions: make([]string, 0),
		ZeroArguments: func(session *sessions.Session, args []string) error {

			//checks if the user is looking for the subcommands
			//this will list all subcommands for a function
			if len(args) >= 2 {
				//this will get the command
				//this will also check if the command exists
				c := GetCommand(args[1])
				
				//checks if the command has any subcommands
				//this is so we don't try render a command without any subcommands
				if c == nil || c.SubFeatures == nil || len(c.SubFeatures) <= 0 {
					//this will print a custom err if a branding peice doesn't exist
					return views.NewDTX("commands-NoSubCommands.dtx", session.Write).RegisterVariable("query", args[0]).RegisterVariable("subquery", args[1]).Template(session, session.Channel)
				}

				//creates a new simpletable structure
				//this will store our users information
				table := simpletable.New()

				//correctly sets the table header information
				//this stores information about the commands
				table.Header = &simpletable.Header{


					Cells: []*simpletable.Cell{
						{Align: simpletable.AlignCenter, Text: "#"},
						{Align: simpletable.AlignCenter, Text: "   Name   "},
						{Align: simpletable.AlignCenter, Text: "Description"},
						{Align: simpletable.AlignCenter, Text: "Ranks"},
					},
				}

				//ranges through all commands which have been registered correctly
				for position, command := range c.SubFeatures {

					//creates a new tablcell row
					//this stores the rows information
					r := []*simpletable.Cell{
						{Align: simpletable.AlignCenter, Text: strconv.Itoa(position)},
						{Align: simpletable.AlignLeft, Text: command.Name},
						{Align: simpletable.AlignLeft, Text: command.Desciption},
						{Align: simpletable.AlignLeft, Text: ranks.InternalDecorate(command.MinPermissions, Toml.DecorationToml.Gradient.Status && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, "commands"))},
					}

					//saves the information into the array
					table.Body.Cells = append(table.Body.Cells, r)
				}

				//ranges through the nonbody commands fitted
				for position, command := range c.NonBody {
					//creates a new tablcell row
					//this stores the rows information
					r := []*simpletable.Cell{
						{Align: simpletable.AlignCenter, Text: strconv.Itoa(position+len(c.SubFeatures))},
						{Align: simpletable.AlignLeft, Text: command.Name},
						{Align: simpletable.AlignLeft, Text: command.Description},
						{Align: simpletable.AlignLeft, Text: ranks.InternalDecorate(command.Permissions, Toml.DecorationToml.Gradient.Status && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, "commands"))},
					}

					//saves the information into the array
					table.Body.Cells = append(table.Body.Cells, r)
				}

				//renders the pager and prints any error which was found
				return pager.NewPager("commands", table, session).ExecutePager()
		
			}

			//creates a new simpletable structure
			//this will store our users information
			table := simpletable.New()

			//correctly sets the table header information
			//this stores information about the commands
			table.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "#"},
					{Align: simpletable.AlignCenter, Text: "   Name   "},
					{Align: simpletable.AlignCenter, Text: "Description"},
					{Align: simpletable.AlignCenter, Text: "Ranks"},
				},
			}

			//ranges through all commands which have been registered correctly
			for position, command := range Container {

				//creates a new tablcell row
				//this stores the rows information
				r := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: strconv.Itoa(position)},
					{Align: simpletable.AlignLeft, Text: command.Name},
					{Align: simpletable.AlignLeft, Text: command.Desciption},
					{Align: simpletable.AlignLeft, Text: ranks.InternalDecorate(command.MinPermissions, Toml.DecorationToml.Gradient.Status && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, "commands"))},
				}

				//saves the information into the array
				table.Body.Cells = append(table.Body.Cells, r)
			}

			//renders the pager and prints any error which was found
			return pager.NewPager("commands", table, session).ExecutePager()
		},
	})
}