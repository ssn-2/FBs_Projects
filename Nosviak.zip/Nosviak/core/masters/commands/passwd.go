package commands

import (
	"Nosviak/core/database"
	"Nosviak/core/masters/sessions"
	"Nosviak/core/models/views"

	"golang.org/x/term"
)


func init() {

	NewCommand(&Command{
		//allows a user to edit there password
		//this will make sure the user can update there password
		Name: "passwd",
		Desciption: "updates a users maiden password",
		MinPermissions: make([]string, 0),
		ZeroArguments: func(session *sessions.Session, args []string) error {

			//renders the new password banner
			//this will render when the user types the command for the first time
			err := views.NewDTX("commands-passwd-Banner.dtx", session.Write).Template(session, session.Channel)

			//err handles the render statement
			//this will make sure the command executes the render splash
			if err != nil {
				//returns the err which was found
				return err
			}

			//renders the prompt
			//this will be the first prompt out of 2 prompt options
			err = views.NewDTX("commands-passwd-Password.dtx", session.Write).Template(session, session.Channel)

			//err handles the render statement
			//this will make sure the command executes the render splash
			if err != nil {
				//returns the err which was found
				return err
			}

			//creates a new reader instance
			//this is what the user will render
			Term := term.NewTerminal(session.Channel, "")

			//reads the incoming statement properly
			//this will read the input from the user properly & safely
			PasswordOne, err := Term.ReadLine()

			//err handles the read statement
			//makes sure no errors happened when reading the statement
			if err != nil {
				//err handles the read statement properly
				return err
			}
			
						//renders the prompt
			//this will be the first prompt out of 2 prompt options
			err = views.NewDTX("commands-passwd-ConfirmPassword.dtx", session.Write).Template(session, session.Channel)

			//err handles the render statement
			//this will make sure the command executes the render splash
			if err != nil {
				//returns the err which was found
				return err
			}

			//creates a new reader instance
			//this is what the user will render
			Term = term.NewTerminal(session.Channel, "")

			//reads the incoming statement properly
			//this will read the input from the user properly & safely
			PasswordTwo, err := Term.ReadLine()

			//err handles the read statement
			//makes sure no errors happened when reading the statement
			if err != nil {
				//err handles the read statement properly
				return err
			}

			//checks that the two inputs match correctly
			//this will allow us to check that both passwords match
			if PasswordOne != PasswordTwo {
				return views.NewDTX("commands-passwd-NotMatch.dtx", session.Write).Template(session, session.Channel)
			}

			//querys the password update inside the database
			//this will push the password updation inside the database
			err = database.Container.UpdatePassword(PasswordOne, session.User.Username)

			//checks if the password was updated correctly
			//this will make sure the password was updated, if not we will return an error
			if err != nil {
				//renders the error splash which will display an interface
				return views.NewDTX("commands-passwd-Error.dtx", session.Write).Template(session, session.Channel)
			}

			//renders the passwd updated command
			//this will display that the password was updated
			return views.NewDTX("commands-passwd-Updated.dtx", session.Write).Template(session, session.Channel)
		},
	})
}