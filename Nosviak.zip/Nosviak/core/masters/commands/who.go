package commands

import (
	"Nosviak/core/masters/sessions"
	"Nosviak/core/masters/users/pager"

	"strings"

	"github.com/alexeyco/simpletable"
)

func init() {
	NewCommand(&Command{
		//this command completely clears the clients screen
		//it will also render the `clear-splash.dtx`
		Name:           "who",
		Desciption:     "sessions opened in your username",
		MinPermissions: make([]string, 0),
		ZeroArguments: func(session *sessions.Session, args []string) error {

			//creates a new simpletable structure
			//this is used to store our table information so we can render it correctly
			NewTable := simpletable.New()

			//correctly sets the headers to what we are looking for
			//this allows more customiszation for the clients
			NewTable.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "     User     "},
					{Align: simpletable.AlignCenter, Text: "Connected"},
					{Align: simpletable.AlignCenter, Text: "IP"},
				},
			}

			//ranges through all active sessions
			//this allows us to control a sessions better
			//also allows us to view who is connected from where
			for _, s := range sessions.Sessions {

				//this will force it to only display the users username open sessions
				//forces it to only be the current usernames open sessions
				if session.User.Username != s.User.Username {
					continue
				}

				//creates a new table body cell
				//this shall give us access to the users information for this rotation
				r := []*simpletable.Cell{
					{Align: simpletable.AlignLeft, Text: s.User.Username},
					{Align: simpletable.AlignCenter, Text: s.Connected.Format("15:04:05")},
					{Align: simpletable.AlignCenter, Text: strings.Split(s.Conn.RemoteAddr().String(), ":")[0]},
				}
	
				//correctly saves into the array correctly
				//meaning it can be rendered inside the pager correctly
				NewTable.Body.Cells = append(NewTable.Body.Cells, r)
			}

			//renders the pager and prints any error which was found
			return pager.NewPager("who", NewTable, session).ExecutePager()
		},
	})
}