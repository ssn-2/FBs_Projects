package commands

import (
	"Nosviak/core/deployment"
	"Nosviak/core/masters/sessions"
	Toml "Nosviak/core/models/configs/toml"
	"fmt"
	"strings"
)

func init() {
	NewCommand(&Command{
		//executes the command which displays information about the cnc version etc
		Name:           "credits",
		Desciption:     "view more information about this unit",
		MinPermissions: make([]string, 0),
		ZeroArguments: func(session *sessions.Session, args []string) error {
			//renders the user who is viewing and the cnc's version
			//this is basic management, as this version contains custom appnames
			//we will want to display a custom note next to the name if there is a different appName
			if strings.ToLower(Toml.InstanceToml.Default.AppName) != "nosviak" {
				fmt.Fprintf(session.Channel, "Welcome %s - %s (Nosviak) %s\r\n", session.User.Username, Toml.InstanceToml.Default.AppName, deployment.Version)
			} else {
				fmt.Fprintf(session.Channel, "Welcome %s - %s %s\r\n", session.User.Username, Toml.InstanceToml.Default.AppName, deployment.Version)
			}
			fmt.Fprintf(session.Channel, " - %s contains over 5K Lines of Go code solely written by FB\r\n", Toml.InstanceToml.Default.AppName)
			fmt.Fprintf(session.Channel, " - %s runs extremely efficiently while maintaining it's features!\r\n", Toml.InstanceToml.Default.AppName)

			return nil
		},
	})
}