package commands

import "strings"

//prepares to register the new command
func NewCommand(cmd *Command) {

	//checks if the command already exists
	if cmd.Already() {
		//returns as there is no need to make it
		return
	}

	//verifys all subfeatures correctly
	cmd.SubFeatures = cmd.VerifySubs(cmd.SubFeatures)

	Mux.Lock()
	defer Mux.Unlock()

	//inserts the current command into the array
	Container = append(Container, *cmd)
}

//verifys all the subcommands inside the array correctly
func (cmd *Command) VerifySubs(sub []SubFeature) ([]SubFeature) {

	//ranges through all the valid sub features
	for pos, cb := range sub {

		//checks if the split function is active
		if cb.SplitName {
			//splits the charater by the first charater
			sub[pos].Name = strings.Split(cb.Name, cb.SplitCharater)[0]
		}
	}
	//returns the subcommand correctly
	return sub
}


//checks if the command already exists
//basic err checking for the command which is being made
func (cmd *Command) Already() bool {

	//ranges through all active commands
	for _, Commands := range Container {

		//compares the two command names
		if strings.EqualFold(strings.ToLower(Commands.Name), strings.ToLower(cmd.Name)) {
			return true
		}
	}

	return false
}

//gets the command corresponding to that name
func GetCommand(name string) *Command {

	//ranges through all correctly registered commands
	for _, Command := range Container {

		//returns the command structure is the two substructures are correct
		if strings.EqualFold(strings.ToLower(Command.Name), strings.ToLower(name)) {
			return &Command
		}
	}

	//returns nil as the command wasn't found
	return nil
}


//if this object is equal to nil
//you will just execute the default function
func (c *Command) IndexSubCommand(sub string) (*SubFeature) {

	//ranges through all subcommands
	for _, feature := range c.SubFeatures {
		//compares the to strings to each other correctly
		if strings.EqualFold(strings.ToLower(feature.Name), strings.ToLower(sub)) {
			//returns the current feature
			return &feature
		}
	}

	//if this is returned you will need to execute the default command
	return nil
}