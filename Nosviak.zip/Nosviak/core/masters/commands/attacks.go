package commands

import (
	"Nosviak/core/masters/sessions"
	"Nosviak/core/masters/users/pager"
	"Nosviak/core/masters/users/ranks"
	"Nosviak/core/models/configs/json"
	Toml "Nosviak/core/models/configs/toml"
	"Nosviak/core/models/util"
	"strconv"

	"github.com/alexeyco/simpletable"
)

func init() {

	NewCommand(&Command{
		Name:           "attacks",
		Desciption:     "displays all available attacks methods",
		MinPermissions: nil,
		ZeroArguments: func(session *sessions.Session, args []string) error {
			//creates a new simpletable structure
			//this will store our users information
			table := simpletable.New()

			//correctly sets the table header information
			//this stores information about the attacks
			table.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "#"},
					{Align: simpletable.AlignCenter, Text: "     Name     "},
					{Align: simpletable.AlignCenter, Text: "Description"},
					{Align: simpletable.AlignCenter, Text: "Ranks"},
				},
			}

			//ranges through all registered api methods
			//this will create a body cell per method
			for validation, Attack := range json.ContentApis.Methods {
				//fills an row of method information
				//this will display information about a certain method
				r := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: strconv.Itoa(validation)},
					{Align: simpletable.AlignLeft, Text: Attack.Name},
					{Align: simpletable.AlignLeft, Text: Attack.Description},
					{Align: simpletable.AlignLeft, Text: ranks.InternalDecorate(Attack.Access.Access, Toml.DecorationToml.Gradient.Status && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, "attacks"))},
				}

				//saves the information into the array of body cells
				table.Body.Cells = append(table.Body.Cells, r)
			}

			return pager.NewPager("attacks", table, session).ExecutePager()
		},
	})
}