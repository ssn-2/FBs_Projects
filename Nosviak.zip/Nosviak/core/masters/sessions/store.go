package sessions

import (
	"Nosviak/core/masters/users/terminal"
	"Nosviak/core/database"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
)

var (
	//stores the map of the sessions which have been made
	Sessions map[int64]*Session = make(map[int64]*Session)
	mux sync.Mutex
)

type Session struct {
	//stores the current user profile
	//this will store information which was gotton from the database
	User *database.User

	//stores the time the user officially connected
	//this is mainly used for moderation of session active time
	Connected time.Time

	//stores the time the user has been idle for 
	//this is mainly used for moderation of session inactivity
	Idle time.Time

	//stores the current channel information
	//this is used so we can write to the individual sessions
	Channel ssh.Channel

	//stores the current connection information
	//this is used so we manage individual sessions
	Conn *ssh.ServerConn

	//stores the terminals current size
	TerminalSize *TerminalSize
	
	//stores information about the current connection
	//this will allow us to access the writing function
	//also allows us to see what we have rewritten to this host
	*terminal.Terminal

	//stores how many views are currently viewing this user in sessions glass
	GlassViewers int

	//stores the current title file which is being renders
	//this will store the file header, which will allow us to edit what the user views
	//the default for this will be the title.dtx file
	Title string
}

//stores the current terminal size
type TerminalSize struct {
	W, H int
}
