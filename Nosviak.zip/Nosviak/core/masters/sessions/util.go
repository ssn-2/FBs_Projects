package sessions

import (
	"strconv"
	"strings"
	"unicode/utf8"
)

//this function will display a function at the bottom middle of the client screen
//you may set custom colours in the arguments for the function and it will keep with the size of your window
func (session *Session) MakeLowerBanner(message string, colourOne, colourTwo int) error {

	//works out where we want to start writing from
	size := session.TerminalSize.W/2 - utf8.RuneCountInString(message)/2

	//writes the ansi escape codes
	if _, err := session.NonWrite([]byte("\x1b7\x1b[80;0f\x1b[48;5;" + strconv.Itoa(colourOne) + "m\x1b[38;5;" + strconv.Itoa(colourTwo) + "m")); err != nil {
		return err
	}

	//ranges through until window has been complete
	for position := 0; position < session.TerminalSize.W+1; position++ {

		//checks if the position if correct
		//if so we will render our message
		if position == size {
			//writes our message to the remote host
			if _, err := session.NonWrite([]byte("\x1b[38;5;" + strconv.Itoa(colourTwo) + "m" + message)); err != nil {
				return err
			}
			//adds on the amount of positions
			//meaning we can skip positions
			position += utf8.RuneCountInString(message)

		} else {
			//renders a blank space
			//meaning nothing will be written here
			if _, err := session.NonWrite([]byte(" ")); err != nil {
				return err
			}
		}
	}

	//resets the terminals bistandard colour ratio
	//stips all ansi codes from here in future requests safely
	if _, err := session.NonWrite([]byte("\x1b8")); err != nil {
		return err
	}
	return nil
}


//takes the ssh banner information
//and returns a resolved ssh client name
func ResolveClientVersion(Version []byte) string {
	//stores all the support ssh clients for this function
	var KeyWords = []string{"windows", "Ubuntu", "KiTTY", "PuTTY", "OpenSSH"}

	//ranges through all keywords
	for _, Keyword := range KeyWords {
		//compares the version and this
		if strings.Contains(string(Version), Keyword) {
			return Keyword
		}
	}

	//returns an err message
	return "EOF"
}