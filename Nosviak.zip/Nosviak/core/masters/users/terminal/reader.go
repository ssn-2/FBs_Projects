package terminal



//pauses until a keypress is detected
func (t *Terminal) PauseTill() {

	size := make([]byte, 1)

	//waits till the next read input
	if _, err := t.channel.Read(size); err != nil {
		return
	}

	return
}