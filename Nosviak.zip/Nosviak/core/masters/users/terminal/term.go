package terminal

import "golang.org/x/crypto/ssh"


//the terminal structure
//allows us to store information
type Terminal struct {
	//stores everything we have written to the remote host
	//this will allow us to watch peoples terminal's live and view more information
	Written []string

	//stores the ssh channel interface
	//this is how we will confirm our writes to the host
	channel ssh.Channel
}

//stores the information about the newTerminal
//this is how we will write to our remote hosts easier
func NewTerm(channel ssh.Channel) *Terminal {
	return &Terminal{
		Written: make([]string, 0),
		channel: channel,
	}
}