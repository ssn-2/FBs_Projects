package terminal


//writes information to the host
//we will save anything which is written through this function
func (t *Terminal) Write(source []byte) (int, error) {
	//saves the written part into a string correctly
	t.Written = append(t.Written, string(source))
	//returns the channel write function
	return t.channel.Write(source)
}

func (t *Terminal) NLWrite(source []byte) (int, error) {
	//saves the written part into a string correctly
	t.Written = append(t.Written, string(source)+"\r\n")
	//returns the channel write function
	return t.channel.Write(source)
}

func (t *Terminal) NonWrite(source []byte) (int, error) {
	//saves the written part into a string correctly
	//returns the channel write function
	return t.channel.Write(source)
}

