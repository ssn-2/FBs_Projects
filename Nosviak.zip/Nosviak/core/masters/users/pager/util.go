package pager

import (
	"Nosviak/core/masters/sessions"
	"Nosviak/core/models/views"

	"strings"

	"github.com/alexeyco/simpletable"
	"github.com/zieckey/goini"
)

//this function will help making exempting items from gradients
//this is used so we can block certain items inside a table from gradient
func ExemptGradient(g bool, text string) string {
	//checks if gradient is active
	if g {
		return "*"+text+"*"
	}
	//else return the raw text
	return text
}


//function will completetly ignore all headers from the gradient
//makes using the gradient function easier on the cnc and producing a cleaner outlook
func IgnoreHeaders(cells []*simpletable.Cell) ([]*simpletable.Cell) {

	//ranges through all active cells
	for Pos, Cell := range cells {
		//places the ignore content into the cell text
		cells[Pos].Text = "*"+Cell.Text+"*"
	}

	//returns the cells correctly
	return cells
}

//checks if the window needs the pager
//this can be sorted by getting the height of the window
//this function will take the session structure and the amount of cols in the table
func PagerAssistance(session *sessions.Session, cols int) bool {

	//checks that the table will fit correctly on the terminal
	if session.TerminalSize.H - 2 > cols {
		return true
	}

	return false
}

//sets the simpletable style
//this is so the instance can control what the table looks like
func QueryStyle(style int) *simpletable.Style {
	switch style {
	case 1:
		return simpletable.StyleCompact
	case 3:
		return simpletable.StyleCompactClassic
	case 4:
		return simpletable.StyleMarkdown
	case 5:
		return simpletable.StyleRounded
	case 6:
		return simpletable.StyleUnicode
	default:
		return simpletable.StyleCompactLite
	}
}

//sets the simpletable pager instance style
//this is so the instance can control what the table looks like when there is a pager
func QueryStylePager(style int) *simpletable.Style {
	switch style {
	case 1:
		return simpletable.StyleCompact
	default:
		return simpletable.StyleCompactLite
	}
}

//gets the queryed style
//this will open from the tables folder using the branding object
func GetQueryStyle(File string) (*simpletable.Style, bool, error) {

	//gets the piece from the folder correctly
	//this will be passed into the query function
	View, err := views.SearchPiece(File)
	if err != nil {
		return nil, false, err
	}

	//joins the source in a line by line basis
	Source := strings.Join(View.Source, "\n")

	//creates a new ini instance
	ini := goini.New()

	//parses the file correctly
	if err := ini.Parse([]byte(Source), "\n", "="); err != nil {
		return nil, false, err
	}

	//gets the table type from the file correctly
	Type, boolen := ini.GetInt("TableType")
	if !boolen {
		return QueryStyle(9), false, nil
	}

	Header, boolen := ini.GetBool("ignoreHeader")
	if !boolen {
		return nil, false, nil
	}


	//returns the query type correctly
	return QueryStyle(Type), Header, nil
}

//gets the longest row in the class properly
//this allows us to acces it at any point properly
func (method *Pager) GetLongestRow(source []string) int {
	return len(source[1]) - 1
}