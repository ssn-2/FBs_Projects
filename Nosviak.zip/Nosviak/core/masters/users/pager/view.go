package pager

import (
	"strconv"

	"github.com/alexeyco/simpletable"
)

//function used to render the tables current rows inside the pager
//displays all rows which are currently viewable
func (method *Pager) RenderTable(position int, Row []string) error {

	//sets style correctly
	method.Table.SetStyle(simpletable.StyleCompactLite)


	//stores how many cols the user can view at once safely
	viewableCols := method.Session.TerminalSize.H 

	var subsession int = 2

	//for loops through all the possible options correctly
	for Polc := position + 2; Polc < position + viewableCols; Polc++ {
		subsession += 1
		
		if position + viewableCols - 1 >= len(method.Table.Body.Cells) {
			return nil
		}


		method.Session.Write([]byte("\033["+strconv.Itoa(subsession)+";0H\x1b[2K"+Row[Polc]))
	}


	return nil
}