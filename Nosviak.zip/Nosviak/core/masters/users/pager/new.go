package pager

import (
	"Nosviak/core/masters/sessions"
	"Nosviak/core/models/configs/toml"
	"strconv"
	"strings"

	"github.com/alexeyco/simpletable"
)

type Pager struct {
	//this object is operated by a external operator
	//the position of this is located in the decoration.toml
	Gradient bool

	//stores the name of the screen being viewed
	//this will allow you to single/all disable gradients on tables
	Header string

	//stores the table instance, this will hopefully have the values completely filled
	//meaning we can just display the table without needing to fill it
	Table *simpletable.Table

	//stores the sessions current instance
	//this will store the sessions window size etc
	Session *sessions.Session
}

//creates a new pager instance
func NewPager(Header string, Table *simpletable.Table, session *sessions.Session) *Pager {
	return &Pager{
		//holds the gradient information
		//this allows you to disable gradients globally
		Gradient: Toml.DecorationToml.Gradient.Status,

		//stores the page header
		//meaning we can use this to check if the choice has access
		Header: Header,

		//stores the table information
		//holds the rows using inside the structure
		Table: Table,

		//stores information about the current sessions
		//meaning it stores the current window size etc
		Session: session,
	}
}

//executes the pager correctly and safely 
func (pg *Pager) ExecutePager() error {
	width := pg.GetLongestRow(strings.Split(pg.Table.String(), "\n"))
	if width > pg.Session.TerminalSize.W {
		pg.Session.Write([]byte("\x1b[8;"+strconv.Itoa(pg.Session.TerminalSize.H)+";"+strconv.Itoa(width)+"t"))
	}
	if PagerAssistance(pg.Session, len(pg.Table.Body.Cells)) {
		return pg.newDefault()
	} else {
		return pg.NewPager()
	}
}