package pager

import (
	"Nosviak/core/models/configs/toml"
	"Nosviak/core/models/util"
	"Nosviak/core/tools/gradient"
	"strings"
)

//renders the table without any pager functionality
//this will perform all checks before executing and make sure its safe
func (pg *Pager) newDefault() error {


	//gets the needed information
	//this will get the query style from the ini made for that file
	Default, IgnoreHeader, err := GetQueryStyle(pg.Header+".ini")
	if err != nil {
		return err
	}

	//sets the style to the correct type
	pg.Table.SetStyle(Default)


	//checks that gradient can be performed on this table correctly
	if pg.Gradient && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, pg.Header) {

		//removes all gradient options from the header of the table
		if IgnoreHeader {
			//completely removes it
			pg.Table.Header.Cells = IgnoreHeaders(pg.Table.Header.Cells)
		}

		//performs the gradient
		//this will correctly execute the gradient on the object safely
		source, err := gradient.CreateCurve(strings.Split(pg.Table.String(), "\n")).PerformGradient()
		if err != nil {
			return err
		}

		//writes the table to the channel correctly
		if _, err := pg.Session.Write([]byte(source+"\r\n")); err != nil {
			return err
		}

		return nil
	} else {

		//writes the table to the channel correctly
		//this will make sure all strings are safe before printing them to the host
		if _, err := pg.Session.Write([]byte(strings.ReplaceAll(pg.Table.String(), "\n", "\r\n")+"\r\n")); err != nil {
			return err
		}

		return nil
	}

}