package pager

import (
	Toml "Nosviak/core/models/configs/toml"
	"Nosviak/core/models/util"
	"strings"

	"github.com/alexeyco/simpletable"
	"Nosviak/core/tools/gradient"
)

//renders the pager instance correctly
//this will start the pager correctly on the screen safely
func (method *Pager) NewPager() error {

	//correctly sets the table type to the chosen table type safely
	method.Table.SetStyle(simpletable.StyleCompactLite)

	//stores the source in an array properly and safely
	//what we will use to access the source during the pager events
	var modifiedSource []string = make([]string, 0)

	//gets the needed information
	//this will get the query style from the ini made for that file
	_, IgnoreHeader, err := GetQueryStyle(method.Header+".ini")
	if err != nil {
		return err
	}

	//checks that gradient is enabled
	//and that the table has been whitelisted for the gradientClient
	if method.Gradient && util.NeedleHaystack(Toml.DecorationToml.Gradient.CommissionedTables, method.Header) {
		
		//checks if the client has enabled the ignoreheader
		//stops the header of the tables from being apart of the gradient
		if IgnoreHeader {
			//correctly sets all the headers to being ignored
			method.Table.Header.Cells = IgnoreHeaders(method.Table.Header.Cells)
		}

		//performs the gradient on the chosen source
		//this will push the entire source through the gradient client
		source, err := gradient.CreateCurve(strings.Split(method.Table.String(), "\n")).PerformGradient()
		if err != nil {
			return err
		}

		//splits the source via line by line
		//this allows us to split the source safely and properly
		modifiedSource = strings.Split(source, "\r\n")
	} else {
		//splits the table string line by line
		//this allows us to access it properly and safely
		modifiedSource = strings.Split(method.Table.String(), "\n")
	}

	//writes one clear to the screen once correctly
	method.Session.Write([]byte("\033c"+method.RenderHeader(modifiedSource)))

	//pager's current position
	var PagerPosition int = 0

	//loops through all keypresses
	//the exit key will be set to esc
	//when that key press is detected we will completely exit from the forLoop
	for {
		//renders the table in position
		//this will force it to rerender every keypress safely
		method.RenderTable(PagerPosition, modifiedSource)

		//creates a buffer for saving keypresses
		Buffer := make([]byte, 1)
		//reads from the channel tunnel safely
		_, err := method.Session.Channel.Read(Buffer)
		if err != nil {
			return err
		}

		switch Buffer[0] {

		case 113, 81:
			var sourceSection string = strings.Split(strings.Join(method.Session.Written, ""), "\033c")[len(strings.Split(strings.Join(method.Session.Written, ""), "\033c"))-2]

			method.Session.Write([]byte("\033c"+sourceSection))
			return nil

		//65: up arrow key press detected
		//119: W key press detected properly
		case 65, 119, 87:
			//stops the user from being able to go subzero
			if PagerPosition - 1 < 0 {
				continue
			}

			PagerPosition--

		//66: down arrow key press detected
		//115: S key press detected properly
		case 66, 115, 83:
			//stops the user from being able to drop more than allowed amount
			if PagerPosition + method.Session.TerminalSize.H > len(method.Table.Body.Cells) {
				continue
			}

			PagerPosition++

		}

	}
}


func (method *Pager) RenderHeader(source []string) string {
	return source[0] + "\r\n" + source[1] + "\r\n"
}