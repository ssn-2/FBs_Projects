package ranks

import (
	"Nosviak/core/database"
)

//basic command access system
//this checks if the user can access a certain command
//this is used to make sure users can execute certain commands and stopped them from other commands
func AccessCommand(cWants []string, user *database.User) (bool, error) {
	//checks if the length of roles is equal or less than 0
	//or if the array is equal to a nil pointer and we will return true
	if len(cWants) <= 0 || cWants == nil {
		return true, nil
	}

	//gets the ranks from the database
	//this is mainly used so we can access ranks
	dec, err := UnravelRanks(user)
	if err != nil {
		return false, err
	}
	
	//ranges through all the ranks inside the array above
	for _, Wanted := range cWants {

		//checks if the user can't access this command
		//this will correctly check if the user has access
		if CanAccess(Wanted, dec) {
			//the user can access that command
			//returns true so the parent function knows we can execute
			return true, nil
		}
	}

	//the user can't access that command
	//the parent function will now know that we can execute
	return false, nil
}