package ranks

type Ranks struct {
	// stores all the ranks a user has
	// this is stored inside an array so it can store many
	MyRanks []Rank `json:"ranks"`
}

//structure to hold role information
type Rank struct {
	//stores the entry of the role correctly
	Name string `json:"name"`

	//stores if the user has that role currently
	Has bool `json:"has"`
}