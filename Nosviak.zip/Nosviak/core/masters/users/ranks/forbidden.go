package ranks

//this function here will remove ranks
//it will either check if it exists or if it does it will set Has to false
func ForbidRole(Role string, Ranks []Rank) ([]Rank, error) {

	//checks if the rank already exists
	//if this is returned as false, we can return nil
	//as there wont be nothing todo
	Has, Pos := AlreadyExists(Role, Ranks)

	//checks if the user has the rank
	//this is so we can check if we need todo anything
	if !Has {
		//returns the default settings as we don't need todo anything
		return Ranks, nil
	}

	//removes the user from having the rank
	//as we have rank history fitted, we want to be able to see what ranks this user has had
	Ranks[Pos].Has = false


	//returns nil as no error has happened
	//this is main error handling inside the function
	return Ranks, nil
}