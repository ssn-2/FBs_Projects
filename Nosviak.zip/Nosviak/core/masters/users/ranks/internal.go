package ranks

import Template "Nosviak/core/deployment/template"

/*
	- this part stores information about our internal roles
*/


var Internal map[string]*Template.NewRank = map[string]*Template.NewRank{


	//admin base role
	//stores information about the admin role
	"admin" : &Template.NewRank{
		Status: true,
		//only admins may create admins or delete them
		PermissionsPromote: make([]string, 0),
		Description: "admin, the managers of nosviak",
		IgnoreBlacklist: false,
		Signature: "A",
		Decoration: 10,
		Charatercolour: 16,
	},

	"moderator" : &Template.NewRank{
		Status: true,
		//this role can only be given my admins
		PermissionsPromote: []string{"admin"},
		Description: "moderator, the operators of nosviak",
		IgnoreBlacklist: false,
		Signature: "M",
		Decoration: 105,
		Charatercolour: 16,
	},

	"reseller" : &Template.NewRank{
		Status: true,
		//this role can only be given my admins
		PermissionsPromote: []string{"admin", "moderator"},
		Description: "reseller, the seller's of nosviak",
		IgnoreBlacklist: false,
		Signature: "R",
		Decoration: 9,
		Charatercolour: 16,
	},

	"banned" : &Template.NewRank{
		Status: true,
		//this role can only be given my admins
		PermissionsPromote: []string{"admin"},
		Description: "banned, the criminal's of nosviak",
		IgnoreBlacklist: false,
		Signature: "B",
		Decoration: 27,
		Charatercolour: 15,
	},
}

//checks if the rank is classed as internal
func CheckRankInternal(name string) bool {
	//ranges through all the internal ranks
	for rankName, _ := range Internal {

		//compares the 2 ranks
		//this will comparet the ranks
		if rankName == name {
			return true
		}
	}

	return false
}

