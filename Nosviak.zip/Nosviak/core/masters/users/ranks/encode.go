package ranks

import (
	"encoding/base64"
	"encoding/json"
)

//takes all the ranks passed into this function
//every rank passed into this function will be encoded and marshaled into json
func EncodeString(Has []Rank) (string, error) {

	//creates a new rank object
	//this will store the rank information
	var Rank *Ranks = &Ranks{

		//saves the ranks array into the correct col
		//array of all ranks the user will have access to
		MyRanks: Has,
	}


	//converts the current the structure into the array
	//this is so it can be stored in mysql correctly and safely
	Value, err := json.Marshal(Rank)
	if err != nil {
		return "", err
	}

	//converts the correct value into the string
	return base64.RawURLEncoding.EncodeToString(Value), nil
}