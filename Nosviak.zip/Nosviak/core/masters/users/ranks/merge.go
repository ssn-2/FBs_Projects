package ranks


import "Nosviak/core/models/configs/toml"


//correctly merges the toml map with the internal ranks
//meaning we can display the ranks inside the cnc correctly
func MergeToml() {

	//ranges through the internal map
	for key, val := range Internal {
		//saves the current internal role into the map
		Toml.RanksToml.Ranks[key] = *val
	}
}