package ranks

import (
	"strings"
)

//this is used to check if the user can execute
//main function for this would be checking if the user has access to a command
func CanAccess(rank string, Has []Rank) bool {

	//ranges through all the ranks the user has
	for _, r := range Has {

		//compares the strings in a lower format correctly
		//this will make sure the role which is currently being passed is equal to the other role
		if strings.EqualFold(strings.ToLower(rank), strings.ToLower(r.Name)) {
			//the user can execute this
			//this will be returned so the user can execute
			return true
		}
	}
	//the user can't access that command
	//this is so the function knows the user can't execute it
	return false
}