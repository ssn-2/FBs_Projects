package ranks

import (
	"Nosviak/core/database"
	"errors"
	"strings"
)

//awards the user a new rank
//this can be used to give a user a certain rank
func AwardRank(ranks []Rank, user *database.User, name string) ([]Rank,error) {

	//checks if the rank already exists
	//if the role exists we will exit it so its active
	if exists, pos := AlreadyExists(name, ranks); exists {
		rank := ranks[pos]
		if &rank == nil {
			return make([]Rank, 0) ,errors.New("rank was found but equal to nil pointer")
		}

		//sets so the 
		rank.Has = true

		return ranks, nil
	}

	ranks = append(ranks, Rank{
		Name: name,
		Has: true,
	})

	return ranks, nil
}


//checks if the user already has the rank
//this will return the information and the position
func AlreadyExists(name string, ranks []Rank) (bool, int) {

	//ranges through the array of ranks
	for pos, rank := range ranks {

		//compares the two rank names
		//if they equal the same we will return true and the position
		if strings.EqualFold(strings.ToLower(rank.Name), strings.ToLower(name)) {
			//returns true and the position it exsits in
			return true, pos
		}
	}

	//returns false and nil as the rank couldn't be found
	return false, -1
}