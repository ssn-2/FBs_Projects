package ranks

import (
	"Nosviak/core/database"
	"encoding/base64"
	"encoding/json"
)

//takes the incoming user information, ide the uToken & the userRanks
//this will take the incoming string and convert it into an array of all roles the user has
func UnravelRanks(user *database.User) ([]Rank, error) {

	//correctly merges the toml map with this
	MergeToml()

	//decodes the incoming role string to the raw string
	//removes any encoding on the string correctly
	Raw, err := base64.RawURLEncoding.DecodeString(user.Roles)
	if err != nil {
		return make([]Rank, 0), err
	}

	//stores the rank structure
	//this is only used temporarily
	var Ranks Ranks

	//decodes the incoming json structure
	//converts the string back into the []Rank structure
	if err := json.Unmarshal(Raw, &Ranks); err != nil {
		return make([]Rank, 0), err
	}

	//compares the ranks token to the users token
	//both should equal the same output safely
	// if Ranks.UserToken != user.UserToken {
	// 	return make([]Rank, 0), errors.New("ranks: EOF* invaild uToken")
	// }

	//what we will save the ranks into
	//this is returned at the end of the interum
	var ContinueRanks []Rank = make([]Rank, 0)

	//ranges through all the ranks on the users arrays
	for _, currentRank := range Ranks.MyRanks {

		//checks if the users rank is active
		if currentRank.Has {
			//saves the current rank into the array
			ContinueRanks = append(ContinueRanks, currentRank)

			//loops again
			continue
		}

		//loops again
		continue
	}

	//returns the functions output correctly
	return ContinueRanks, nil
}