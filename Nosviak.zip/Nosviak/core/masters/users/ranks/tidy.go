package ranks

import (
	"Nosviak/core/deployment/template"
	"Nosviak/core/models/configs/toml"



	"strconv"
	"strings"
)

//this will correctly make a simple string
//this is used for creating a decorated role string storing all roles
func InternalDecorate(CommandWants []string, gradient bool) string {

	//correctly merges the maps safely
	//this will completetly sync the ranks correctly
	MergeToml()

	//stores an array of ranks
	//this allows us to store the ranks inside an aray
	var Creative []string = make([]string, 0)

	//ranges through all ranks correctly
	//all ranks the commands want will be for looped through
	for _, RankName := range CommandWants {
		//gets the correct rank information
		Rank := ResolveRank(RankName)
		if Rank == nil || !Rank.Status {
			continue
		}

		//checks if the instance has gradient active
		if gradient {
			//correctly saves the rank into the array
			Creative = append(Creative, "*\x1b[48;5;"+strconv.Itoa(Rank.Decoration)+"m \x1b[38;5;16m"+strings.Split(Rank.Signature, "")[0]+" \x1b[0m*")
			continue
		}
		//correctly saves the rank into the array
		Creative = append(Creative, "\x1b[48;5;"+strconv.Itoa(Rank.Decoration)+"m \x1b[38;5;16m"+strings.Split(Rank.Signature, "")[0]+" \x1b[0m")
	}

	//returns all the ranks we got in a string split each slice by a space
	return strings.Join(Creative, " ")
}

//this will make a simple string
//this will be able to be stored inside a table
//meaning you can view your ranks in a much easy fashion
func CompileRanks(R []Rank, gradient bool) (string) {

	//correctly merges the maps safely
	MergeToml()


	var Creative []string = make([]string, 0)
	
	//gets all possible active ranks
	Possible := GetAllActiveRanks()

	//ranges through all possible ranks
	for _, Rank := range R {
	
		//checks if the user has the rank
		if !CheckActive(Rank.Name) || !Rank.Has {
			//saves the rank without a name into the string correctly anyway
			Creative = append(Creative, "   ")
			continue
		}


		RK := ResolveRank(Rank.Name)
		if RK == nil {
			//saves the rank without a name into the string correctly anyway
			Creative = append(Creative, "   ")
			continue
		}

		//checks if the instance has gradient active
		if gradient {
			//correctly saves the rank into the array
			Creative = append(Creative, "*\x1b[48;5;"+strconv.Itoa(RK.Decoration)+"m \x1b[38;5;"+strconv.Itoa(RK.Charatercolour)+"m"+strings.Split(RK.Signature, "")[0]+" \x1b[0m*")
			continue
		}
		//correctly saves the rank into the array
		Creative = append(Creative, "\x1b[48;5;"+strconv.Itoa(RK.Decoration)+"m \x1b[38;5;"+strconv.Itoa(RK.Charatercolour)+"m"+strings.Split(RK.Signature, "")[0]+" \x1b[0m")

	}

	if len(Creative) < Possible {
		BiggerBy := Possible - len(Creative)

		Creative = append(Creative, AddFields(BiggerBy)...)
	}

	return strings.Join(Creative, " ")
}

//adds another slice into the array
//this means we can easily view them
func AddFields(f int) []string {

	//we will store our information inside this array
	var Storage []string = make([]string, 0)

	//ranges until the query is met
	for Pos := 0; Pos < f; Pos++ {
		Storage = append(Storage, "   ")
	}

	//returns the array
	return Storage
}

// this will correctly count how many ranks can be possibly given to a user
// this is so we can calculate how much space we will need
func GetAllActiveRanks() (int) {
	var Active int = 0

	//rankes through all the ranks inside the file
	for _, rank := range Toml.RanksToml.Ranks {

		//checks if the rank is active
		if rank.Status {
			//adds an additonal rank and continues
			Active++
			continue
		}
	}

	//returns the active int
	return Active
}

//check if the rank being passed is active
//meaning the system can detect when a rank isn't active
func CheckActive(name string) bool {

	//ranges through all ranks inside the file
	for Name, Rank := range Toml.RanksToml.Ranks {

		//correctly compares the to rank names and checks if its active
		if strings.EqualFold(strings.ToLower(Name), strings.ToLower(name)) && Rank.Status {
			return true
		}
	}

	//as the rank isn't active
	return false
}

//correctly takes the name and trys to find it in the map
//this is so we can get information about the rank and other stuff aswell
func ResolveRank(name string) *Template.NewRank {

	//ranges through the map looking for the rank
	for Name, Rank := range Toml.RanksToml.Ranks {

		//correctly compares the to rank names and checks if its active
		if strings.EqualFold(strings.ToLower(Name), strings.ToLower(name)) && Rank.Status {
			return &Rank
		}
	}

	return nil
}
