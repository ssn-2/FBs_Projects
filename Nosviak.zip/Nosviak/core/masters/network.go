package masters

import (
	"Nosviak/core/database"
	"Nosviak/core/deployment"
	"Nosviak/core/models/configs/json"
	"encoding/binary"
	"errors"
	"io/ioutil"
	"path/filepath"

	"golang.org/x/crypto/ssh"
)

//intends to start the new listener
//used to safely start the ssh listener correctly
func NewNetwork() error {


	System := ssh.ServerConfig{

		PasswordCallback: func(connection ssh.ConnMetadata, password []byte) (*ssh.Permissions, error) {

			//trys to fetch the users details from the database
			usr, err := database.Container.GetUser(connection.User())
			if err != nil || usr == nil {
				//checks if there is an err
				if err != nil {
					return nil, err
				}
				//returns the err as the login doesn't exist
				return nil, errors.New("invaild login attempt for '"+connection.User()+"' from '"+connection.RemoteAddr().String()+"'")
			}

			//trys to compare the passwords
			if usr.Password != database.Password(string(password)) {
				return nil, errors.New("invaild password given for '"+connection.User()+"' from '"+connection.RemoteAddr().String()+"'")
			}

			//trys to log the login to the database correctly
			if err := database.Container.NewLogin(usr.Username, string(connection.ClientVersion()), connection.RemoteAddr().String()); err != nil {
				return nil, err
			}

			return nil, nil
		},

		//configures the ssh server version
		ServerVersion: "SSH-2.0-OpenSSH_8.6p1 Nosviak-"+deployment.Version,
	}

	//sees if the pre authentication banner is enabled
	if json.ContentConfig.Masters.PreAuthentication.Enabled {
		//saves the banner callback into the system correctly
		System.BannerCallback = func(conn ssh.ConnMetadata) string {
			//returns our custom callBack message
			return json.ContentConfig.Masters.PreAuthentication.Message
		}
	}


	//checks if the system wants a no client authentication option
	if !json.ContentConfig.Masters.Authentication.Passwd {
		System.NoClientAuth = true
	}

	//sets the maxTries a user can hace
	System.MaxAuthTries = json.ContentConfig.Masters.Authentication.MaxTries


	//reads the file from the assets dir
	system, err := ioutil.ReadFile(filepath.Join(deployment.Assets, json.ContentConfig.Masters.Encryption.RsaPrivate))
	if err != nil {
		return err
	}

	//parses the key safely
	signature, err := ssh.ParsePrivateKey(system)
	if err != nil {
		return err
	}

	//saves the key into the structure
	System.AddHostKey(signature)

	//starts the listener correctly
	return NewListener(System)
}


func ParseWinDifferent(b []byte) (uint32, uint32) {
	w := binary.BigEndian.Uint32(b) //detects the windows length of the binary
	h := binary.BigEndian.Uint32(b[4:]) //detects how tall the window is
	return w, h
}