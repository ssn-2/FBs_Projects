package masters

import (
	"fmt"
	"net"
	"time"

	"golang.org/x/crypto/ssh"

	"Nosviak/core/database"
	"Nosviak/core/masters/sessions"
	"Nosviak/core/masters/views"
	"Nosviak/core/models/configs/toml"
)

//handles the incoming socket correctly
func HandleSocket(conn net.Conn, server *ssh.ServerConfig) {

	//trys to open a new ssh connection correctly
	Connection, chans, reqs, err := ssh.NewServerConn(conn, server)
	if err != nil {
		fmt.Println(err.Error())
		return
	}
		
	fmt.Println("New SSH connection from "+conn.RemoteAddr().String()+" has authenticated into "+Connection.User())


	//discards the requests inside a goroutine
	go ssh.DiscardRequests(reqs)

	//ranges through the channels
	for newChannel := range chans {

		//validates the incoming connection channel type
		if newChannel.ChannelType() != "session" {
			//rejects invaild channel types
			newChannel.Reject(ssh.UnknownChannelType, "UnknownChannelType")
			return
		}

		//accepts the current channel type
		channel, request, err := newChannel.Accept()
		if err != nil {
			return
		}

		//creates the main id form
		//this shall be used in each session which is made
		SessionInitialised := time.Now()

		//starta a go routine ranges through the reqs
		go func(in <-chan *ssh.Request) {
			for req := range in {
				switch req.Type {
				case "pty-req":
					req.Reply(true, nil)
					continue
				case "shell":
					req.Reply(true, nil)
					continue
				case "window-change":

					//parses the payload request
					Width, Height := ParseWinDifferent(req.Payload)

					//checks if the session still exists
					//if not we will kill the for loop and close
					if sessions.Sessions[SessionInitialised.Unix()] == nil {
						return
					}
					//applys the window sizes correctly and safely
					sessions.Sessions[SessionInitialised.Unix()].TerminalSize.W = int(Width)
					sessions.Sessions[SessionInitialised.Unix()].TerminalSize.H = int(Height)
				}	
			}
		}(request)


		//prerequest title will be set here
		if _, err := channel.Write([]byte("\033]0;"+Toml.TerminalToml.Terminal.TitleStartup+"\007")); err != nil {
			return
		}

		//trys to get the user from the database
		user, err := database.Container.GetUser(Connection.User())
		if err != nil {
			return
		}

		//creates a new session structure
		session := sessions.MakeSession(user, channel, Connection, SessionInitialised)
		
		//makes a session for the new instance
		if err := session.NewSession(); err != nil {
			return
		}

		//executes the home menu
		err = views.NewHome(session)
		fmt.Println(err.Error())
		//deletes the session from the map if its not already been deleted
		delete(sessions.Sessions, session.Connected.Unix())
		
		//error handles
		if err != nil {
			return
		}
	}
}