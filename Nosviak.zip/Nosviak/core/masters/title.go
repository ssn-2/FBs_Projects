package masters

import (
	"fmt"
	"time"

	"Nosviak/core/masters/sessions"
	"Nosviak/core/models/configs/toml"
	"Nosviak/core/models/views"
)


//creates a new title worker instance
//updates the title for each session every X amount of time
func TitleWorker() error {

	//for loops the title rotations
	//this will for loop until the instance is complete
	for {

		//ranges through the sessions
		for _, session := range sessions.Sessions {

			//executes the title, this can be different for each user
			//this will execute under a per user basis on each rotation
			if err := views.NewDTX(session.Title, session.NonWrite).Template(session, session.Channel); err != nil {
				//renders an error which has happened when trying to render the information splash
				//this will render when an error has been caught
				fmt.Printf("[TitleWorker] issue for %s, reason: `%s`\r\n", session.User.Username, err.Error())
				continue
			}
		}

		//sleeps for the duration selected
		//this will sleep every title rotation for the duration in the terminal.toml
		time.Sleep(time.Duration(Toml.TerminalToml.Terminal.TitleTicks) * time.Second)
	}
}