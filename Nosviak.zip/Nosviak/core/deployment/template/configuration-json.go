package Template 

//stores the structure used in the configuration (config.json) stores in here for easy finding
type ConfigurationJson struct {
	Database struct {
		Host     string `json:"host"`
		Username string `json:"username"`
		Password string `json:"password"`
		Name     string `json:"name"`
	} `json:"database"`
	Masters struct {
		Masters           string `json:"masters"`
		PreAuthentication struct {
			Enabled bool   `json:"enabled"`
			Message string `json:"message"`
		} `json:"pre_authentication"`
		Authentication struct {
			Passwd   bool `json:"passwd"`
			MaxTries int  `json:"maxTries"`
		} `json:"authentication"`
		Encryption struct {
			ConcurrentRandom bool   `json:"concurrentRandom"`
			RsaPrivate       string `json:"rsaPrivate"`
		} `json:"encryption"`
	} `json:"masters"`
}