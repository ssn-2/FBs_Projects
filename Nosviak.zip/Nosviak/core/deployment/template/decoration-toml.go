package Template


type Decoration struct {
	Gradient struct {
		Status                   bool          `toml:"status"`
		CommissionedTables       []string      `toml:"commissionedTables"`
		GradientAxis             []string      `toml:"gradientAxis"`
		IgnoredTypes             []string `toml:"ignoredTypes"`
		IgnoredStrings           []string      `toml:"ignoredStrings"`
		IgnoredReplacementColour string        `toml:"ignoredReplacementColour"`
	} `toml:"Gradient"`
}