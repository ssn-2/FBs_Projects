package Template


type Instance struct {
	Default struct {
		AppName string `toml:"appName"`
	} `toml:"default"`
}