package Template 


type RankToml struct {
	Ranks  map[string]NewRank `toml:"ranks"`
}

type NewRank struct {
	Status             bool     `toml:"status"`
	PermissionsPromote []string `toml:"permissionsPromote"`
	Description        string   `toml:"description"`
	IgnoreBlacklist    bool     `toml:"ignoreBlacklist"`
	Signature          string   `toml:"signature"`
	Decoration         int      `toml:"decoration"`
	Charatercolour     int      `toml:"charatercolour"`
}