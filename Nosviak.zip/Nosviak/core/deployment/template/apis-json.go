package Template


type Apis struct {
	Methods []Method `json:"methods"`
}

type Method struct {
	Access struct {
		EqualOrAbove bool     `json:"EqualOrAbove"`
		Access       []string `json:"access"`
	} `json:"access"`
	Description string   `json:"description"`
	Name        string   `json:"name"`
	Targets     []string `json:"targets"`
	DefaultPort int      `json:"defaultPort"`
}