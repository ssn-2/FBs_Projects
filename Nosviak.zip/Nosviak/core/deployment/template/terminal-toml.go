package Template 

//stores the terminal toml information
type TerminalToml struct {
	Terminal struct {
		TitleStartup     string `toml:"TitleStartup"`
		TitleTicks       int    `toml:"TitleTicks"`
		PromptDisconnect int    `toml:"PromptDisconnect"`
	} `toml:"terminal"`
}