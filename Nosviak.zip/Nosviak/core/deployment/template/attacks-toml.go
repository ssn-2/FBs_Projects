package Template


type AttacksToml struct {
	Attacks struct {
		KvPointer   string `toml:"kvPointer"`
		Timeout     int    `toml:"timeout"`
		Measurement string `toml:"measurement"`
	} `toml:"Attacks"`
}