package deployment


const (
	//stores the systems current dev version
	//this allows for easier distrobution of the product
	Version string = "v0.1"

	//stores the main folder which **ALL** assets will be loaded from
	//this is mainly used for everything which is loaded from an external configuration
	Assets string = "assets"

	//stores the central views dir
	//mainly used so we can easily render any object from the array
	View string = "views"

)