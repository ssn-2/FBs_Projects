package gradient 


import (
	"Nosviak/core/models/configs/toml"
)

/*
	- implementation of `pazdano's` gradient client
	- gradient client presets etc will be loaded from the decoration.toml 
*/


//creates a new instance
func NewFeed(src []string) *Feed {
	return &Feed{
		Source: src,
		//saves the correct ignored types into a string structure
		IgnoredCharater: Toml.DecorationToml.Gradient.IgnoredStrings,
		IgnoredTypes: Toml.DecorationToml.Gradient.IgnoredTypes,
	}
}

//structure which will store the information inside of
type Feed struct {
	//stores the text being inputed into the function
	//this will be split on a line by line basis meaning we can range through it easier
	Source []string

	//stores all the charaters we will be ignoring
	//this allows the client to have more configuration of how there tables look
	IgnoredCharater []string

	//stores all types which we will ignore
	//this allows us to block certain looks from the table
	IgnoredTypes []string
}