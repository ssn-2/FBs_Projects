package gradient

import (
	Toml "Nosviak/core/models/configs/toml"
	"strings"
	"unicode/utf8"

	Colour "github.com/mazznoer/colorgrad"
)


type NewCurve struct {
	//stores all the colours which will be passed into the engine
	//all colours placed in here will be validated
	Colours []string

	//most likely we will take this from the feed tool
	//meaning tagWhitelisting will be in play correctly
	Source []string
}


//creates a new curve, makes a new method meaning we can access further information
func CreateCurve(src []string) *NewCurve {
	return &NewCurve{
		//sets the curve to the default axis set inside the file
		Colours: Toml.DecorationToml.Gradient.GradientAxis,

		Source: src,
	}
}

//executes the gradient cli
//meaning anything passed in from here will have the gradient performed on it
//this function will auto apply the feed engine on it
func (crv *NewCurve) PerformGradient() (string, error) {

	crv.Colours = Toml.DecorationToml.Gradient.GradientAxis

	//creates a new feed correctly
	//this will ignore anything the user has set it too
	correction, err := NewFeed(crv.Source).Correction()
	if err != nil {
		return "", err
	}

	//splits the correction properly
	crv.Source = strings.Split(correction, "\r\n")

	//ranges through all colours passed into the function
	for Pos, Colour := range crv.Colours {

		Colour = strings.Trim(strings.Trim(Colour, ")"), "rgb(")


		//trys to validate the rgb code
		//this will make sure its valid and can be used
		if err := ValidateRGB(Colour); err != nil {
			return "", err
		}

		//saves the current position as a modified option
		crv.Colours[Pos] = "rgb(" + Colour + ")"
		continue
	}

	//builds the new gradient instance 
	//this will also return an error is rgb colours are invalid
	curve, err := Colour.NewGradient().HtmlColors(crv.Colours...).Build()
	if err != nil {
		return "", err
	}

	//temp object storage for our object
	var mainContainer []string = make([]string, 0)
	

	//ranges through the source, Line by Line
	for pos, Line := range crv.Source {

		//we will ignore any blank lines
		if utf8.RuneCountInString(Line) <= 0 {
			continue
		}

		var MyLine []string = make([]string, 0)

		//information if we are current ignoring charaters
		//this is how we can configure our information
		var Ignoring bool = false

		for Position := 0; Position < utf8.RuneCountInString(Line); Position++ {

			//stores the current object that we are rending
			Object := strings.Split(Line, "")[Position]

			//checks if the current charater is the ignore charater
			if strings.Contains(Object, "*") {
				//toggles gradients either on/off
				Ignoring = !Ignoring
				//as this current charater is a declare char
				//we will now ignore that charater
				if pos <= 0 {
					//adjusts the spaces for the header
					MyLine = append(MyLine, "\x1b"+Toml.DecorationToml.Gradient.IgnoredReplacementColour+" ")
				} else {
					//revets back to normal cell
					MyLine = append(MyLine, "\x1b"+Toml.DecorationToml.Gradient.IgnoredReplacementColour+"")
				}
				
				//and loop again
				continue
			}

			//checks if the current charater is the ignore charater
			if strings.Contains(Object, "+") {
				//toggles gradients either on/off
				Ignoring = !Ignoring

				MyLine = append(MyLine, "\x1b"+Toml.DecorationToml.Gradient.IgnoredReplacementColour+" ")

								
				//and loop again
				continue
			}

			//checks if we are currently ignoring our charater we are scanning
			if Ignoring {
				//appends the current object if we are ignoring
				MyLine = append(MyLine, Object)
				//loops again
				continue
			}

			var ColoursGotton []RGB = make([]RGB, 0)

			//proceeds with the gradient with the params in a for loop safely
			for _, Colour := range curve.ColorfulColors(uint(GetLongestQuery(crv.Source))) {
				//converts the current object into a rgb colour value
				Value, err := Hex2RGB(Hex(Colour.Hex()[1:]))
				if err != nil {
					return "", err
				}

				//saves the rgb value into the array correctly
				ColoursGotton = append(ColoursGotton, Value)
			}

			//correctly saves the object into the array safely
			MyLine = append(MyLine, Fade(Object, ColoursGotton[Position]))
			//completely refreshes the array
		}

		//saves the current line into the array
		mainContainer = append(mainContainer, strings.Join(MyLine, ""))
	}

	return strings.Join(mainContainer, "\r\n"), nil
}