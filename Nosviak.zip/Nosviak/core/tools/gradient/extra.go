package gradient

import (
	"fmt"
	"strconv"
)

type Hex string

type RGB struct {
	Red   uint8
	Green uint8
	Blue  uint8
}


func Hex2RGB(hex Hex) (RGB, error) {
	var rgb RGB
	values, err := strconv.ParseUint(string(hex), 16, 32)

	if err != nil {
		return RGB{}, err
	}

	rgb = RGB{
		Red:   uint8(values >> 16),
		Green: uint8((values >> 8) & 0xFF),
		Blue:  uint8(values & 0xFF),
	}

	return rgb, nil
}

func Fade(letter string, color RGB) string {
	return fmt.Sprintf("\x1b[38;2;%d;%d;%dm%s\033[0m", color.Red, color.Green, color.Blue, string(letter))
}