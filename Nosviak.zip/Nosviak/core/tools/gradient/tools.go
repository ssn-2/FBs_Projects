package gradient

import (
	"errors"
	"strconv"
	"strings"
	"unicode/utf8"
)

//validates the rgb code which will be passed into this function
//this will simply make sure the rgb code can be used correctly inside the gradient
//avoids future errors invalid RGB codes could cause
func ValidateRGB(rgb string) error {

	//splits the string by the commas found
	//before we split we will remove all spaces from the string
	Slices := strings.Split(strings.ReplaceAll(rgb, " ", ""), ",")

	//checks the length, possible missing RGB colours
	//if the length isn't validate we will return an err code
	if len(Slices) < 3 {
		//returns the err code
		return errors.New("rgb validation failed: missing slices")
	}

	//ranges through all the slices inside the array
	//we will try to convert all strings into integers to make sure they are ints
	for pos, Slice := range Slices {

		//checks that we can convert the object correctly
		if _, err := strconv.Atoi(Slice); err != nil {
			//returns the correct err code, we do skip one position as it provides a more easier position for people to find
			return errors.New("rgb validation failed: failed at position, "+strconv.Itoa(pos+1))
		}

		//loops again
		continue
	}

	return nil
}


//this function will get the gradients longest line
//this will allow the tool to calculate the longest line in the array
func GetLongestQuery(Lines []string) int {
	var Largest int = 0

	//ranges through the lines of the file
	for _, Line := range Lines {

		//checks if the current line is the longest line
		if utf8.RuneCountInString(Line) > Largest {
			Largest = utf8.RuneCountInString(Line)
		}
	}

	//returns the largest charater
	return Largest
}