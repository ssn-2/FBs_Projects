package gradient

import (
	"Nosviak/core/models/configs/toml"
	"Nosviak/core/models/util"

	"strconv"
	"strings"
)

//this will complete the structures request
//this is the main control hub for all gradients which will be performed
func (fd *Feed) Correction() (string, error) {

	//ranges through the source line by line
	for position, Line := range fd.Source {

		//comparse the line meaning scanning for ignored types/strings
		Line, err := fd.comparseLine(Line)
		if err != nil {
			return "", err
		}

		//updates the current scanned line to the newer version
		fd.Source[position] = Line
		
	}

	//joins the string line by line
	return strings.Join(fd.Source, "\r\n"), nil
}


//executes the line by checking the types
//this will allow you to execute the system and whitelist certain types
func (fd *Feed) comparseLine(line string) (string, error) {
	//an array of strings which the output will be
	var Saves []string = make([]string, 0)

	//ranges through the source by splitting it by its spaces
	for _, subject := range strings.Split(line, " ") {

		//checks if the type of the current object is blacklisted
		//if the object is blacklisted we will suround the object with our ignore tags
		if util.NeedleHaystack(Toml.DecorationToml.Gradient.IgnoredTypes, fd.CheckType(subject)) {
			//saves the object into the array
			Saves = append(Saves, "*"+subject+"*")
			//forces it to look again
			continue
		}

		if util.NeedleHaystack(Toml.DecorationToml.Gradient.IgnoredStrings, strings.ToLower(subject)) {
			//saves the object into the array
			Saves = append(Saves, "*"+subject+"*")
			//forces it to look again
			continue
		}

		//saves the object into the array
		Saves = append(Saves, subject)
		//forces it to look again
		continue
	}


	return strings.Join(Saves, " "), nil
}

//gets the type of the string
//this will check the current section for a type
func (fd *Feed) CheckType(section string) string {

	//checks if the type passed is type integer
	if _, err := strconv.Atoi(section); err == nil {
		return "int"
	}

	//checks if the type is a boolean
	if err := util.AuthenticateBooelean(section); err == nil {
		return "bool"
	}

	//if non above we will revert to type string
	return "string"
}