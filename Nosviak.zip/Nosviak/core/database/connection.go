package database

import (
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"time"

	//driver imports
	_ "github.com/go-sql-driver/mysql"
	//configuration imports
	"Nosviak/core/models/configs/json"
)


type Database struct {
	//stores the contained database for the instance
	contain 		*sql.DB

	//stores the time the database was safely opened
	//used to we can view the database uptime and see an amount of how long the cnc has been
	attachment 		time.Time
}

//stores for everything
var Container *Database = nil

//pushs the instance to try to open/connect with the database server
func PushConnection() (error) {

	//trys to push with the connection to the sql server safely
	instance, err := sql.Open("mysql", json.ContentConfig.Database.Username+":"+json.ContentConfig.Database.Password+"@tcp("+json.ContentConfig.Database.Host+")/"+json.ContentConfig.Database.Name)
	if err != nil {
		return err
	}

	//trys to ping the database
	if err := instance.Ping(); err != nil {
		return err
	}

	//saves the sql seq into the storage var
	Container = &Database{contain: instance, attachment: time.Now()}

	//returns the database structure
	return nil
}

//hashes the password using sha256 encoding
func Password(passwd string) string {
	//returns the string value of the seal from the password
	return hex.EncodeToString(sha256.New().Sum([]byte(passwd)))
}