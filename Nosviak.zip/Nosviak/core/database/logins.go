package database

import (
	"errors"
	"time"
)


type Login struct {
	//stores the date the login request was made
	Date 		int64

	//stores the username which made the request
	Username string

	//stores the ssh client they used to make the request
	Client string

	//stores where they logged in from
	Address string
}

//places a new subject login into the table
func (conn *Database) NewLogin(user string, version string, address string) error {

	//trys to insert the login into the correct tables
	row, err := conn.contain.Query("INSERT INTO `logins` VALUES (?, ?, ?, ?);", time.Now().Unix(), user, version, address)
	//standard err handling
	if err != nil {
		return err
	}

	//closes the table once function is finished
	defer row.Close()
	//returns nil
	return nil
}


//gets all login requests
//this is user specific so it will only get the logins requests for a certain user
func (conn *Database) GetLoginReqs(user string) ([]Login, error) {

	//selects all logins reqeusts from a certain username
	rows, err := conn.contain.Query("SELECT `date`, `user`, `client`, `address` FROM `logins` WHERE `user` = ?", user)
	if err != nil {
		return make([]Login, 0), err
	}

	//closes the rows once the function is finished
	defer rows.Close()


	//stores all logins
	//this will fill up as we scan the rows
	var LoginReqs []Login = make([]Login, 0)

	for rows.Next() {
		//temp storage for the row
		//the row is stored there until we loop again
		var Row Login

		//scans the current row
		err := rows.Scan(&Row.Date, &Row.Username, &Row.Client, &Row.Address)
		if err != nil {
			return make([]Login, 0), err
		}

		//stores the current login request into the array
		LoginReqs = append(LoginReqs, Row)

	}

	return LoginReqs, nil
}

//gets the last login a user performed
func (conn *Database) GetLastLogin(user string) (*Login, error) {

	//gets all the logins reqs a user ever performed
	//this allows us to view more information about the logins
	logins, err := conn.GetLoginReqs(user)
	if err != nil {
		return nil, err
	}

	//checks if there is more than one login displayed
	if len(logins) >= 1 {
		return &logins[len(logins)-1], nil
	}

	return nil, errors.New("EOF")
}