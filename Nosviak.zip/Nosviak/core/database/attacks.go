package database 

import (

)

//stores the attack structure
//this is used to contain information about attacks
type Attack struct {
	//stores the target
	//this is what the attack was pointed towards
	Target string
	//stores the port
	//this is the port on the target the attack was pointed towards
	Port int
	//stores the duration
	//this is the time the attack will last for on attacking
	Duration int
	//stores when the attack was created in unixtime
	Created int64
	//stores when the attack is due to end in unixtime
	Finish int64
	//stores the user who launched the attack
	Username string
}

// (conn *Database) LogAttack(username string, Target string, Port int, Duration int)

//returns an array of how many times the user has attacked that target
//this will be used when trying to view who has attacked what target
func (conn *Database) QueryAttacks(query string) ([]Attack, error) {

	//pushes for the query in the database
	//this will get all the attacks the user has launched for that target
	Rows, err := conn.contain.Query(query)

	//err handles the query statement
	//makes sure the statement has been performed
	if err != nil {
		//returns the error which was found
		return make([]Attack, 0), err
	}

	defer Rows.Close()

	//creates an object
	//this object will store all possible attacks
	var Attacks []Attack = make([]Attack, 0)

	for Rows.Next() {
		//temp memory object for the user
		//this will be used to store the attack seq
		var attack Attack

		//scans the current row
		//this will allow us to fill the temp object with the information
		err := Rows.Scan(&attack.Target, &attack.Port, &attack.Duration, &attack.Created, &attack.Finish, &attack.Username)

		//err handles the scan statement
		//makes sure the row has been scanned
		if err != nil {
			//contines to loop again
			continue
		}

		//saves the current row into the storage
		//this will correctly store the entire row into the database
		Attacks = append(Attacks, attack)
	}

	//returns every row we scanned properly
	return Attacks, nil
}