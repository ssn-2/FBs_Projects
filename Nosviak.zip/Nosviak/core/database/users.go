package database

import "errors"

type User struct {
	//stores the users id inside the database
	//the position the user occurs inside the database
	Id int

	//stores the username & the password for the user
	Username, Password, UserToken, Roles string

	MaxTime, Cooldown, Concurrents int
}

//gets the user from the database Table `users`
//a user.Username must be passed into the function so we can find the right user
func (conn *Database) GetUser(user string) (*User, error) {

	//inserts the query into the SQL Database
	row := conn.contain.QueryRow("SELECT `id`, `Username`, `Password`, `UserToken`, `Ranks`, `maxTime`, `cooldown`, `concurrents` FROM `users` WHERE `Username` = ?", user)
	if row.Err() != nil {
		return nil, row.Err()
	}
	//temp storage for the user
	var Instance User

	//scans the row which was found
	if err := row.Scan(&Instance.Id, &Instance.Username, &Instance.Password, &Instance.UserToken, &Instance.Roles, &Instance.MaxTime, &Instance.Cooldown, &Instance.Concurrents); err != nil {
		return nil, err
	}
	//returns the instance information
	return &Instance, nil
}

//updates a users password
//this will update the password inside the database correctly
func (conn *Database) UpdatePassword(password, user string) error {

	//edits the password field inside the database
	//this will update the password for the user properly
	Row := conn.contain.QueryRow("UPDATE `users` SET `Password` = ? WHERE `Username` = ?", Password(password), user)

	//returns any possible error which could happen
	return Row.Err()
}

//this function will completetly update the roles the user has access too
//this is a main part inside the user role handler
func (conn *Database) UpdateRanks(ranks string, user string) error {

	//updates the sql rank structure
	//this will completetly update the sql rank structure safely
	Row, err := conn.contain.Query("UPDATE `users` SET `Ranks` = ? WHERE `Username` = ?", ranks, user)
	if err != nil {
		return err
	}
	//closes the sql query once complete
	defer Row.Close()
	return nil
}

//this function will completetly change the users maxtime
//this will allow users to add time onto there maxtime
func (conn *Database) ChangeMaxTime(newMT string, user string) error {

	//updates the sql rank structure
	//this will completetly update the sql rank structure safely
	Row, err := conn.contain.Query("UPDATE `users` SET `maxTime` = ? WHERE `Username` = ?", newMT, user)
	if err != nil {
		return err
	}
	//closes the sql query once complete
	defer Row.Close()
	return nil
}

//this function will completetly change the users cooldown
//this will allow users to add time onto there cooldown
func (conn *Database) ChangeCooldown(newMT string, user string) error {

	//updates the sql rank structure
	//this will completetly update the sql rank structure safely
	Row, err := conn.contain.Query("UPDATE `users` SET `cooldown` = ? WHERE `Username` = ?", newMT, user)
	if err != nil {
		return err
	}
	//closes the sql query once complete
	defer Row.Close()
	return nil
}

//this function will completetly change the users cooldown
//this will allow users to add time onto there cooldown
func (conn *Database) ChangeConcurrents(newMT string, user string) error {

	//updates the sql rank structure
	//this will completetly update the sql rank structure safely
	Row, err := conn.contain.Query("UPDATE `users` SET `concurrents` = ? WHERE `Username` = ?", newMT, user)
	if err != nil {
		return err
	}
	//closes the sql query once complete
	defer Row.Close()
	return nil
}

//gets all users in the database
//this will grab all active users inside the database correctly
func (conn *Database) GetUsers() ([]User, error) {

	//selects all logins reqeusts from a certain username
	rows, err := conn.contain.Query("SELECT `id`, `Username`, `Password`, `UserToken`, `Ranks`, `maxTime`, `cooldown`, `concurrents` FROM `users`")
	if err != nil {
		return make([]User, 0), err
	}

	//closes the rows once the function is finished
	defer rows.Close()

	//stores all logins
	//this will fill up as we scan the rows
	var LoginReqs []User = make([]User, 0)

	for rows.Next() {
		//temp storage for the row
		//the row is stored there until we loop again
		var Row User

		//scans the current row
		err := rows.Scan(&Row.Id, &Row.Username, &Row.Password, &Row.UserToken, &Row.Roles, &Row.MaxTime, &Row.Cooldown, &Row.Concurrents)
		if err != nil {
			return make([]User, 0), err
		}

		//stores the current login request into the array
		LoginReqs = append(LoginReqs, Row)

	}

	return LoginReqs, nil
}

var (
	ErrUserAlreadyExists error = errors.New("User which was queryed has already been created")
)

//creates the user inside the database
//this pushes the query towards the database safely and properly
func (conn *Database) CreateNewUser(usr *User) error {

	//checks to see if the user already exists
	//this stops users from being able to dup users inside the database
	if usr, err := conn.GetUser(usr.Username); err == nil || usr != nil {
		return ErrUserAlreadyExists
	}

	//querys the insert in the database
	//this will try to correctly insert the users information if its possible
	row, err := conn.contain.Query("INSERT INTO `users` VALUES (NULL, ?,?,?,?,?,?,?);", usr.Username, Password(usr.Password), usr.UserToken, usr.Roles, usr.MaxTime, usr.Cooldown, usr.Concurrents)
	if err != nil {
		return err
	}

	defer row.Close()
	return nil
}