package security

import (
	"Nosviak/core/database"
	"crypto/md5"
)

// creates a new userToken
// this is a way we can find users without using something which is dynamic
func UserToken(password, username string) (string) {
	// hashes the users password
	// this is the last section of the usertoken
	Text := md5.New().Sum([]byte(password))

	//combines the username & Text (ide Password) and returns the sha256 product
	return database.Password(username+"@"+string(Text))
}