package security

import (
	"math/rand"
	"strings"
	"time"
)

//creates a strong password
//this is used for mainly user creation
//creates a strong random charater password
func GenerateStrongPassword(length int) string {
	//stores all the charaters we can use inside the password
	var ValidCharaters string = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890"

	//creates a password to the right length
	var Password []string = make([]string, length)
	rand.Seed(time.Now().UnixMicro())
	//for loops the amount of times the length says to
	for render := 0; render < length; render++ {
		Password[render] = strings.Split(ValidCharaters, "")[rand.Intn(len(ValidCharaters) - 1)]
	}
	return strings.Join(Password, "")
}