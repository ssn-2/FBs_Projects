package util

import (
	"fmt"
	"strings"
	"time"
)

//this is used for when the time.Since function is wanted
//this will auto resolve the timestamp into its current format
//with the format of f you can display if you want the full time display
func ResolveTimeStamp(t time.Time, f bool) string {
	//detects if the session has been open for longer than one hour
	if strings.Count(time.Since(t).Round(0).String(), "h") > 0 {
		if f {
			//displays the full time measurement
			return fmt.Sprintf("%.0f hours", time.Since(t).Hours())
		}
		return fmt.Sprintf("%.0fhrs", time.Since(t).Hours())
	} else if strings.Count(time.Since(t).Round(0).String(), "m") > 0 && !strings.Contains(time.Since(t).Round(0).String(), "ms") {
		if f {
			//displays the full time measurement
			return fmt.Sprintf("%.0f minutes", time.Since(t).Hours())
		}
		return fmt.Sprintf("%.0fmins", time.Since(t).Minutes())
	} else if strings.Count(time.Since(t).Round(0).String(), "s") > 0 {
		if f {
			//displays the full time measurement
			return fmt.Sprintf("%.0f seconds", time.Since(t).Hours())
		}
		return fmt.Sprintf("%.0fsecs", time.Since(t).Seconds())
	}

	return "0secs"
}