package util

import "errors"



//checks if the boolean is valid
//if not we will reutrn an error code
func AuthenticateBooelean(str string) error {
	//checks if the boolean is type true or false
	if str == "true" || str == "false" {
		return nil
	}

	//returns err if its anything else
	return errors.New("invaild type passed into function")
}

//basic boolean system
//this will allow us to check something is valid
//it will only add the additional charaters if the boolean passed is valid
//this system will add the charaters to the start & the back of the string
func ValidateBoolean(base string, additional string, b bool) string {
	//checks if the boolean is set correctly
	if b {
		//returns the valid charaters on the end of the system
		//this will be displayed inside the table correctly & properly
		return additional + base + additional
	}
	//return the default structure
	return base
}