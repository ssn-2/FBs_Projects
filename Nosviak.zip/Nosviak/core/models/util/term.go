package util

import (
	"strings"
)

//function used as a basic fillspace
//allows us to display text of any length and be able to display it safely
func FillSpace(Text string, filler int) string {
	//this stores the amount of space we need to fill
	//we will loop this amount of times filling each space
	Filler := filler - len(Text)

	//we will now place our text inside this array
	//this will allocate us memory to store our fillspace inside
	var Support []string = make([]string, len(Text))

	//ranges through each charater of the text
	//this will be placed into the array safely and properly
	for pos, char := range Text {
		//allocates the charaters position in the array
		Support[pos] = string(char)
	}

	//for loops the amount of times the filler says so
	//this allows us to control the amount of loops we perform
	for render := 0; render < Filler; render++ {
		//places a space as the place holder
		Support = append(Support, " ")
	}

	//returns the array but joined as a string properly
	return strings.Join(Support, "")
}

//basic pretty boolean display
//this is used in the view user command
func TextBoolean(access bool) string {
	if access {
		return "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m"
	} else {
		return "\x1b[48;5;2m\x1b[38;5;16m TRUE \x1b[0m"
	}
}

//outputs a string with the length of 40
//this should be half the terminals window size
func BuildRow(que [2]string) string {
	//builds the string safely and correctly
	return FillSpace(que[0], 20) + FillSpace(que[1], 20)
}