package util

//scans through an array of objects looking for an object
//cleaner way to mass look through multiply objects without being messy
func NeedleHaystack(stack []string, needle string) bool {

	//ranges through the array
	for _, hay := range stack {

		//checks and trys to match the object
		if hay == needle {
			//returns true if it matchs the object
			return true
		}
	}

	//returns false if object doesn't match
	return false
}
