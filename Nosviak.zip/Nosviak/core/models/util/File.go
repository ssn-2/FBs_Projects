package util

import (
	"io/ioutil"
	"strings"
)

//gets all the files with a certain extension inside the dir selected
func GetExtensions(ext string, dir string) ([]string, error) {

	//trys to read the dir for all possible files inside
	Folder, err := ioutil.ReadDir(dir) 
	if err != nil {
		//returns the array with 0 positions and the err code
		return make([]string, 0), err
	}

	var Storage []string = make([]string, 0)

	for _, File := range Folder {

		//gets the extension used for the file
		FileExt := Extension(File.Name())

		//compares the 2 extensions
		if FileExt != ext {
			//voids this input as its not the extension we are looking for
			continue
		}

		//saves the file name as a possibly inside that directory
		Storage = append(Storage, File.Name())
	}

	return Storage, nil
}


//gets the extension, example json, js, go...
func Extension(header string) (string) {
	//returns the header of the file
	return strings.Split(header, ".")[len(strings.Split(header, "."))-1]
}