package json

import (
	"io/ioutil"
	"path/filepath"
	"strings"
)

//converts an array of strings into an array of byte values
//mainly used to be passed into each parser
func ArrayToBytes(array []string) []byte {
	//converts the array into a string
	arrayPointer := strings.Join(array, "")
	//returns the pointer as a array byte
	return []byte(arrayPointer)
}

//uses the function inside of util (GetExtensions) to get all the files with the json extensions and reads there contents
func GetFiles(dir string) (map[string][]string, error) {
	return RenderDir(dir)
}

//mainly added support for multi Directory support
//meaning json files can be anywhere inside the cnc but with the same path
func RenderDir(path string) (map[string][]string, error) {

	//renders the dir which we want to read
	//this will allows us to properly scan the dir for all files inside
	Location, err := ioutil.ReadDir(path)

	//err handles the read statement
	//makes sure no errors happened when trying to read
	if err != nil {
		//returns the error which was found correctly and safely
		return make(map[string][]string), err
	}

	//creates a storage object
	//this will store the objects from the function properly
	var MemoryObject map[string][]string = make(map[string][]string)

	//ranges through all the possible options which can be used
	//this will range through all possible files inside the dir
	for _, information := range Location {

		//checks the length of the folder
		//this will allow us to check if the option contains a extension
		if strings.Count(information.Name(), ".") <= 0 {
			//renders the file as a directory
			//we will trigger a new renderdir instance to scan

			//creates a filepath to the dir
			//this will allow us to create a new instance
			Path := filepath.Join(path, information.Name())

			//reads the dir for all possible files
			//this will get all possible json files from this area
			Mem, err := RenderDir(Path)

			//err handles the render statement
			//this will allow us to check if there was an error
			if err != nil {
				//returns the error which was found
				return make(map[string][]string), err
			}

			//ranges through the map which was being ranged correctly
			//this will register all the objects inside into the main map
			for Key, Contain := range Mem {
				//registers the object properly
				MemoryObject[Key] = Contain
			}

			continue
		} else if strings.Split(information.Name(), ".")[len(strings.Split(information.Name(), "."))-1] == "json" {
			//makes sure the file is a valid json file before we continue
			//this will make sure every file we register is json
			MemoryPath := filepath.Join(path, information.Name())

			//reads the filepath correctly
			//this will read the file in that position
			Render, err := ioutil.ReadFile(MemoryPath)

			//err handles the err which could happen
			//this is future proofing any error which could happen
			if err != nil {
				//continues the loop and loops again
				continue
			}

			//splits the file line by line
			//meaning we are left with an array of lines
			elements := strings.Split(string(Render), "\n")

			//correctly stores the object into the map
			MemoryObject[information.Name()] = elements
		}
	}

	return MemoryObject, nil
}