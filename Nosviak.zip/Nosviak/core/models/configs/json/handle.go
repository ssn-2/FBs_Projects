package json

import (
	"Nosviak/core/models/util"
	"errors"
	"fmt"
	"log"
	"strconv"
)



type Json struct {
	//the folder we want to scan
	Dir string

	//stores all the filters files of json inside this app
	elements []string

	ALog bool
}

//makes a new json instance for parsing
func MakeJson(directory string) (*Json) {
	
	return &Json{
		//stores the dir we want to scan through
		Dir: directory,

		//makes an array of object which we will use for later
		elements: make([]string, 0),

		ALog: false,
	}
}

//saves an object which we want to force
func (J *Json) MakeRelevantObject(obj string) {
	//saves the object into the array
	relevant = append(relevant, obj)
}

func (J *Json) MakeLoud() {
	J.ALog = true
}

func (J *Json) RunParser() error {

	//uses the directory we have selected for this instance to scan through
	elements, err := GetFiles(J.Dir)
	if err != nil {

		//checks for alog in the instance settings
		if J.ALog {
			//logs to the terminal
			fmt.Printf("!json: %s\r\n", err.Error())
		}

		//returns any errors (if any are found) which can be printed
		return err
	}


	//gets all the possible keys from the map
	keys := J.getKeys(elements)

	//checks for alog in the instance settings
	if J.ALog {
		log.Println("\x1b[1mJson || array layed:",keys,"\x1b[0m")
	}

	//runs the checker to see if all wanted options are found
	err = J.Relevant(keys)
	
	//checks for any errors
	if err != nil {
		//checks for alog in the instance settings
		if J.ALog {
			//logs to the terminal
			fmt.Printf("!json: %s\r\n", err.Error())
		}

		//returns the error we found
		return err
	}

	//checks for alog in the instance settings
	if J.ALog {
		log.Println("\x1b[1mJson || found "+strconv.Itoa(len(relevant))+" relevant keys\x1b[0m")
	}

	//ranges through the hashMap
	for subject, subValue := range elements {

		//trys to parse the current instance
		err := J.activeParser(subject, subValue)

		//checks for an error
		if err != nil {

			//checks for alog in the instance settings
			if J.ALog {
				log.Println("\x1b[1mJson || ERR "+err.Error()+"\x1b[0m")
			}

			//returns the error which was found
			return errors.New("["+subject+"] "+err.Error())
		}

		//loops again
		continue
	}

	return nil
}

func (J *Json) Relevant(array []string) error {

	for _, depend := range relevant {

		//trys to see if the object suggested if the object we are looking for
		output := util.NeedleHaystack(array, depend)

		//error code when the object is missing from the array
		if !output {
			//returns the suggested error
			return ErrForcedMissing
		}

		continue
	}


	//returns nil as all pointers have been found
	return nil
}

func (J *Json) getKeys(m map[string][]string) []string {
	//array which is being saved for later
	var storage []string = make([]string, 0)

	for key, state := range m {

		//checks if the object has any value
		if state == nil {
			//if not we skip it
			continue
		}

		//saves the key into the array which we will output
		storage = append(storage, key)
	}

	//returns the array
	return storage
}