package json

import (
	"Nosviak/core/deployment/template"
	"encoding/json"
)


//parses the instance with the subject if made
//this will parse the file with the extension provided meaning we can parse the file correctly
func (J *Json) activeParser(file string, extension []string) (error) {

	switch file {

	case "apis.json":

		//converts the value into a type *[]Byte
		value := ArrayToBytes(extension)

		//declares a temp object which is used to store the value
		var objectPointer Template.Apis

		//parses the element using the golang json lib
		err := json.Unmarshal(value, &objectPointer)

		//checks for any errors to report back
		if err != nil {
			//reports the error back to the function
			return err
		}

		//saves/updates the pointer
		ContentApis = &objectPointer

		//else returns a nil pointer for the error
		return nil


		// "config.json" element parser (forced parserable object)
	case "central.json":

		//converts the value into a type *[]Byte
		value := ArrayToBytes(extension)

		//declares a temp object which is used to store the value
		var objectPointer Template.ConfigurationJson

		//parses the element using the golang json lib
		err := json.Unmarshal(value, &objectPointer)

		//checks for any errors to report back
		if err != nil {
			//reports the error back to the function
			return err
		}

		//saves/updates the pointer
		ContentConfig = &objectPointer

		//else returns a nil pointer for the error
		return nil
	}


	return ErrUnknownObject
}