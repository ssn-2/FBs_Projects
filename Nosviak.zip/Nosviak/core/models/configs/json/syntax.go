package json

import (
	"Nosviak/core/deployment/template"
	"errors"
)

var (

	
	//all files we want to be forced to file and if not we will return an error
	relevant = []string{"central.json"}

	//our structure we wish to file using our parser. make sure to store any content as nil pointers
	ContentConfig *Template.ConfigurationJson = nil
	ContentApis *Template.Apis = nil
)

var (

	//error for when a object inside of the relevant array is missing from the array
	ErrForcedMissing error = errors.New("missing forced relevant object inside array of elements")

	ErrUnknownObject error = errors.New("object passed is unknown, possible error")
)