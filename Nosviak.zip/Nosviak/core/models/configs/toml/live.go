package Toml

import (
	"Nosviak/core/deployment/template"


	"bytes"
	"github.com/naoina/toml"
)


func (J *Toml) activeParser(file string, extension []string) (error) {

	switch file {

	case "attacks.toml":

		//converts the value into a type *[]Byte
		value := ArrayToBytes(extension)

		//declares a temp object which is used to store the value
		var objectPointer Template.AttacksToml

		//reads the bytes from the file
		reader := bytes.NewReader(value)


		//decodes the structure properly
		if err := toml.NewDecoder(reader).Decode(&objectPointer); err != nil {
			return err
		}

		//saves/updates the pointer
		AttacksToml = &objectPointer

		//else returns a nil pointer for the error
		return nil

	case "instance.toml":

		//converts the value into a type *[]Byte
		value := ArrayToBytes(extension)

		//declares a temp object which is used to store the value
		var objectPointer Template.Instance

		//reads the bytes from the file
		reader := bytes.NewReader(value)


		//decodes the structure properly
		if err := toml.NewDecoder(reader).Decode(&objectPointer); err != nil {
			return err
		}

		//saves/updates the pointer
		InstanceToml = &objectPointer

		//else returns a nil pointer for the error
		return nil


	case "decoration.toml":

		//converts the value into a type *[]Byte
		value := ArrayToBytes(extension)
		
		//declares a temp object which is used to store the value
		var objectPointer Template.Decoration

		//reads the bytes from the file
		reader := bytes.NewReader(value)


		//decodes the structure properly
		if err := toml.NewDecoder(reader).Decode(&objectPointer); err != nil {
			return err
		}

		//saves/updates the pointer
		DecorationToml = &objectPointer

		//else returns a nil pointer for the error
		return nil


	case "terminal.toml":

		//converts the value into a type *[]Byte
		value := ArrayToBytes(extension)

		//declares a temp object which is used to store the value
		var objectPointer Template.TerminalToml

		//reads the bytes from the file
		reader := bytes.NewReader(value)


		//decodes the structure properly
		if err := toml.NewDecoder(reader).Decode(&objectPointer); err != nil {
			return err
		}

		//saves/updates the pointer
		TerminalToml = &objectPointer

		//else returns a nil pointer for the error
		return nil
	case "ranks.toml":

		//converts the value into a type *[]Byte
		value := ArrayToBytes(extension)

		//declares a temp object which is used to store the value
		var objectPointer Template.RankToml

		//reads the bytes from the file
		reader := bytes.NewReader(value)


		//decodes the structure properly
		if err := toml.NewDecoder(reader).Decode(&objectPointer); err != nil {
			return err
		}

		//saves/updates the pointer
		RanksToml = &objectPointer

		//else returns a nil pointer for the error
		return nil
	}


	return ErrUnknownObject
}