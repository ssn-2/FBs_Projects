package Toml

import (
	"Nosviak/core/models/util"
	"io/ioutil"
	"path/filepath"
	"strings"
)

func ArrayToBytes(array []string) []byte {
	//converts the array into a string
	arrayPointer := strings.Join(array, "")
	//returns the pointer as a array byte
	return []byte(arrayPointer)
}

//uses the function inside of util (GetExtensions) to get all the files with the Toml extensions and reads there contents
func GetFiles(dir string) (map[string][]string, error) {

	//gets all the possible choices inside that directory
	possible, err := util.GetExtensions("toml", dir)

	//if any errors happen we will report them back to the function statement
	if err != nil {
		//returns the map identy and the error we found
		return make(map[string][]string), err
	}

	//makes the variable active
	var storage map[string][]string = make(map[string][]string)

	//ranges through the array
	for _, FileExtension := range possible {

		//creates a readable path to the file using information we know
		Path := filepath.Join(dir, FileExtension)

		//trys to reads the file using that path
		contents, err := ioutil.ReadFile(Path)

		//if any errors could happen we will ignore them
		if err != nil {
			//reports any errors back to the function statement
			return make(map[string][]string), err
		}

		//splits the contents line by line using the ansi code
		elements := strings.SplitAfter(string(contents), "\n")

		//saves the information back into the map
		storage[FileExtension] = elements
	}

	//returns the map and a nil error 
	return storage, nil
}