package Toml

import (
	"Nosviak/core/deployment/template"
	"errors"
)

var (

	
	//all files we want to be forced to file and if not we will return an error
	relevant = []string{"terminal.toml", "ranks.toml", "decoration.toml", "instance.toml", "attacks.toml"}

	//our structure we wish to file using our parser. make sure to store any content as nil pointers
	TerminalToml *Template.TerminalToml = nil

	RanksToml *Template.RankToml = nil

	DecorationToml *Template.Decoration = nil

	InstanceToml *Template.Instance = nil

	AttacksToml *Template.AttacksToml = nil
)

var (

	//error for when a object inside of the relevant array is missing from the array
	ErrForcedMissing error = errors.New("missing forced relevant object inside array of elements")

	ErrUnknownObject error = errors.New("object passed is unknown, possible error")
)