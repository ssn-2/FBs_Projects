package views

import (
	"Nosviak/core/models/dtx"
	"errors"
	"strings"
)


//new instance for the parser correctly
func PerformStep(header string) (*dtx.Evaluator, error) {

	//loops for the piece correctly
	Object, err := SearchPiece(header)
	if err != nil {
		return nil, err
	}

	//the array we will save everything into
	var LexerInput [][]string = make([][]string, 0)

	//ranges through the object we have correctly
	for _, Line := range Object.Source {
		LexerInput = append(LexerInput, strings.Split(dtx.AmplifyANSI(Line), ""))
	}

	//creates a new lexer instance
	lex := dtx.CreateLexer(LexerInput)

	//executes the lexer correctly
	if _, err := lex.PerformLexer(); err != nil {
		return nil, err
	}

	//creates a new parser instance
	newParser := dtx.NewParser(lex)

	//executes the parser correctly
	if err := newParser.NewNode(); err != nil {
		return nil, err
	}

	//returns the new evaluator instance
	return dtx.NewEvaluator(newParser, make([]dtx.Function, 0)), nil
}


//searchs for the item correctly
func SearchPiece(header string) (*View, error) {
	
	//ranges through the array
	for _, currentView := range Store {

		//compares the header we want to the header found
		if currentView.Header == header {
			return &currentView, nil
		}
	}

	//returns an err as it couldn't be found correctly
	return nil, errors.New("failed to correctly find that object inside the array")
}