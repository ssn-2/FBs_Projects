package views



//completetly clears the branding map
//this means every which was once inside is completetly removed
func ScrapBranding() {
	Store = make([]View, 0)
}