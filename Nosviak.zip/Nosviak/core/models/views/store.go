package views

import "sync"

//stores information about the view safely
//used so we can pass this into the dtx wrapper and execute easier
type View struct {
	//stores the files header
	//this is mainly the file name
	Header string

	//stores the line inside the file
	//this will futher be splited before being passed into the lexer/parser/interpreter
	Source []string
}

var (
	//creates an array to store the objects inside
	Store []View = make([]View, 0)
	Mutex sync.Mutex
)

//creates a new view and returns the structure
func NewView(container []string, header string) View {
	return View{
		Header: header,
		Source: container,
	}
}