package views

import (
	"Nosviak/core/models/dtx"
	"errors"
	"io"
	"strconv"
	"strings"
	"sync"
)

type DtxFormat struct {

	//stores the header you want to wrap
	//this is used as we will get the source from the map using this
	Header string

	//stores all interfaces you want to register
	//this is used so we can register structures into the system
	//ths map key will be the structures header
	Structures map[string]interface{}

	//stores all the values you want to register
	//this is used so users that have a copy of the cnc can use variables on this
	Variables map[string]string

	//stores the interface you would like the cnc to write too
	wr func(source []byte) (int, error)

	//stores the term mutex for the instance
	mutex sync.Mutex
}


//creates a new instance
//this is used to start the processes
func NewDTX(header string,  wr func(source []byte) (int, error)) *DtxFormat {
	return &DtxFormat{
		Header:     header,
		Structures: make(map[string]interface{}),
		Variables: make(map[string]string),
		wr: wr,
	}
}

//simple function which supports chain registering
func (i *DtxFormat) RegisterVariable(varName string, varValue string) *DtxFormat {
	Mutex.Lock()
	defer Mutex.Unlock()

	//enters the item into the structure
	i.Variables[varName] = varValue

	//returns the value
	return i
}


//register a type boolean into the scope
//allows users to register boolens into dtx safely
func (i *DtxFormat) RegisterBoolean(varName string, varValue bool) *DtxFormat {
	Mutex.Lock()
	defer Mutex.Unlock()

	type Store struct {
		Value bool
	}

	//enters the item into the structure
	i.Variables[varName] = strconv.FormatBool(true)

	//returns the value
	return i
}

//simple function which supports chain registering
func (i *DtxFormat) RegisterStructure(Header string, Value interface{}) *DtxFormat {
	Mutex.Lock()
	defer Mutex.Unlock()

	//enters the item into the structure
	i.Structures[Header] = Value

	//returns the value
	return i
}

//starts the execution processes properly
func (i *DtxFormat) ExecuteStandard(wr io.Writer) error {

	//performs the parser & lexer on the source
	//then returns the eval structure completely setup
	eval, err := PerformStep(i.Header)
	if err != nil {
		return err
	}

	//ranges through all the interfaces
	//each rotation the interface is properly registered
	for Header, Structure := range i.Structures {

		//registers the structure into the interpreter
		if err := eval.RegisterStructure(Header, Structure); err != nil {
			//returns the err which was found
			return err
		}
	}

	//ranges through all the interfaces
	//each rotation the interface is properly registered
	for Header, Value := range i.Variables {
		//registers the structure into the interpreter
		if err := eval.NewVariable("", Header, dtx.CreateToken(Value, dtx.Position{Row: 0, Col: 0}, "string"), true); err != nil {
			return err
		}
	}

	eval.RegisterFunction("format.MoveCursor", func(Arguments []dtx.Token, wr func(source []byte) (int, error)) error {

		//makes sure the user has provided the right amount of args
		//these will be used to correctly move the cursor
		if len(Arguments) != 2 {
			//returns the invalid format information
			return errors.New("invalid format, Args format.MoveCursor(row int, col int)")
		}

		//checks that the argument type is valid
		//this makes sure the type given is valid
		if Arguments[0].VType != "int" || Arguments[1].VType != "int" {
			//returns the invalid format error
			return errors.New("invalid format, Args format.MoveCursor(row int, col int)")
		}

	
		//moves the cursor to the line asked for
		//this will correctly move the cursor safely
		if _, err := wr([]byte("\033["+Arguments[0].Literal()+";"+Arguments[1].Literal()+"f")); err != nil {
			return err
		}

		return nil
	}, func(session io.Writer, args string) (int, error) {

		//returns the invalid format error
		if len(strings.Split(args, ",")) != 2 {
			//returns the invalid format information
			return 0, errors.New("invalid format, Args <<format.MoveCursor(row int, col int)>>")
		}

		//makes sure the line provided is valid
		Line, err := strconv.Atoi(strings.Split(args, ",")[0])
		if err != nil {
			//returns the invalid format information
			return 0, errors.New("invalid format, Args <<format.MoveCursor(row int, col int)>>")
		}

		//makes sure the line provided is valid
		Col, err := strconv.Atoi(strings.Split(args, ",")[1])
		if err != nil {
			//returns the invalid format information
			return 0, errors.New("invalid format, Args <<format.MoveCursor(row int, col int)>>")
		}

		return session.Write([]byte("\033["+strconv.Itoa(Line)+";"+strconv.Itoa(Col)+"f"))
	})



	//executes the rootnode with the writer set correctly
	return eval.RootNodeWR(i.wr)
}