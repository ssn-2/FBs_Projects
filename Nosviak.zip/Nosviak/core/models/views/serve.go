package views

import (
	"Nosviak/core/deployment"
	"io/ioutil"
	"path/filepath"
	"strings"
)

//gets all branding
//please note that the dir inside the arguments must be inside the assets dir
func FetchBranding(dir string) error {

	//joins the assets directory and the dir put together
	directory := filepath.Join(deployment.Assets, dir)

	//reads the dir correctly
	storage, err := RenderDir(directory)
	if err != nil {
		return err
	}

	//saves the object into the array
	Store = append(Store, storage...)

	return nil
}


//reads all the files inside the dir correctly
func RenderDir(dir string) ([]View, error) {
	//reads all the files in the dir
	RDir, err := ioutil.ReadDir(dir)
	if err != nil {
		return make([]View, 0), err
	}

	var container []View = make([]View, 0)

	for _, vendor := range RDir {


		//counts how many sections are inside the name
		if strings.Count(vendor.Name(), ".") <= 0 {
			//joins to the second directory
			connection := filepath.Join(dir, vendor.Name())

			//reads the dir correctly
			VRender, err := RenderDir(connection)
			if err != nil {
				return make([]View, 0), err
			}

			//saves into the array
			container = append(container, VRender...)

			//loops again
			continue
		} else {
			//joins the directory with the file
			correction := filepath.Join(dir, vendor.Name())

			//reads the file
			render, err := ioutil.ReadFile(correction)
			if err != nil {
				return make([]View, 0), err
			}


			container = append(container, NewView(strings.SplitAfter(string(render), "\n"), vendor.Name()))
		}
	}

	return container, nil
}