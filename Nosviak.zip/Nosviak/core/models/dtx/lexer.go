package dtx

import (
	"errors"
	"strings"
)

type Lexer struct {
	//stores the source which we are reading in a [][]string type
	literal [][]string

	//stores the lexers current
	position *Position

	//stores an array of tokens which have been found
	tokens []Token

	currentLine []string

	Errs []error

	ActiveBody bool
}

//creates a new lexer instance which we are going to use
func CreateLexer(source [][]string) *Lexer {
	return &Lexer{
		literal: source,
		position: &Position{
			Col: 0, Row: 1,
		},

		//makes an array of possible tokens
		tokens: make([]Token, 0),
		Errs: make([]error, 0),
		ActiveBody: false,
	}
}


//used in making a simple wrapper for the lexer, parser & interpreter
func (l *Lexer) ExecuteLexer() (*Lexer, error) {

	if _, err := l.PerformLexer(); err != nil {
		return nil, err
	}

	return l, nil
}

func (l *Lexer) PerformLexer() ([]Token, error) {

	//runs until the length of the literal source is not as big as the position
	for pos := 0; pos < len(l.literal); pos++ {


		//updates the current line which is being scanned
		l.currentLine = l.literal[pos]

		//updates the current scanners row
		l.position.Row = pos

		//runs util we have reached the end of the slice of the array
		for scanner := 0; scanner < len(l.currentLine); scanner++ {

			//sets the current scanner position
			l.position.Col = scanner

			if !l.ActiveBody {

				//executes the body worker
				if body, err := l.NewBody().Execute(); err == nil  {
					//makes sure we save the body as a token
					if strings.Contains(strings.Join(body.Source, ""), "?>") {
						continue
					}
					
					l.tokens = append(l.tokens, *CreateToken(strings.ReplaceAll(strings.ReplaceAll(strings.Join(body.Source, ""), "?>", ""), "<?", ""), *l.position, "text"))

					//checks if a body was found
					if body.Unlock {
						l.tokens = append(l.tokens, *CreateToken("?>", Position{Col: body.Unlocked, Row: l.position.Row}, "NB"))
						//allows the lexer to completely keep scanning
						l.ActiveBody = body.Unlock
						//skips to when the body is believed to have been opened at
						scanner += body.Unlocked
					} else {
						scanner = body.current_Col
					}
				}

				//continues looping anyway
				continue
			}

			if token, err := l.lexChar(); err != nil || token == nil {

				//checks if there was an error
				if err != nil {
					//if so, saves it
					l.Errs = append(l.Errs, err)
				}

				continue //loops again
			} else {



				//updates the scanner to were the token is finished
				scanner += token.size



				//saves the token which was grabbed and loops again
				l.tokens = append(l.tokens, *token)
			}
		}
	}

	return l.tokens, nil
}

//trys to peek the next charater in the string
func (l *Lexer) peekChar() (string, error) {

	//sees if the adding one position takes the scanner to another line
	if l.position.Col + 1 >= len(l.currentLine) {
		return "", errors.New("failed to peek, next charater performs on the next line")
	}

	//returns the current char but one space ahead
	return l.currentLine[l.position.Col+1], nil
}

func (l *Lexer) lexChar() (*Token, error) {


	//scans the current position
	switch l.currentLine[l.position.Col] {

	case "+":
		return CreateToken("+", *l.position, "PLUS"), nil
	case "-":
		return CreateToken("-", *l.position, "MINUS"), nil
	case "*":
		return CreateToken("*", *l.position, "MULTIPLY"), nil
	case "/":	
		return CreateToken("/", *l.position, "DIVIDE"), nil
	case "^":
		return CreateToken("^", *l.position, "XOR"), nil
	case ".":
		return CreateToken(".", *l.position, "STOP"), nil
	case ",":
		return CreateToken(",", *l.position, "COMMA"), nil
	case ";":
		return CreateToken(";", *l.position, "SEMICOLON"), nil

	case "#":
		return CreateToken("#", *l.position, "LineComment"), nil

	case ":":
		if char, _ := l.peekChar(); char == ":"{
			return CreateToken("::", *l.position, "LineComment"), nil
		}

	case "=":
		//checks for a equal statement
		if char, err := l.peekChar(); char == "=" && err == nil {
			return CreateToken("==", *l.position, "EQUAL"), nil
		}

		//if not an equal statement it should be a assign statement
		return CreateToken("=", *l.position, "ASSIGN"), nil

	case "!":
		//checks for a not equal statement statement
		if char, err := l.peekChar(); char == "=" && err == nil {
			return CreateToken("!=", *l.position, "NEQ"), nil
		}

		return CreateToken("!", *l.position, "BANG"), nil

	case ">":

		if char, _ := l.peekChar(); char == "=" {
			return CreateToken(">=", *l.position, "GOR"), nil
		} else if char == ">" {
			return CreateToken(">>", *l.position, "RSHIFT"), nil
		} else {
			return CreateToken(">", *l.position, "GREATER"), nil
		}

	case "<":

		if char, _ := l.peekChar(); char == "=" {
			return CreateToken("<=", *l.position, "LOR"), nil
		} else if char == "<" {
			return CreateToken("<<", *l.position, "LSHIFT"), nil
		} else {
			return CreateToken("<", *l.position, "LESS"), nil
		}

	case "?":
		if char, _ := l.peekChar(); char == ">" {
			l.ActiveBody = false
			return CreateToken("?>", *l.position, "CB"), nil
		}



	case "|":
		if char, _ := l.peekChar(); char == "|" {
			return CreateToken("||", *l.position, "OROR"), nil
		}

		return CreateToken("|", *l.position, "OR"), nil
	case "(":
		return CreateToken("(", *l.position, "OPARENT"), nil
	case ")":
		return CreateToken(")", *l.position, "CPARENT"), nil
	case "[":
		return CreateToken("[", *l.position, "OBRACKET"), nil
	case "]":
		return CreateToken("]", *l.position, "CBRACKET"), nil
	case "{":
		return CreateToken("{", *l.position, "OBRACE"), nil
	case "}":
		return CreateToken("}", *l.position, "CBRACE"), nil


	case "\"":
		//possible string detected being opened
		token, err := l.ReadString()
		if err != nil {
			return nil, err
		}

		//reads the strings body
		return token, nil


	default:

		if IsLetter(l.currentLine[l.position.Col]) {
			return l.ReadIdent()
		} else if IsDigit(l.currentLine[l.position.Col]) {
			return l.ReadInt()
		}
	}


	return nil, nil
}



func (l *Lexer) ReadString() (*Token, error) {
	
	var stringBody string = ""

	for body := l.position.Col + 1; body < len(l.currentLine); body++ {

		if l.currentLine[body] == "\"" {
			return CreateToken("\""+stringBody+"\"", *l.position, "string"), nil
		}

		stringBody += l.currentLine[body]
	}

	return nil, errors.New("string opened but never closed (well not detected)")
}

func (l *Lexer) ReadIdent() (*Token, error) {

	var identBody string = ""

	for body := l.position.Col; body < len(l.currentLine); body++ {

		if !IsLetter(l.currentLine[body]) {
			return CreateToken(identBody, *l.position, "ident"), nil
		}

		identBody += l.currentLine[body]
	}

	return CreateToken(identBody, *l.position, "ident"), nil
}

func (l *Lexer) ReadInt() (*Token, error) {

	var intBody string = ""

	for body := l.position.Col; body < len(l.currentLine); body++ {

		if !IsDigit(l.currentLine[body]) {
			return CreateToken(intBody, *l.position, "int"), nil
		}

		intBody += l.currentLine[body]
	}

	return CreateToken(intBody, *l.position, "int"), nil
}