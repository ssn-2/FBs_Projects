package dtx

import (
	"fmt"
	"io/ioutil"
	"os"
	"runtime"
	"strings"
	"time"
)

var Verbose bool = false

func main() {

	started := time.Now()

	if len(os.Args) <= 1 {
		fmt.Println("Missing || you must include a file")
		return
	}

	if len(os.Args) >= 3 && strings.ToLower(os.Args[2]) == "-d" {
		Verbose = true
	}

	File, err := ioutil.ReadFile(os.Args[1])
	if err != nil {
		fmt.Println("Err || "+err.Error())
		return
	}


	current := strings.SplitAfter(string(File), "\n")
	
	
	var source [][]string = make([][]string, 0)

	for _, line := range current {
		source = append(source, strings.Split(AmplifyANSI(line), ""))
	}


	lexer := CreateLexer(source)

	//performs the lexer safely
	if _, err := lexer.PerformLexer(); err != nil {
		fmt.Println("Err || "+err.Error())
		return
	}

	if Verbose {
		lexer.DebugTokens("assembly.cs")
	}


	node := NewParser(lexer)

	//performs the parser correctly
	if err := node.NewNode(); err != nil {
		fmt.Println("Err || "+err.Error())
		return
	}

	eval := NewEvaluator(node, make([]Function, 0))

	type System struct {
		Cores int
		Operating  string
	}

	
	var sys System = System{
		Cores: runtime.NumCPU(),
		Operating: runtime.GOOS,
	}

	eval.RegisterStructure("sys", sys)
	eval.NewVariable("user", "username", &Token{startPosition: nil, endPosition: nil, literal: "root", VType: "string", size: 0}, true)

	//performs the interpreter safely
	if err := eval.RootNode(); err != nil {
		fmt.Println("Err || "+err.Error())
		return
	}

	if Verbose {
		fmt.Println("\r\n======================= Debug =======================")
		fmt.Println("Time taken:", time.Since(started).Microseconds(), "Mircoseconds")
		fmt.Println("Routines:", runtime.NumGoroutine())
		fmt.Println("Functions made:", len(eval.Functions))
		fmt.Println("Global variables made:", len(eval.GlobalScope))
	}
}
