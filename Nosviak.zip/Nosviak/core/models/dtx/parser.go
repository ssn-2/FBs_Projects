package dtx

import (
	"errors"
	"fmt"
	"strconv"
	"strings"
)

type Node struct {
	//stores the lexer instance
	//stores the token array and the source we are parsing
	Lexer *Lexer

	//stores the current parser position in the token array
	position int

	//stores all the vistors we have in the parser
	BaseNode []Vistor
}

//creates a new parser instance
func NewParser(lex *Lexer) *Node {
	return &Node{
		Lexer:    lex,
		BaseNode: make([]Vistor, 0),
	}
}

func LoopParser(lex *Lexer, err error) (*Node) {
	return &Node{
		Lexer:    lex,
		BaseNode: make([]Vistor, 0),
	}
}

var TextBody bool = true

func (node *Node) BuildNode() (*Node, error) {


	if err := node.NewNode(); err != nil {
		return nil, err
	}

	return node, nil
}

//ranges through all the statements
func (node *Node) NewNode() error {
	//for loops through the tokens
	for currentPosition := 0; currentPosition < len(node.Lexer.tokens); currentPosition++ {
		//updates the current position of the node scanner
		node.position = currentPosition


		//detected a text object
		if node.Lexer.tokens[currentPosition].VType == "text" {
			//places the token into the array
			node.BaseNode = append(node.BaseNode, *node.NewText(&node.Lexer.tokens[currentPosition]))
			//loops again
			continue
		} else if node.Lexer.tokens[currentPosition].VType == "NB" || node.Lexer.tokens[currentPosition].VType == "CB" {
			continue
		}


		//creates a new parser and executes using the information passed
		element, size, err := node.createParser(currentPosition, node.Lexer.tokens).parseElement(nil)
		if err != nil {
			return err
		} else if element == nil {
			//loops again if the element is equal to nil
			continue
		}
		//skips until that function has finished
		currentPosition = currentPosition + size - 1
		//adds the element we parsed into the array
		node.BaseNode = append(node.BaseNode, *element)
		continue

	}


	return nil
}

func (node *Node) NewText(token *Token) *Vistor {
	return &Vistor{
		VistorNode: 5,
		Text: &Text{
			Source: token.literal,
			Position: token.startPosition,
		},
	}
}



type Parse struct {

	//stores the position of the token
	//stores the position of the token you want to parse inside the array
	position int

	//tokens which are being passed into the parser
	//stores all tokens we want to be parsed
	Tokens []Token

	//stores if you want the parser to have a parent body
	//mainly used in the interpreter to see were the token is located
	Peer *Parent

	//stores the node information
	//used mainly to get the lexer information
	node *Node

	//stores how many tokens have been counted in the parser
	//used so we don't have duplicates entering the parser tree
	TokenLength int
}

func (node *Node) createParser(pos int, token []Token) *Parse {
	return &Parse{
		position: pos,
		Tokens:   token,
		Peer:     nil,
		node:     node,
		TokenLength: 0,
	}
}

func (p Parse) WorkComment(Comment *Token) int {

	for Pos := p.position; Pos < len(p.Tokens); Pos++ {

		if p.Tokens[Pos].startPosition.Row > Comment.startPosition.Row {
			fmt.Println(Pos - p.position)
			return Pos - p.position
		}
	}


	return 0
}

//parses the element
//passes the object thought the parser and creates an ast tree out of it
func (p *Parse) parseElement(peer *Parent) (*Vistor, int,  error) {
	var Object *Vistor = &Vistor{}

	//applys the parent node if there is one
	p.workParent(Object, peer)

	if p.Tokens[p.position].VType == "LineComment" {
		return Object, p.WorkComment(&p.Tokens[p.position]), nil
	}

	//switch through the information statements
	switch p.Tokens[p.position].literal {

	case p.node.Lexer.Conditional():

		//sets the vistor node to the correct type
		Object.VistorNode = 2

		Con, size, err := p.BuildConditional(Object)
		if err != nil {
			return nil, 0, err
		}


		Object.Conditional = *Con

		return Object, size + 1, nil

	case p.node.Lexer.Var(), p.node.Lexer.Const():
		//creates a new vistor to the node
		//with the correct type
		Object.VistorNode = 4

		//builds the structure needed
		//places all samples into the data structure which can be used in the interpreter
		Declare, size, err := p.BuildForgeReq(Object)
		if err != nil {
			return nil, 0, err
		}


		//assigns the function information into the vistor node
		Object.Forge = *Declare


		return Object, size, nil
	case p.node.Lexer.Function():


		//checks if the parser can produce functions at this point
		//functions may not be made inside other element bodys

		//checks if the peer structure was passed
		if peer != nil {
			//returns the err as a function has been found inside a function
			return nil, 0, errors.New(strconv.Itoa(p.Tokens[p.position].startPosition.Row)+":"+strconv.Itoa(p.Tokens[p.position].startPosition.Col)+"| parser: functions may not be declared inside other bodys")
		}

		//makes sure we set out vistorNode type to the correct state
		Object.VistorNode = 1

		//builds the function using the build function
		//gets all objects needed for the function and applys into the structure
		Function, size, err := p.BuildFunction(Object)
		if err != nil {
			return nil, 0, err
		}


		//saves the structure into the vistor structure
		Object.Function = *Function

		//returns the key object
		return Object, size + 1, nil

	//handles other function call statements, registers everything until a function either ends or a semi colon/new line starts
	//handles how the system handles incoming requests into the interpreter
	default:


		if p.Tokens[p.position].VType == "CB" {
			TextBody = true
			return nil, 0, nil
		}


		//we will only allow the instance to pass instances as the firstToken
		//as we won't allow any other function to not be type ident we won't want this to be one
		if p.Tokens[p.position].VType != "ident" {
			return nil, 0, errors.New(strconv.Itoa(p.Tokens[p.position].startPosition.Row)+":"+strconv.Itoa(p.Tokens[p.position].startPosition.Col)+"| parser: Got `"+p.Tokens[p.position].VType+"(`"+p.Tokens[p.position].literal+"`), Want ident(`"+p.Tokens[p.position].literal+"`)")
		}

		//sets the nodes type
		Object.VistorNode = 3

		//builds the request body informaiton
		//fills the structure we will use to execute
		Req, size, err := p.BuildRequest(Object)
		if err != nil {
			return nil, 0, err
		}

		//gets if the body length isn't a nil pointer
		if Req == nil {
			return nil, 0, errors.New(strconv.Itoa(p.Tokens[p.position].startPosition.Row)+":"+strconv.Itoa(p.Tokens[p.position].startPosition.Col)+"| parser: BuildRequest returned '<nil>' <UNSAFE>")
		}

		//saves the request into the structure safely
		Object.CallRequest = *Req

		//returns information
		return Object, size + 1, nil
	}
}

func (p *Parse) BuildConditional(object *Vistor) (*Condition, int, error) {
	var NewCondition *Condition = &Condition{
		OriginToken: p.Tokens[p.position],
	}

	//looks for everything which is a dependable object inside the conditions
	Cons, ConLength, err := p.BuildConditions(NewCondition)
	if err != nil {
		return nil, 0, err
	}

	//sets the cons we found to the condition
	NewCondition.Conditions = Cons

	var Size int = 0

	//gets the true body statement information
	TrueBody, err := p.BuildBody(p.position + 2 + ConLength)
	if err != nil {
		return nil, 0, err
	}

	//builds the vector. converts the []Token -> []Vistor
	True, err := p.PerformVector(TrueBody, object.Peer)
	if err != nil {
		return nil, 0, err
	}

	//sets the true vector
	NewCondition.True = True

	Size += 3 + p.TrueLength(Cons) + len(TrueBody)

	//peeks the next token inside the array item
	Else, err := p.peekNextToken(p.position + Size)
	if err == nil && Else.literal == "else" {

		//builds the false body
		FalseBody, err := p.BuildBody(p.position + Size + 3)
		if err != nil {
			return nil, 0, err
		}


		//builds the vector. converts the []Token -> []Vistor
		False, err := p.PerformVector(FalseBody, object.Peer)
		if err != nil {
			return nil, 0, err
		}

		//saves the false vistor array into the sheet correctly
		NewCondition.False = False

		Size += 3 + len(FalseBody)
	}

	return NewCondition, Size, nil
}


func (p *Parse) TrueLength(tokens [][]Token) (int) {
	var Object int = 0

	for _, TokenArray := range tokens {
		Object += len(TokenArray)
	}

	return Object
}

//gets all conditions to the token
func (p *Parse) BuildConditions(Con *Condition) ([][]Token, int, error) {

	//stores each different array of arrayTokens
	var Cons [][]Token = make([][]Token, 0)

	var CurrentStorage []Token = make([]Token, 0)

	var Size int = 0 

	//for loops through every position of the token until the end of the line
	for TokenPos := p.position + 1; TokenPos < len(p.Tokens); TokenPos++ {


		if p.Tokens[TokenPos].startPosition.Row != Con.OriginToken.startPosition.Row {
			return make([][]Token, 0), 0, errors.New("failed to correctly find the body to the if statement safely")
		} else if p.Tokens[TokenPos].literal == "{" {
			Cons = append(Cons, CurrentStorage)
			return Cons, Size + p.TrueLength(Cons), nil
		} else if p.Tokens[TokenPos].literal == "||" {
			Size += 1
			Cons = append(Cons, CurrentStorage)
			CurrentStorage = make([]Token, 0)
		} else {
			CurrentStorage = append(CurrentStorage, p.Tokens[TokenPos])
		}
	}

	return make([][]Token, 0), 0, errors.New("condition body was never opened safely")
}

//builds statements associated with custom information
//mainly used on call functions and using builtin functions
func (p *Parse) BuildRequest(object *Vistor) (*CallRequest, int, error) {

	//makes the new request structure we will use to pass into the interpreter
	var NewRequest *CallRequest = &CallRequest{
		OriginToken: p.Tokens[p.position],
	}

	//gets all arguments leading upto the bracket function
	Princ, err := p.GetPrinciples()
	if err != nil {
		return nil, 0, err
	}

	//saves the principles into the array safely
	NewRequest.Principles = Princ

	//creates a variable to store the safe size
	SafeSize := len(Princ)

	//checks if the last token gathered was a argument opening we will parser it
	if Princ[len(Princ)-1].literal == "(" {
		//gets the arguments used
		Propertys, err := p.GetPropertys(p.position + len(Princ))
		if err != nil {
			return nil, 0, err
		}


		if p.Tokens[p.position + len(Princ) + len(Propertys)].literal != ")" {
			return nil, 0, errors.New("parser: EOF. statement opened but never closed")
		}


		//adds onto the safe size of the function
		SafeSize = SafeSize + len(Propertys)

		//saves the tokens into the array
		NewRequest.RequiredPropertys = Propertys
	}



	return NewRequest, SafeSize, nil
}

//gets the arguments used inside the request
//mainly used to gather all the arguments used inside a token array
func (p *Parse) GetPropertys(opens int) ([]Token, error) {

	//makes an array which we will store our tokens inside
	var TokensGotten []Token = make([]Token, 0)

	//for loops through the tokens gathering each one until the break point
	for starting := opens; starting < len(p.Tokens); starting++ {

	

		//gets all the tokens until that argument
		if p.Tokens[starting].literal == ")" {
			return TokensGotten, nil
		}

		//saves the token into the array
		TokensGotten = append(TokensGotten, p.Tokens[starting])
	}


	return nil, errors.New("parser: EOF")
}

//gets how many positions are between the orginal tokens and the nearest new line or semi-colon
func (p *Parse) GetPrinciples() ([]Token, error) {

	//creates a new token array which we will store our information inside
	var Gotten []Token = make([]Token, 0)

	//for loops through the tokens gathering each one
	for PositionTemp := p.position; PositionTemp < len(p.Tokens); PositionTemp++ {
		//breaks the looping
		if p.Tokens[p.position].startPosition.Row != p.Tokens[PositionTemp].startPosition.Row || p.Tokens[PositionTemp].literal == "(" {
			Gotten = append(Gotten, p.Tokens[PositionTemp])
			break
		}

		//saves the token into the array
		Gotten = append(Gotten, p.Tokens[PositionTemp])
	}

	return Gotten, nil
}

//builds a var/const statement
//this function builds the needed constrants to use the structure
func (p *Parse) BuildForgeReq(object *Vistor) (*Forge, int, error) {
	var NewVarConst *Forge = &Forge{
		OriginToken: p.Tokens[p.position],
	}

	//peeks the next token which should be the next value/variable name
	NextTask, err := p.peekNextToken(p.position)
	if err != nil {
		return nil, 0, err
	}

	//stores the value which is going to be used
	NewVarConst.Value = *NextTask


	//trys to get the next statement which should be the assign which assigns the name to the variable
	Assign, err := p.peekNextToken(p.position + 1)
	if err != nil {
		return nil, 0, err
	}

	//checks if the next position token is the correct one we need
	if Assign.literal != "=" {
		return nil, 0, errors.New(NewVarConst.OriginToken.literal+" | found `"+Assign.literal+"`, want `=`")
	}
	
	//gets all the valid arguments which we can use 
	Tokens, err := p.GrabForgeReqs(p.Tokens[p.position])
	if err != nil {
		return nil, 0, err
	}

	// if len(Tokens) < 0 {
	// 	return nil, 0, errors.New(NewVarConst.OriginToken.literal+" | missing objects to assign")
	// }

	//makes sure that the orginal first place is the type
	NewVarConst.OfficialType = Tokens[0].VType

	//gets all the valid arguments
	NewVarConst.Values = Tokens

	return NewVarConst, 3 + len(Tokens), nil
} 

//grabs all arguments used inside the statement
//this will be assigned to the variable name inside the interpreter
//this will accept everything until either the statement has finished or a new line is detected
func (p *Parse) GrabForgeReqs(firstToken Token) ([]Token, error) {
	//stores the array of tokens we will feed all valid tokens into
	var Tokens []Token = make([]Token, 0)


	//for loops through all active tokens
	for current := p.position + 3; current < len(p.Tokens); current++ {

		//if the token is either on a different line or the literal format if `;` we will break the loop
		if p.Tokens[current].startPosition.Row != firstToken.startPosition.Row || p.Tokens[current].literal == ";" {
			//exits the loop
			break
		}

		//appends the token onto the loop so far
		Tokens = append(Tokens, p.Tokens[current])

		//loops again
		continue
	}


	//checks if the length is bigger enough to be accepted
	if len(Tokens) <= 0 {
		//returns an error as 0 operants were found
		return nil, errors.New("EOF ("+firstToken.literal+") no literal assign found")
	}

	//returns the tokens we have found
	return Tokens, nil
}


//builds the function
//will grab all the information needed for the function
func (p *Parse) BuildFunction(object *Vistor) (*Function, int, error) {
	var NewFunction *Function = &Function{
		//sets the first token which idenfiyed the function from the others
		OriginToken: p.Tokens[p.position],
	}

	//gets the token which is next in line
	Property, err := p.peekNextToken(p.position)
	if err != nil {
		return nil, 0, err
	}

	//makes sure we add the token into the structure
	NewFunction.Property = *Property

	//builds the arguments getting every argument we need
	Arguments, err := p.BuildFunctionArguments()
	if err != nil {
		return nil, 0, err
	}

	//saves the arguments into the storage
	NewFunction.RequiredPropertys = Arguments

	//counts how many tokens are between the position and the next occurrence of that token
	TokensBetween, err := p.CountTill("{")
	if err != nil {
		return nil, 0, err
	}

	//gets all tokens until the body closes **SAFELY**
	BodyTokens, err := p.BuildBody(p.position + TokensBetween + 1)
	if err != nil {
		return nil, 0, err
	}

	//gets all the vistors inside that body
	Body, err := p.PerformVector(BodyTokens, &Parent{Parent: true, ParentVistor: object})
	if err != nil {
		return nil, 0, err
	}

	//saves the information into a format
	NewFunction.FunctionBody = Body

	//saves the function into the structure
	object.Function = *NewFunction

	//returns the new function propertys
	return NewFunction, TokensBetween + 1 + len(BodyTokens), nil
}

//parses all elements inside the body
//mainly used for if/function statements
func (p *Parse) PerformVector(tokens []Token, parent *Parent) ([]Vistor, error) {

	//creates an array for storing the vistors in
	var Collection []Vistor = make([]Vistor, 0)

	//for loops through the tokens which were passed in
	for starting := 0; starting < len(tokens); starting++ {


		//creates a new parser
		Vistor, size, err := p.node.createParser(starting, tokens).parseElement(parent)
		if err != nil {
			return nil, err
		}


		//checks if the vistor is equal to nil
		if Vistor == nil {
			//ignores
			continue
		}

		//saves the vistor information into the array
		Collection = append(Collection, *Vistor)

		//skips the positions needed to reach the next POI
		starting += size
	}

	//returns the array
	return Collection, nil
}

//grabs all the arguments from the function safely
func (p *Parse) BuildFunctionArguments() ([][]Token, error) {

	//gets how many tokens are inbetween the start position and the charater `(`
	Skip, err := p.CountTill("(")
	if err != nil {
		return make([][]Token, 0), err
	}

	//creates an array of strings which we will store our arguments in
	var Safely []Token = make([]Token, 0)

	//for loops all tokens from the position of the charater `(` which has been counted
	for starting := p.position + Skip + 1; starting < len(p.Tokens); starting++ {

		//checks if the charater detected is the closing of the arguments
		if p.Tokens[starting].literal == ")" {
			//exits the loop
			break
		}

		//adds the token into the array of tokens
		Safely = append(Safely, p.Tokens[starting])
	}
	

	return p.SplitArguments(Safely)
}

//splits all the arguments
//gets all the arguments from the function spliting into other arrays by the comma 
func (p *Parse) SplitArguments(Tokens []Token) ([][]Token, error) {

	//cleared everytime we detect a comma
	var current []Token = make([]Token, 0)

	//this array won't change we will only push tokens once we have detected the string
	var Finish [][]Token = make([][]Token, 0)

	//ranges through all the tokens
	for _, token := range Tokens {

		if token.literal == "," {
			//pushs the latest split into the array
			Finish = append(Finish, current)
			//clears the old array
			current = make([]Token, 0)
			continue
		}

		//adds the current one into the temp array
		current = append(current, token)
	}
	//we will also push the last set of arguments into the array
	Finish = append(Finish, current)

	//returns the current array of arrays
	return Finish, nil
}


//function used to grab the function/if bodys
//by bodys i mean the script attched to each function/if which is passed into the interpreter
func (p *Parse) BuildBody(starting int) ([]Token, error) {
	/*
		- base example, we will count how many times a body is opened (while appending the token)
		- and we will count that we need an object to close it. meaning a instance can contain many bodys
	*/

	//allocated memory to the system
	var (
		BodyLec []Token = make([]Token, 0)
		AllocatedBraces int = 0
	)

	//ranges through the tokens
	for Position := starting; Position < len(p.Tokens); Position++ {

		//if a brace has been opened we will add one to our allocated
		if p.Tokens[Position].literal == "{" {
			//allocates one more position
			AllocatedBraces++
		}

		//if it is closed we will check how many need to be closed
		if p.Tokens[Position].literal == "}" {
			if AllocatedBraces <= 0 {
				//checks if there is any braces awaiting to be closed
				if AllocatedBraces > 0 {
					return nil, errors.New("parser: EOF")
				}

				//returns the tokens we gathered
				return BodyLec, nil
			}

			//removes one from the allocated
			AllocatedBraces--
		}

		//appends to the array
		BodyLec = append(BodyLec, p.Tokens[Position])
	}

	
	//returns the tokens we gathered
	return nil, errors.New("parser: EOF")
}


//used mainly in the functions/if
//counts the tokens inbetween we reach a certain point in the tokens line
func (p *Parse) CountTill(Want string) (int, error) {

	//for loops until the end of line has been reached safely
	for position := p.position; position < len(p.Tokens); position++ {
		//checks if the current token which is being picked is correct
		if p.Tokens[position].literal == strings.ToLower(Want) {
			return position - p.position, nil
		}
	}
	//returns -1 and the err if one happened
	return -1, errors.New("token which you are looking for couldn't be found safely")
}

//gets the token which is next in line
func (p *Parse) peekNextToken(pos int) (*Token, error) {
	//checks if the length of the tokens isn't bigger than the next charater
	if len(p.Tokens) <= pos + 1 {
		return nil, errors.New("failed to peek next charater")
	}

	//gets the token inline
	return &p.Tokens[pos + 1], nil
}

//works out the if the element has a parent
func (p *Parse) workParent(object *Vistor, peer *Parent) {
	if peer != nil {
		object.Peer = peer
	} else {
		object.Peer = &Parent{
			Parent:       false,
			ParentVistor: nil,
		}
	}
}