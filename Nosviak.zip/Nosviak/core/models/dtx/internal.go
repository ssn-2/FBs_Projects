package dtx

import (
	"errors"
	"fmt"
	"io"
	"reflect"
	"strings"
)

//creates a function which can be executed correctly and safely
func (exe *Evaluator) RegisterFunction(name string, dtx func(Arguments []Token, wr func(source []byte) (int, error)) error, termfx func(session io.Writer, args string) (int, error)) error {

	BuiltinFunctions = append(BuiltinFunctions, Builtin{
		FunctionName: name,
		WantedArguments: nil,
		UnlockArgs: true,
		FunctionBody: dtx,
		TermFXVersion: termfx != nil,
		TermFXFunction: termfx, 
	})

	return nil
}

func (exe *Evaluator) RegisterStructure(Header string, structure interface{}) error {

	value := reflect.ValueOf(structure)
	Type := value.Type()

	for position := 0; position < value.NumField(); position++ {

		if exe.Already(Type.Field(position).Name, Header) {
			return errors.New("variable is already registered inside that field")
		}

		var Storage Scope

		if value.Field(position).Type().Name() == "bool" {
			var Single Scope = Scope{
				Header: Header,
				Variable: strings.ToLower(Type.Field(position).Name),
				Type: "ident",
				Value: Token{
					startPosition: nil,
					endPosition: nil,
					literal: fmt.Sprint(value.Field(position).Interface()),
					VType: "ident",
					size: 0,
				},
				Constant: true,
			}

			Storage = Single

		} else {
			var Single Scope = Scope{
				Header: Header,
				Variable: strings.ToLower(Type.Field(position).Name),
				Type: value.Field(position).Type().Name(),
				Value: Token{
					startPosition: nil,
					endPosition: nil,
					literal: fmt.Sprint(value.Field(position).Interface()),
					VType: value.Field(position).Type().Name(),
					size: 0,
				},
				Constant: true,
			}

			Storage = Single
		}


		exe.GlobalScope = append(exe.GlobalScope, Storage)
	}

	return nil
}

//creates the new variable
func (exe *Evaluator) NewVariable(Header string, Name string, Token *Token, constant bool) error {

	//checks if the variable is already registered
	if exe.Already(Name, Header) {
		return errors.New("variable is already registered")
	}

	//stores the single array
	var Single Scope = Scope{
		Header: Header,
		Variable: Name,
		Type: Token.VType,
		Value: *Token,
		Constant: constant,
	}

	//saves into the array correctly
	exe.GlobalScope = append(exe.GlobalScope, Single)


	//returns the nil pointer
	return nil
}

//checks if the variable is already registered
func (exe *Evaluator) Already(header string ,Name string) bool {

	//ranges through all global scopes
	for _, savedName := range exe.GlobalScope {
		//compares the name
		if savedName.Variable == Name {

			if header != "" && savedName.Header != "" && header == savedName.Header || header == "" && savedName.Header == "" {
				return true
			}

		}
	}

	//returns false
	return false
}

//used as a quick checker
//just a simple interface
func (exe *Evaluator) SearchInternal(header string, sub string, scope []Scope) (error) {

	for _, System := range scope {
		
		if header != "" && System.Header != "" && System.Header == header && sub == System.Variable {
			return nil
		}
	}


	return errors.New("`" + header + "` hasn't got a field for `" + sub + "`")
}