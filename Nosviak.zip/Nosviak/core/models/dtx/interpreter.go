package dtx

import (
	"errors"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"

	"strconv"
	"strings"

	"github.com/oleksandr/conditions"
)

//interpreter/evaluator information
type Evaluator struct {
	//pass the parsers root node into the function
	//stores all the vistors which are parsed inside the parser
	//essentially stores the token/syntax tree which the parser performed & outputed
	Parser *Node

	//the writer which we will write to if there is any writer
	//standard is os.stdout
	Writer func(source []byte) (int, error)

	//stores all the global scopes which were made inside the function
	GlobalScope []Scope

	//stores all the functions as they are made safely
	Functions []Function
}



//scope acts as a variable storage
//mainly used in an array/map
type Scope struct {

	//used mainly only for variables which are dropped using structures
	Header string

	//stores the name which the scope is
	//the variable name
	Variable string

	//stores the scope type
	//mainly the variable which has been declared the type of it
	Type string

	//stores the value of the scope safely
	//stored as an interface so it can be executed anywhere
	Value Token

	//stores if the scope can be edited
	//if true the variable can't be edited at all
	Constant bool
}


//creates a new evaluator structure filled with information
func NewEvaluator(node *Node, Functions []Function) *Evaluator {
	return &Evaluator{
		Parser: node,
		Writer: func(source []byte) (int, error) {
			return fmt.Println(string(source))
		},
		Functions: Functions,
		GlobalScope: make([]Scope, 0),
	}
}


func DropEvaluator(node *Node, err error) *Evaluator {
	return &Evaluator{
		Parser: node,
		Writer: nil,
		Functions: make([]Function, 0),
		GlobalScope: make([]Scope, 0),
	}
}


//starts the interpreter (RootNode) with a custom writer so you can write to a device/interface
func (exe *Evaluator) RootNodeWR(wr func(source []byte) (int, error)) error {
	exe.Writer = wr
	return exe.RootNode()
}

//starts the main parser involded
//executes all vistors which have been given
func (exe *Evaluator) RootNode() (error) {
	//ranges through the basenodes from the parser
	for _, Vistor := range exe.Parser.BaseNode {
		//executes the evaluator on the vistor
		err, _ := exe.Eval(Vistor, nil, false)
		//handles any errors
		if err != nil {
			//returns the error
			return err
		}
	}

	return nil
}


func (exe *Evaluator) Eval(vistor Vistor, scope []Scope, parent bool) (error, []Scope) {
	switch vistor.VistorNode {
	//variable declaration statement

	case 2:
		//if statement support
		return exe.BuildConditional(&vistor.Conditional, scope), make([]Scope, 0)
	case 1:
		if parent {
			return errors.New("functions may not be made within a body!"), nil
		}
		exe.Functions = append(exe.Functions, vistor.Function)
		return nil, make([]Scope, 0)
	case 3:
		return exe.ExecuteFunction(vistor.CallRequest, scope), make([]Scope, 0)
	case 4:
		return exe.MakeVariable(vistor.Forge, scope, vistor.Peer.Parent)
	case 5:
		//creates a new termfx instance
		newTemplate := New()

		//ranges through all global variables which were made
		for _, Variable := range exe.GlobalScope {

			if Variable.Header != "" {
				newTemplate.RegisterRawVariable(Variable.Header+".$"+Variable.Variable, Variable.Value.literal)
			} else {
				newTemplate.RegisterVariable(Variable.Variable, Variable.Value.literal)
			}

		}

		for _, FunctionBuiltin := range exe.GetTermfxFunctions() {
			newTemplate.RegisterFunction(FunctionBuiltin.FunctionName, FunctionBuiltin.TermFXFunction)
		}

		source, err := newTemplate.ExecuteString(vistor.Text.Source)
		if err != nil {
			return err, make([]Scope, 0)
		}


		if _, err := exe.Writer([]byte(source)); err != nil {
			return err, make([]Scope, 0)
		}

	}
	return nil, make([]Scope, 0)
}


func (exe *Evaluator) BuildConditional(Con *Condition, scope []Scope) error {


	V, err := exe.WorkConditional(Con.Conditions, scope)
	if err != nil {
		return err
	}

	if V  {

		if Con.True == nil {
			return errors.New("nil body, no body was attached to the question!")
		} else if len(Con.True) <= 0 {
			return nil
		}

		if err := exe.PerformVector(Con.True, scope); err != nil {
			return err
		}

		return nil
	} else if Con.False != nil {
		if err := exe.PerformVector(Con.False, scope); err != nil {
			return err
		}

		return nil
	}


	


	return nil
}

func (exe *Evaluator) WorkConditional(TokenInvolded [][]Token, Scope []Scope) (bool, error) {


	var Sections [][]string = make([][]string, 0)
	for _, Tkn := range TokenInvolded {

		var Current []string = make([]string, 0)

		//ranges through the array
		for _, Single := range Tkn {


			if Single.VType == "ident" {
				current, _, err := exe.SearchVariable(Single.literal, Scope)
				if err != nil {
					return false, err
				}

				if current.literal == "true" {
					return true, nil
				} else if current.literal == "false" {
					return false, nil
				}

				Single = *current
				
				if Single.VType == "string" {
					Single.literal = "\""+Single.literal+"\""
				}
			}


			Current = append(Current, Single.literal)
		}

		
		Sections = append(Sections, Current)
	}


	for _, Sample := range Sections {

		if strings.Join(Sample, "") == "" {
			continue
		}


		p := conditions.NewParser(strings.NewReader(strings.Join(Sample, "")))
		expr, err := p.Parse()
		if err != nil {
			return false, err
		}

		r, err := conditions.Evaluate(expr, nil)
		if err != nil {
			return false, err
		}

		if r {
			return true, nil
		}
	}
	
	return false, nil
}


//used to execute the function
//this is mainly used for when someone declares a function
func (exe *Evaluator) ExecuteFunction(vistor CallRequest, scope []Scope) error {


	//stores all possible arguments
	var Simple []string = make([]string, 0)

	//ranges through the function
	for _, Format := range vistor.Principles {

		if Format.literal == "(" {
			break
		}

		//saves into the array
		Simple = append(Simple, Format.literal)
	}


	//trys to get the internal function
	Function, err := exe.GetInteralFunction(strings.Join(Simple, ""))
	if err != nil {
		return exe.ExecuteBuiltin(vistor, scope)
	}


	//sorts the arguments via there split by `,`
	Arguments, err := exe.SortArguments(vistor.RequiredPropertys)
	if err != nil {
		return err
	}

	//stores the array we will sort our arguments into after
	var Complete []Token = make([]Token, 0)

	//ranges through the array of arrayTokens
	for _, TokenArray := range Arguments {

		//outputs the tokens with anything they needed doing
		Output, err := exe.CompileTokens(TokenArray, scope)
		if err != nil {
			return err
		}

		if Output == nil {
			continue
		}

		//saves into the array
		Complete = append(Complete, *Output)
	}

	//gets all the arguments passed into the function
	Preps, err := exe.ParseFunctionArguments(*Function, Complete, scope)
	if err != nil {
		return err
	}

	//executes the function properly
	error := exe.PerformVector(Function.FunctionBody, Preps)
	if error != nil {
		return err
	}

	return nil
}

//executes the builtin function section
func (exe *Evaluator) ExecuteBuiltin(Call CallRequest, Scope []Scope) error {

	var Simple []string = make([]string, 0)

	//ranges through the function
	for _, Format := range Call.Principles {

		//checks if the builtin call has finished
		if Format.literal == "(" {
			break
		}

		//saves into the array
		Simple = append(Simple, Format.literal)
	}

	//gets the builtin function if it exists
	Builtin := exe.GetBuiltin(strings.Join(Simple, ""))
	if Builtin == nil {
		return errors.New("interpreter: failed to find the function wanted")
	}

	//sorts the arguments into mulitply arrays
	Tokens, err := exe.SortArguments(Call.RequiredPropertys)
	if err != nil {
		return err
	}

	//create a storage area
	var Complete []Token = make([]Token, 0)

	//ranges through the array of arrayTokens
	for _, TokenArray := range Tokens {

		//outputs the tokens with anything they needed doing
		Output, err := exe.CompileTokens(TokenArray, Scope)
		if err != nil {
			return err
		}

		if Output == nil {
			continue
		}

		//saves into the array
		Complete = append(Complete, *Output)
	}



	//executes the body
	err = Builtin.FunctionBody(exe.RemoveCommas(Complete), exe.Writer)
	if err != nil {
		return err
	}

	//returns nil
	return nil
}

//sorts all the arguments into different section
func (exe *Evaluator) SortArguments(Arguments []Token) ([][]Token, error) {

	//stores everything the current function has gotten
	var Section [][]Token = make([][]Token, 0)

	var Push []Token = make([]Token, 0)

	for _, Arg := range Arguments {


		//checks if its a comma
		if Arg.literal == "," {
			//pushes the newer section
			Section = append(Section, Push)
			Push = make([]Token, 0)
			continue
		}

		//adds the token onto the array
		Push = append(Push, Arg)
	}

	//pushes the last section
	Section = append(Section, Push)

	return Section, nil
}


//parses the arguments which we passed safely into the function
func (exe *Evaluator) ParseFunctionArguments(Function Function, ArgumentsGiven []Token, ScopeCurrent []Scope) ([]Scope, error) {

	//creates an array of scopes which we wil fill in
	var ScopeStore []Scope = make([]Scope, 0)


	if ScopeCurrent == nil {
		ScopeCurrent = make([]Scope, 0)
	}

	ArgumentsGiven = exe.RemoveCommas(ArgumentsGiven)

	//ranges through the arguments wanted
	for Position, Token := range Function.RequiredPropertys {

		//checks the length of the token array
		if len(Token) == 0 {
			break
		}

		

		//checks the length of the token
		if len(Token) <= 1 {
			return make([]Scope, 0), errors.New("interpreter: missing a type declared with the variable")
		}

		//checks the length compared to the arguments given
		if len(Function.RequiredPropertys) != len(exe.RemoveCommas(ArgumentsGiven))  {
			Want, err := exe.PresentArgs(Function.RequiredPropertys)
			if err != nil {
				return make([]Scope, 0), err
			}

			return make([]Scope, 0), errors.New("interpreter: missing arguments, want func("+Want+")")
		}

		//checks if the argument is a variable
		if ArgumentsGiven[Position].VType == "ident" {
			//if so we will check inside the functions scope
			Token, _, err := exe.SearchVariable(ArgumentsGiven[Position].literal, ScopeCurrent)
			if err != nil {
				return make([]Scope, 0), err
			}
			//handles the information
			ArgumentsGiven[Position] = *Token
		}



		//compares the type
		if Token[1].literal != ArgumentsGiven[Position].VType {
			Want, err := exe.PresentArgs(Function.RequiredPropertys)
			if err != nil {
				return make([]Scope, 0), err
			}

			return make([]Scope, 0), errors.New("interpreter: invalid type, want func("+Want+")")
		} else {
			//creates the type
			ScopeStore = append(ScopeStore, Scope{
				Variable: Token[0].literal,
				Type: Token[1].literal,
				Value: ArgumentsGiven[Position],
				Constant: false,
			})

			//loops again
			continue
		}
	}

	//returns the scopes which were fuond
	return ScopeStore, nil
}


//removes all commas from the token string
func (exe *Evaluator) RemoveCommas(Tokens []Token) ([]Token) {

	//makes an array to stored informaiton in 
	var Santized []Token = make([]Token, 0)

	//ranges through the fnuctions
	for _, Token := range Tokens {

		//checks if the literal form is a comma
		if Token.literal == "," {
			//continues if so
			continue
		} else {
			//appends if not
			Santized = append(Santized, Token)
		}
	}

	//returns the array
	return Santized
}

//makes presenting the functions want clear/nicer to read
func (exe *Evaluator) PresentArgs(tokens [][]Token) (string, error) {

	var Text []string = make([]string, 0)

	for _, Token := range tokens {


		if len(Token) < 1 {
			return "", errors.New("interpreter: missing a type declared with the variable")
		} else {
			Text = append(Text, Token[1].literal)
		}
	}

	return strings.Join(Text, ", "), nil
}

//gets all internal functions
func (exe *Evaluator) GetInteralFunction(prop string) (*Function, error) {
	//ranges through the functions which have been registered
	for _, FunctionPass := range exe.Functions {

		//trys to match the function name to the property passed in
		if FunctionPass.Property.literal == prop {
			//returns the function
			return &FunctionPass, nil
		}
	}

	//returns nil and a error as the function has failed to be found
	return nil, errors.New("interpreter: failed to find the function wanted")
}




func (exe *Evaluator) PerformVector(vistors []Vistor, scope []Scope) error {

	//creates the scope we will use to fill the function with
	var Scope []Scope = scope

	//ranges through the function
	for _, vector := range vistors {


		//executes the block of vector using the scope made above
		err, New := NewEvaluator(&Node{BaseNode: vistors, position: exe.Parser.position, Lexer: exe.Parser.Lexer}, exe.Functions).Eval(vector, Scope, false)
		if err != nil {
			return err
		}
		//makes sure we apply the variable into the scope safely
		Scope = New
		//loops again safely
		continue
	}

	return nil
}

//makes a variable and inserts into the structure
//declares the variable either into the function scope
func (exe *Evaluator) MakeVariable(vistor Forge, scope []Scope, parent bool) (error, []Scope) {

	if _, constant, err := exe.SearchVariable(vistor.Value.literal, scope); err == nil && constant {
		return errors.New("interpreter: you may not edit/change a constant mid instance"), make([]Scope, 0)
	}
	//allocated memory to the new scope
	var tempScope *Scope = &Scope{}

	//checks if the variable is type constant
	if vistor.OriginToken.literal == exe.Parser.Lexer.Const() {
		//sets that the token is type constant
		tempScope.Constant = true
	}

	//creates the variable value for that object
	Token, err := exe.CompileTokens(vistor.Values, scope)
	if err != nil {
		return err, make([]Scope, 0)
	}
	
	if Token == nil {
		return errors.New("interpreter: EOF. position: "+strconv.Itoa(vistor.OriginToken.startPosition.Row)+":"+strconv.Itoa(vistor.OriginToken.startPosition.Col)), make([]Scope, 0)
	}

	var ObjectConstant bool = false

	//checks if the object is a constant
	if vistor.OriginToken.literal == exe.Parser.Lexer.Const() {
		ObjectConstant = true
	}

	//checks if the object has a parent
	if parent && scope != nil {
		//applys the object into the scope array
		scope = append(scope, Scope{Variable: vistor.Value.literal, Type: Token.VType, Value: *Token, Constant: ObjectConstant})
	} else {
		//saves the variable into the global scopes
		exe.GlobalScope = append(exe.GlobalScope, Scope{Variable: vistor.Value.literal, Type: Token.VType, Value: *Token, Constant: ObjectConstant})
	}

	
	return nil, scope
}

//compiles the token into an string
//we will check that the token states are correct and safe to use
//we will take the tokens array and the closed variable array incase they declare a no global one for the function
func (exe *Evaluator) CompileTokens(tokens []Token, Variables []Scope) (*Token, error) {

	if len(tokens) <= 0 {
		return nil, nil
	}

	//makes sure we parse the first position of the token array
	if tokens[0].VType == "ident" && tokens[0].literal != "true" && tokens[0].literal != "false"  {

		//searchs the new token
		New, _, err := exe.SearchVariable(tokens[0].literal, Variables)
		if err != nil {
			return nil, err
		}

		//assigns the first position in the array to this object
		tokens[0] = *New
	}

	if tokens[0].literal == "true" || tokens[0].literal == "false" {
		return &tokens[0], nil
	}

	//allows selection/different methods for parsing
	switch tokens[0].VType {

	case "int":

		//what we will store our mathmatical sum into
		var System []string = make([]string, 0)

		for Position, Token := range tokens {

			//checks if the current position is an odd number
			if Position % 2 != 0 {
				//checks if the operator is valid so it can be used
				if !OperatorValidate(Token.literal) {
					return nil, errors.New("interpreter: invalid operator. `"+Token.literal+"`!")
				}
				//saves the operator into the system
				System = append(System, Token.literal)
			} else if Position % 2 == 0 && Token.VType == "ident" {
				//searchs for the variable inside the global structures and the internal structures
				Variable, _, err := exe.SearchVariable(Token.literal, Variables)
				if err != nil {
					return nil, err
				}
				//checks that the variable type is safe
				if Variable.VType != "int" {
					return nil, errors.New("interpreter: `"+Token.literal+"` must be type int")
				}

				//assigns a new look onto the current token
				Token = *Variable

			}


			//if the literal format if a vaild operator
			if OperatorValidate(Token.literal) {
				//we will continue again
				continue
			}
			//converts the object to a type integer
			Num, err := strconv.Atoi(Token.literal)
			if err != nil {
				return nil, err
			}

			//saves into the array as type string
			System = append(System, strconv.Itoa(Num))
		}

		exp, err := parser.ParseExpr(strings.Join(System, " "))
		if err != nil {
			return nil, err
		}

		Conditional := exe.EvalMath(exp)

		return &Token{
			startPosition: tokens[0].startPosition,
			endPosition: tokens[0].endPosition,
			literal: strconv.Itoa(Conditional),
			VType: "int",
			size: 0,
		}, nil


	//detection for string const statements
	//TODO: implement support for choosing the variable system type 
	case "string":
		
		//joins all the tokens which were found safely into the array
		var System []string = make([]string, 0)

		//makes a new token structure which we will fill in later
		var VariableToken *Token = &Token{
			startPosition: tokens[0].startPosition,
			endPosition: tokens[0].endPosition,
			VType: "string",
		}

		//ranges through all the tokens which have been found
		for Position, Token := range tokens {
			/*
				- in strings we will only accept the `+` operator to join the string elements
			*/
			
			//we will check if we are excepting a `+` charater in this position
			if Position % 2 != 0 && Token.literal != "+" {
				return nil, errors.New("interpreter: EOF. expected `+` gotten "+Token.literal+"")
			} else if Position % 2 == 0 && Token.VType == "ident" {
				//searchs for the variable inside the global structures and the internal structures
				Variable, _, err := exe.SearchVariable(Token.literal, Variables)
				if err != nil {
					return nil, err
				}

				//checks that the variable type is safe
				if Variable.VType != "string" {
					return nil, errors.New("interpreter: `"+Token.literal+"` must be type string")
				}

				//saves the raw format into the array
				System = append(System, Variable.literal)

				//makes sure this token instance doesn't escape into the stream
				continue
			}

			//ignores the operator
			if Token.literal == "+" {
				//loops again
				continue
			}

			//checks the token type and if not a string returns an error
			if Token.VType != "string"  {
				//returns the error
				return nil, errors.New("interpreter: expected `string("+Token.literal+")`. given `"+Token.VType+"("+Token.literal+")`")
			}

			//applys the token into the system
			System = append(System, Token.literal)
		}

		//saves the literal format into the token
		VariableToken.literal = strings.ReplaceAll(strings.Join(System, ""), "\"", "")

		//saves the size into the token
		VariableToken.size = len(strings.ReplaceAll(strings.Join(System, ""), "\"", "")) - 1

		//returns the token information
		return VariableToken, nil

	}


	return nil, nil
}

//searchs through the scopes looking for the variable
func (exe *Evaluator) SearchVariable(Variable string, variables []Scope) (*Token, bool, error) {

	var Header string = ""
	if strings.Count(Variable, ".") == 1 {
		//searchs the internal fields
		if err := exe.SearchInternal(strings.Split(Variable, ".")[0], strings.Split(Variable, ".")[1], variables); err != nil {
			if err := exe.SearchInternal(strings.Split(Variable, ".")[0], strings.Split(Variable, ".")[1], exe.GlobalScope); err != nil {
				return nil, false, err
			}
		} 

		Variable = strings.Split(Variable, ".")[len(strings.Split(Variable, "."))-1]
		Header = strings.Split(Variable, ".")[0]
	}

	//searchs through the internal variables
	//internal variables are non global variables
	internal, constant, err := exe.searchScope(variables, Variable, Header)
	if err == nil {
		return &internal.Value, constant, nil
	}

	//searchs through the global variables array
	//these variables which are only declared are acessable everywhere
	external, constant, err := exe.searchScope(exe.GlobalScope, Variable, Header)
	if err == nil {
		return &external.Value, constant, nil
	}

	return nil, false, errors.New("interpreter: EOF. variable `"+Variable+"` couldn't be found safely")

}


//ranges through the array searching for a certain scope
func (exe *Evaluator) searchScope(scope []Scope, want string, header string) (*Scope, bool, error) {

	//ranges through the declares scopes inside the array
	for _, Variable := range scope {

		if Variable.Header == "" && header == "" && want == Variable.Variable {
			return &Variable, Variable.Constant, nil
		}

		//checks if the scope found is the correct option
		if header != "" && Variable.Header != "" {

			if want == Variable.Variable {
				return &Variable, Variable.Constant, nil
			}
		}
	}

	//returns the error if not
	return nil, false, errors.New("scope which was called doesn't exist inside the array")
}

//gets the next token
//used in mainly addition sums
func (exe *Evaluator) PeekNext(array []Token, position int) (*Token, error) {

	if len(array) < position + 1 {
		return nil, errors.New("Eval: EOF next token is blank")
	}


	//returns the next token inside the array
	return &array[position + 1], nil
}

func (exe *Evaluator) EvalMath(exp ast.Expr) int {
	switch exp := exp.(type) {
	case *ast.BinaryExpr:
		return exe.EvalBinaryExpr(exp)
	case *ast.BasicLit:
		switch exp.Kind {
		case token.INT:
			i, _ := strconv.Atoi(exp.Value)
			return i
		}
	}

	return 0
}

func (exe *Evaluator) EvalBinaryExpr(exp *ast.BinaryExpr) int {
	left := exe.EvalMath(exp.X)
	right := exe.EvalMath(exp.Y)

	switch exp.Op {
	case token.ADD:
		return left + right
	case token.SUB:
		return left - right
	case token.MUL:
		return left * right
	case token.QUO:
		return left / right
	}

	return 0
}