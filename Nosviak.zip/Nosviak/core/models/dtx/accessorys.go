package dtx

import "strings"

//detection for if the charater is a letter
func IsLetter(str string) bool {
	//checks if the string is equal a blank charater
	if str == "" {
		return false
	}

	//splits the string into a switch charater
	switch strings.ToLower(strings.Split(str, "")[0]) {

	//detects if the charater is a letter or not
	case "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "a", "s", "d", "f", "g", "h", "j", "k", "l", "z", "x", "c", "v", "b", "n", "m", ".":
		return true
	}
	//returns false
	return false
}

//detection for if the charater is a digit
func IsDigit(str string) bool {

	//checks if the string is blank
	if str == "" {
		return false
	}

	//splits the string into a switch charater
	switch strings.ToLower(strings.Split(str, "")[0]) {

	//detects if the charater is a letter or not
	case "1", "2", "3", "4", "5", "6", "7", "8", "9", "0":
		return true
	}
	//returns false
	return false
}

//takes an operator and will validate it
//used in the maths interpreter to check if a operator is alright to pass
func OperatorValidate(operator string) bool {
	//switch the operator
	switch operator {

	//correct operator
	case "+", "-", "*", "/":
		//returns true so its correctly
		return true
	}

	//returns false as its invaild
	return false
}

//amplifys the ansi escape codes inside the string so the user may use them
func AmplifyANSI(Source string) (string) {
	Source = strings.ReplaceAll(Source, "\\x1b", "\x1b")
	Source = strings.ReplaceAll(Source, "\\033", "\033")
	Source = strings.ReplaceAll(Source, "\\u001b", "\u001b")
	Source = strings.ReplaceAll(Source, "\\007", "\007")
	return Source
}