package dtx


/*
	- Different vistor types
			- [1] Function ✅
				- vistor is a type function 
			- [2] Conditional statement ✅
				- vistor is a type Conditional statements
			- [3] CallReq ❌
				- vistor is calling a function/builtin
			- [4] ForgeStatement ❌
				- vistor is declaring a new variable
			- [5] TextBody
				- anything which isn't written in a text body is written to the terminal
*/



type Vistor struct {

	//stores if the vistor has a parent
	//a parent can be a body which the vistor is made in
	//we stores as a *type incase its nil
	Peer *Parent

	//stores information about the vistors type
	//different types - vist line 5 till line 13
	VistorNode int

	//body if the Vistor is an condition statement
	Conditional Condition

	//function if the vistor is a function statement/
	//NOTE: if the Vistor.Peer.Parent == true there was an error
	Function Function
	
	//stores the callReq structure
	//used when the vistor is a type CallReq [3]
	//example of this would be echo(...)
	CallRequest CallRequest

	//stores the Forge structure
	//used when the vistor is a type ForgeStatement [4]
	Forge Forge


	//stores the text body structure
	//as this is a scripting lang, we will write to the terminal with this object
	Text *Text
}


type Forge struct {
	//stores the first token which started the request
	//vaildates the type of the requestg
	//it could be either `var` or `const`
	OriginToken Token

	//stores the variable name
	//this is what the variable will be stored under
	//what the variable will be entered as into the struct
	Value Token

	//stores the offical type of the variable being made
	//used so in the interpreter can identify the values
	OfficialType string

	//stores all tokens found inside the object
	Values []Token
}

//function declare structure, stores information about the structure
type Function struct {
	//stores the first token which started the request
	//the literal format should be the function storage
	OriginToken Token

	//stores the token which stores the function name
	//this is mainly used to store in the function scope map
	Property Token

	//stores an array of token arrays used for the arguments
	//each different slice array is split by the , inside the function arguments
	RequiredPropertys [][]Token

	//stores everything which the function shall return
	ReturnWant []Token

	//stores the all vistors found inside the body
	//used in the interpreter
	FunctionBody []Vistor
}

//vistor which is used to call a function vistor
type CallRequest struct {
	//stores the first token which started the request
	//the first token involded with the statement
	OriginToken Token

	//all the tokens leading upto the arguments
	Principles []Token

	//stores all the values passed into the function
	//each different slice is split by the , inside the function arguments
	RequiredPropertys []Token
}

//if statement structure, stores information about the object
type Condition  struct {
	//stores the first token which started the request
	OriginToken Token

	//stores all conditions for the if statement
	//stores an array of array of tokens so we can handle more than 1 condition
	Conditions [][]Token

	//stores all the parsed tokens inside the body if the condition is true
	True []Vistor

	//only applicable if there is an else body
	False []Vistor
}

//stores information about the parent body
type Parent struct {
	//stores if the token is inside a parent function
	//example would be if the variable/object is inside a function
	Parent bool

	//stores the parents vistor object
	//used to help the interpreter identify whats in a function/body
	ParentVistor *Vistor
}


type Text struct {
	//stores the source/text which was found
	Source string

	//stores the text bodys position
	Position *Position
}