package dtx

import "unicode/utf8"

//store information about the token
type Token struct {
	//starting position of the token
	//used mainly inside the parser to identify the position
	startPosition 	*Position
	
	//stores the closing position of the token
	//used mainly inside the parser to identify where the token finishes
	endPosition 	*Position

	//stores a literal form of the token
	//the raw/literal form of the token
	literal 		string

	//stores a bit of information of the token
	//stores the strings type
	VType 			string

	//stores the tokens size and how many positions is needed to be added on the end of the current scanner
	//stores how many charater places the char takes up
	size 			int
}

//basic scanner store (stores the position of which the lexer has scanned something)
type Position struct {
	//stores the col/row of the current object
	Col, Row int
}

//creates a new token
func CreateToken(literal string, position Position, typed string) (*Token) {

	var cache = &Position{
		Col: position.Col,
		Row: position.Row,
	}

	return &Token{
		startPosition: cache,
		endPosition: &Position{
			Row: cache.Row,
			Col: cache.Col + utf8.RuneCountInString(literal),
		},

		literal: literal,
		VType: typed,
		size: utf8.RuneCountInString(literal) - 1,
	}
}


func (lex *Lexer) Function() string {
	return "func"
}

func (lex *Lexer) Var() string {
	return "var"
}

func (lex *Lexer) Const() string {
	return "const"
}

func (lex *Lexer) Conditional() string {
	return "if"
}

func (lex *Lexer) Return() string {
	return "return"
}

//main different between exit & return is that **exit** will completely kill the instance unlike **return** which will finish the body which is being scanned
func (lex *Lexer) Exit() string {
	return "exit"
}

func (lex *Lexer) GetTokens() ([]Token) {
	return lex.tokens
}

func (token *Token) StartPos() (*Position) {
	return token.startPosition
}

func (token *Token) EndPosition() (*Position) {
	return token.endPosition
}

func (token *Token) Literal() (string) {
	return token.literal
}