package dtx

import (
	"os"
	"strconv"
	"unicode/utf8"
)


/*
		- Remove later
*/

func HandleAST(pos int) string {
	switch pos {
	case 1:
		return "Function"
	case 2:
		return "IF"
	case 3:
		return "FunctionCall"
	case 4:
		return "Declare"
	}

	return "EOF"
}

func (l *Lexer) DebugTokens(File string) error {
	FileLoaded, err := os.Create(File)
	if err != nil {
		return err
	}

	defer FileLoaded.Close()


	for _, token := range l.tokens {

		if token.VType == "text" {
			continue
		}

		if _, err := FileLoaded.WriteString(Filler(strconv.Itoa(token.startPosition.Row)+":"+strconv.Itoa(token.startPosition.Col), 10)+"|    "+Filler(token.VType, 15)+token.literal+"\r\n"); err != nil {
			return err
		}

	}

	return nil
}

func Filler(Object string, want int) string {

	var Correction = Object

	for Length := utf8.RuneCountInString(Object); Length < want; Length++ {
		Correction += " "
	}

	return Correction
}