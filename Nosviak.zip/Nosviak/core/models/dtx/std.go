package dtx

import (
	"errors"
	"fmt"
	"io"
	"strconv"
	"strings"
	"time"
)

type Builtin struct {
	//TODO: write a package handler
	Package string

	//stores the name the function will go by
	//this is used when the client wants to use it
	FunctionName string

	//stores the arguments we want
	//mainly used to detect what arguments we want
	WantedArguments []Argument

	//stores if we want argument length checking
	UnlockArgs bool

	//stores the function body which will execute
	FunctionBody func(Arguments []Token, wr func(source []byte) (int, error)) error

	//decides if you want the function to contain a termfx version
	TermFXVersion bool

	TermFXFunction func(session io.Writer, args string) (int, error)

}

type Argument struct {
	//stores the argument name
	//this will be stored into the scope when the function is executed
	Name string
	//stores the type of the argument we want
	//this is used in the function where you can specfiy the arguments
	Type string
}

//creates the argument for the array
func MakeArgument(Name, Type string) Argument {
	return Argument{
		Name: Name,
		Type: Type,
	}
}

var BuiltinFunctions []Builtin = []Builtin{
	{
		FunctionName:    "echo",
		WantedArguments: nil,
		UnlockArgs: true,
		FunctionBody: func(Arguments []Token, wr func(source []byte) (int, error)) error {

			//ranges through the tokens we have gotten
			for po, Token := range Arguments {
		

				//just checks if the first argument is a space
				if po > 0 {
					//prints a space charater
					if _, err := wr([]byte(" ")); err != nil {
						return err
					}
				}

				
				//replaces any string formats
				if _, err := wr([]byte(strings.ReplaceAll(Token.literal, "\"", ""))); err != nil {
					return err
				}

			}

			fmt.Println()


			return nil
		},
	},

	{
		FunctionName:    "clear",
		WantedArguments: nil,
		UnlockArgs: true,
		FunctionBody: func(Arguments []Token, wr func(source []byte) (int, error)) error {
			_, err := wr([]byte("\033c"))
			return err
		},

		TermFXVersion: true,
		TermFXFunction: func(session io.Writer, args string) (int, error) {
			return session.Write([]byte("\033c"))
		},
	},


	{
		FunctionName:    "sleep",
		WantedArguments: nil,
		UnlockArgs: true,
		FunctionBody: func(Arguments []Token, wr func(source []byte) (int, error)) error {
			if len(Arguments) < 1 {
				return errors.New("You must atleast include a duration")
			}

			duration, err := strconv.Atoi(Arguments[0].literal)
			if err != nil {
				return err
			}

			time.Sleep(time.Duration(duration) * time.Millisecond)
			return nil
		},

		TermFXVersion: true,
		TermFXFunction: func(session io.Writer, args string) (int, error) {

			duration, err := strconv.Atoi(args)
			if err != nil {
				return 0, err
			}

			time.Sleep(time.Duration(duration) * time.Millisecond)
			return 0, nil
		},
	},

}

//gets the builtin function
func (exe *Evaluator) GetBuiltin(literal string) *Builtin {

	//ranges through the array
	for _, Builtin := range BuiltinFunctions {

		//checks the current one
		if Builtin.FunctionName == literal {
			return &Builtin
		}
	}

	return nil
}

func (exe *Evaluator) GetTermfxFunctions() []Builtin {

	var Storage []Builtin = make([]Builtin, 0)

	for _, Builtin := range BuiltinFunctions {

		if Builtin.TermFXVersion && Builtin.TermFXFunction != nil {
			Storage = append(Storage, Builtin)
		}

	}
	return Storage
}

func (exe *Evaluator) RegisterVariable(rawTag string, variable string) {

}