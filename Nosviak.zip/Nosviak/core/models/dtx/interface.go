package dtx

import (
	"errors"
)

type Body struct {
	//stores the line which we will scan through looking for the body opening alert
	Line []string

	//stores the lexers current col
	//the line which the statement was found on
	current_Col int

	//stores if the body is opened in this array
	//if not this will be set to false
	Unlock bool

	//stores when the body was offical unlocked
	//used inside the lexer so we can skip until the body opens
	Unlocked int

	//stores the line which we can use to print as it contains no opening
	Source []string
}

//creates a new body instance
func (l *Lexer) NewBody() *Body {
	return &Body{
		Line:     l.currentLine,
		Unlock:   false,
		Unlocked: -1,
		Source: make([]string, 0),
	}
}

//executes the source
func (body *Body) Execute() (*Body, error) {


	for position, charater := range body.Line {
		//sets the current_col to the current position on the line
		body.current_Col = position

	

		NextChar, _ := body.NextCharater()



		//peeks the next charater
		if charater == "<" && NextChar == "?" {
			body.Unlock = true
			body.Unlocked = position
			return body, nil
		} else {
			//saves the current charater into the array
			body.Source = append(body.Source, charater)
			//loops again
			continue
		}
		
	}

	return body, nil
}

//looks for the next charater
func (body *Body) NextCharater() (string, error) {
	//checks the current line
	if len(body.Line) <= body.current_Col+1 {
		return "", errors.New("failed to get next charater")
	}

	//gets the next charater in the line
	return body.Line[body.current_Col + 1], nil
}