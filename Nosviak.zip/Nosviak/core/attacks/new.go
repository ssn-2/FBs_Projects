package attacks

import (
	Template "Nosviak/core/deployment/template"
	"Nosviak/core/masters/sessions"
	"Nosviak/core/models/configs/json"
	"errors"
	"strings"
)

//stores the attack information
//this will allow us to create custom methods
type Attack struct {
	//stores the sessions information
	//this will allow us to use dtx etc
	session *sessions.Session

	//stores the command array which the user inputed
	//this will take the entire command array which we can use later
	Command []string

	//takes all the targets (attack clients) which are being used to attack from
	//this option is mainly used for apis which are connected to the method
	Targets []string

	//the method which is being used
	//allows us to get more information about the method internally
	MethodUsed *Template.Method
}

//creates a new attack method
//this will allow us to access more information about the attack
func NewAttack(command []string, session *sessions.Session) (*Attack, error) {

	//trys to get the method using the first input of the command
	//this will allow us to correctly find the method safely
	Method, err := GetMethod(command[0])

	//err handles the getMethod statement
	//this will allow us to access the method
	if err != nil {
		//returns the error which was found
		return nil, err
	}

	//returns the attack structure
	return &Attack{
		//stores the command which is being executed into the structure
		Command: command,
		//stores all the apis which we will distrobute via
		Targets: Method.Targets,
		//stores the method which we are using
		MethodUsed: Method,
		//stores the session information
		session: session,
	}, nil
}


var (
	//err code when the method couldn't be found correctly
	ErrInvalidMethod error = errors.New("failed to correctly find the method which was asked for")
)

//gets the method from the methodsArray
//this allows us to get the method from the array correctly
func GetMethod(input string) (*Template.Method, error) {

	//ranges through all the methods created
	//this allows us to check for the method properly
	for _, method := range json.ContentApis.Methods {

		//compares the method given to the method located
		//this will check if the current method isn't the attack method
		if strings.EqualFold(strings.ToLower(method.Name), strings.ToLower(input)) {
			//returns the method input which we can use
			return &method ,nil
		}
	}

	//returns nil and an error as the method wasn't found
	//this will be able to detect the error in the main configuration
	return nil, ErrInvalidMethod
}