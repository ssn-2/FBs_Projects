package main

import (
	"Nosviak/core/masters"
	"Nosviak/core/database"
	"Nosviak/core/deployment"
	"Nosviak/core/models/views"
	"Nosviak/core/masters/commands"
	"Nosviak/core/masters/users/ranks"
	"Nosviak/core/models/configs/json"
	"Nosviak/core/models/configs/toml"

	"fmt"
	"log"
)


func main() {
	// graphical presentation of the version of the unit
	fmt.Printf("starting \x1b[1mNosviak\x1b[0m - [%s]\r\n\r\n", deployment.Version)

	fmt.Println(ranks.EncodeString([]ranks.Rank{{Name: "admin",Has: true}}))

	//makes a new json instance without issues
	prepJson := json.MakeJson(deployment.Assets) //this will ensure its done without issues 
	if err := prepJson.RunParser(); err != nil && err != json.ErrUnknownObject {
		//reports the instance err back to the user and kills the go instance
		log.Printf("Json: %s\r\n", err.Error())
		return
	} else {
		// graphical presentation of nil errors found
		log.Printf("[Json] (parsed all json extensions inside `%s`)\r\n", prepJson.Dir)
	}

	//creates the tomlParser without issues
	prepToml := Toml.MakeToml(deployment.Assets) //run parsers properly for toml
	if err := prepToml.RunParser(); err != nil && err != Toml.ErrUnknownObject {
		//reports the instance err back to the user and kills the go instance
		log.Printf("Json: %s\r\n", err.Error())
		return
	} else {
		// graphical presentation of nil errors found
		log.Printf("[Toml] (parsed all Toml extensions inside `%s`)\r\n", prepJson.Dir)
	}
	

	//pushes the connection towards the database
	//ensures its done without errors happening on requests
	if err := database.PushConnection(); err != nil {
		//reports the instance err back to the user and kills the go instance
		log.Printf("Database: %s\r\n", err.Error())
		return
	} else {
		// graphical presentation of the connection being made
		log.Printf("[Database] (correctly pushed for connection) ['%s'@'%s']\r\n", json.ContentConfig.Database.Username, json.ContentConfig.Database.Host)
	}


	//loads the entire branding sector properly
	//this will ensure its done without issues happening
	if err := views.FetchBranding(deployment.View); err != nil {
		//reports the instance err back to the user and kills the go instance
		log.Printf("Views: %s\r\n", err.Error())
		return
	} else {
		log.Printf("[Views] (correctly loaded branding from the directory `%s`) [%d]", deployment.View, len(views.Store))
	}

	//pushes the rank properly
	//this will ensure its done without errors
	PushRanks() //loads the ranks without issues


	//this starts the master server properly
	//this ensures its done without issues happening
	if err := masters.NewNetwork(); err != nil {
		//reports the instance err back to the user and kills the go instance
		log.Printf("Server: %s\r\n", err.Error())
		return
	}
}


func PushRanks() {
	//creates a store
	var StoreNonBody []commands.NonBodyFeature = make([]commands.NonBodyFeature, 0)
	//merges the toml map & the internal map
	ranks.MergeToml()

	//ranges through all the toml ranks correctly
	//we do it at this point to stop us from registering the internal roles
	for name, rank := range Toml.RanksToml.Ranks {
		//doesn't register inactive commands
		//makes sure every role we register is active
		if !rank.Status {
			continue
		}

		//makes sure we don't reregister 
		//this will ensure it isn't registered more than once
		if name == "admin" || name == "banned" {
			continue
		}

		//correctly stores the information as a command
		StoreNonBody = append(StoreNonBody, commands.NonBodyFeature{
			Name: name,
			Description: rank.Description,
			Permissions: rank.PermissionsPromote,
		})
		StoreNonBody = append(StoreNonBody, commands.NonBodyFeature{
			Name: name+"=true",
			Description: "promote a user to vipplus status",
			Permissions: rank.PermissionsPromote,
		})
		StoreNonBody = append(StoreNonBody, commands.NonBodyFeature{
			Name: name+"=false",
			Description: "demote a user from vipplus status",
			Permissions: rank.PermissionsPromote,
		})
	}

	//ranges through all the registered commands
	for index, command := range commands.Container {
		//checks if the commandName is the users information
		if command.Name != "users" {
			//loops again correctly
			continue
		}
		//updates the command inside the array properly
		commands.Container[index].NonBody = StoreNonBody
	}
}