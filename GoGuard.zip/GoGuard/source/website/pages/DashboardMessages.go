package pages

import "net/http"

func DashboardMessages(response http.ResponseWriter, request *http.Request) {

}
