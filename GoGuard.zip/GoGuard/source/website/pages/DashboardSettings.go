package pages

import "net/http"

func DashboardSettings(response http.ResponseWriter, request *http.Request) {

}
