package pages

import "net/http"

func DashboardAdministration(response http.ResponseWriter, request *http.Request) {

}
