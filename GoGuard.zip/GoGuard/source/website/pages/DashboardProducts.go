package pages

import "net/http"

func DashboardProducts(response http.ResponseWriter, request *http.Request) {

}
