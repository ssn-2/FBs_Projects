package pages

import "net/http"

func DashboardAnalytics(response http.ResponseWriter, request *http.Request) {

}
