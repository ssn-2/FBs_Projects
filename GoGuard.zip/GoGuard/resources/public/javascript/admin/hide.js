function hideModal() {
    document.getElementById("modal").style.visibility = "hidden";
    document.getElementById("dashboard").style.opacity = 1;
}