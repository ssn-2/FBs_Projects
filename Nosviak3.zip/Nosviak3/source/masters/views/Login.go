package views

import (
	"Nosviak3/source/db"
	"Nosviak3/source/config"
	"Nosviak3/source/db/funcs"
	"Nosviak3/source/masters/terminal"

	"bytes"
	"time"
)

// Login will attempt and represents the actual login process for connections
func Login(terminal *terminal.Terminal) error {
	for i := 0; i < config.Options.Ints("ssh", "maximum_auth_attempts"); i++ {
		err := terminal.ExecuteBranding(map[string]any{"attempt": i, "max_attempts": config.Options.Ints("ssh", "maximum_auth_attempts")}, "assets", "branding", "login", "header.kbm")
		if err != nil {
			return err
		}

		prompt, err := terminal.ExecuteBrandingToString(make(map[string]any), "assets", "branding", "login", "username.kbm")
		if err != nil {
			return err
		}

		username, err := terminal.Reader(prompt, config.Options.Ints("maximum_username_length")).ReadLine()
		if err != nil {
			return err
		}

		prompt, err = terminal.ExecuteBrandingToString(make(map[string]any), "assets", "branding", "login", "password.kbm")
		if err != nil {
			return err
		}

		password, err := terminal.Reader(prompt, config.Options.Ints("maximum_password_length")).ReadPassword("*")
		if err != nil {
			return err
		}

		// checks if the user exists or not, if not prints the user404 error
		user, err := db.Universal.GetUser(username)
		if err != nil || user == nil {
			err := terminal.ExecuteBranding(make(map[string]any), "assets", "branding", "login", "user404.kbm")
			if err != nil {
				return err
			}

			time.Sleep(3 * time.Second)
			continue
		}

		/* compares the password entered and the users password */
		if bytes.Equal(funcs.NewHash(user.Salt, []byte(password)), user.Password) {
			return Middleware(terminal, user)
		}

		err = terminal.ExecuteBranding(make(map[string]any), "assets", "branding", "login", "invalid_password.kbm")
		if err != nil {
			return err
		}

		time.Sleep(3 * time.Second)
	}
	return nil
}