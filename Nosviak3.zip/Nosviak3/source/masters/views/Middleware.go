package views

import (
	"Nosviak3/source/db"
	"Nosviak3/source/masters/sessions"
	"Nosviak3/source/masters/terminal"
)

/*
	Middleware.go executes between the login being confirmed and
	the connection transfer to the home_screen menu
*/

// Middleware interacts with the connection to help perform certain actions
func Middleware(terminal *terminal.Terminal, user *db.User) error {
	session := sessions.NewSession(user, terminal)
	return Prompt(session)
}