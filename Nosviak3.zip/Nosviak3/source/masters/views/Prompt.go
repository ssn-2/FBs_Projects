package views

import (
	"Nosviak3/source/masters/commands"
	"Nosviak3/source/masters/sessions"
	"strings"

	/* Registers all the default commands */
	"Nosviak3/source/masters/commands/autocomplete"
	_ "Nosviak3/source/masters/commands/registry"
)

// Prompt is what the home_screen is mainly mained as, this is where the prompt is rendered etc.
func Prompt(session *sessions.Session) error {
	err := session.ExecuteBranding(make(map[string]any), "home_splash.kbm")
	if err != nil {
		return err
	}

	/* Makes a new reader interface */
	reader := session.Terminal.Reader(">", -1)
	reader.TabMenu = autocomplete.NewAutoComplete(session).Menus

	for { 
		/* Executes the branding file which produces us our string prompt */
		if prompt, err := session.ExecuteBrandingToString(make(map[string]any), "prompt.kbm"); err == nil {
			reader.ModifyPrompt(prompt)
		}

		/* ReadLine will perform the reading operations */
		message, err := reader.ReadLine()
		if err != nil {
			return err
		}

		/* length of the message is equal to 0 */
		if len(message) == 0 {
			continue
		}

		switch commands.Handler.Execute(session, strings.Split(message, " ")...) {

		case nil:
			continue

		case commands.ErrUnknownCommand: // unknown command error
			err := session.ExecuteBranding(map[string]any{"command": strings.Split(message, " ")[0]}, "command_404.kbm")
			if err != nil {
				return err
			}
			
			continue

		default: // unknown error
			err := session.ExecuteBranding(map[string]any{"command": strings.Split(message, "")[0]}, "error_occurred_while_executing.kbm")
			if err != nil {
				return err
			}
			
			continue
		}
	}
}