package commands

import "sync"

// Handler is the default interface for the command handler
var Handler *CommandHandler = NewHandler()

// CommandHandler is the global interface required for the command handler
type CommandHandler struct {
	Commands []*Command
	mux      sync.Mutex
}

// NewHandler will create the required fields for the command handler
func NewHandler() *CommandHandler {
	return &CommandHandler{
		Commands: 	make([]*Command, 0),
		mux: 		sync.Mutex{},
	}
}

// AddCommand will attempt to register the command
func (ch *CommandHandler) AddCommand(command *Command) {
	for _, alias := range command.Aliases {
		cmd := ch.find(ch.Commands, alias)
		if cmd == nil {
			continue
		}

		panic("command already registered")
	}

	ch.mux.Lock()
	defer ch.mux.Unlock()
	ch.Commands = append(ch.Commands, command)
}