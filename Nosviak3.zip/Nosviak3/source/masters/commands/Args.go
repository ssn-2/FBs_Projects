package commands

import (
	"Nosviak3/source/masters/sessions"
	"strconv"
)

// Helps with the deference of each item
type Type int

const (
	String	Type = iota	// string go object
	Number	Type = 1	// number go object
	Boolean	Type = 2	// boolean go object
)

type Error func(*sessions.Session) error

// Argument will handle the naming convention of arguments
type Argument struct {
	Name	        		string
	Type				Type
	Error	      	      Error
	Required, Variadic	bool
	MissingRequired	 	Error
}

// toGoType will offer the support for converting the literal to the recommend type
func (arg *Argument) toGoType(literal string, session *sessions.Session) (any, error) {
	switch arg.Type {


	case String:
		return literal, nil

	case Number:
		conv, err := strconv.Atoi(literal)
		if err != nil {
			return nil, arg.Error(session)
		}

		return conv, nil

	case Boolean:
		conv, err := strconv.ParseBool(literal)
		if err != nil {
			return nil, arg.Error(session)
		}

		return conv, nil
	}

	return nil, arg.Error(session)
}

// newContext will produce the required information about the command entry
func (c *Command) newContext(session *sessions.Session, args ...string) (*Context, error) {
	var ctx *Context = new(Context)
	ctx.args = make(map[string]*contextArg)

	/* Iterates over all the args */
	for pos, argument := range c.Arguments {
		if len(args) <= pos  || len(args[pos:]) <= 0 {
			if argument.MissingRequired == nil || !argument.Required {
				continue
			}

			return nil, argument.MissingRequired(session)
		} 

		/* Implements the required fields */
		elements := []string{args[pos:][0]}
		if argument.Variadic {
			elements = args[pos:]
		}

		/* Converts to there true type */
		var appends []any = make([]any, len(elements))
		for pos, arg := range elements {
			converted, err := argument.toGoType(arg, session)
			if err != nil || converted == nil {
				return nil, err
			}

			appends[pos] = converted
		}

		ctx.args[argument.Name] = &contextArg{
			Type: 		argument.Type,
			Value: 	 	appends,
		}
	}

	return ctx, nil
}

// Get will return the context value required for the command
func (ctx *Context) Get(name string) *contextArg {
	val, ok := ctx.args[name]
	if !ok {
		return &contextArg{
			Type: 1024,
			Value: make([]any, 0),
		}
	}

	return val
}

// Converts the argument object into a string
func (ctx_arg *contextArg) String(i int) string {
	if ctx_arg.Type == String {
		return ctx_arg.Value[i].(string)
	}

	return ""
}

// Converts the argument object into a number
func (ctx_arg *contextArg) Number(i int) int {
	if ctx_arg.Type == Number {
		return ctx_arg.Value[i].(int)
	}

	return 0
}

// Converts the argument object into a boolean
func (ctx_arg *contextArg) Bool(i int) bool {
	if ctx_arg.Type == Boolean {
		return ctx_arg.Value[i].(bool)
	}

	return false
}
