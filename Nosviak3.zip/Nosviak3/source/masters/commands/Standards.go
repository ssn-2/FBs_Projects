package commands

import "Nosviak3/source/masters/sessions"

// UseBranding will implement the fields for the default matters
func UseBranding(p ...string) Error {
	return func(s *sessions.Session) error {
		return s.ExecuteBranding(make(map[string]any), p...)
	}
}

// NewArgument will create a structure required for the actual handler
func NewArgument(name string, typed Type, required bool, variadic bool, missingRequired Error, err Error) *Argument {
	return &Argument{
		Name: name,
		Type: typed,
		Required: required,
		Variadic: variadic,
		MissingRequired: missingRequired,
		Error: err,
	}
}

// ArrayToStrings will convert an array of commands into an array of strings
func (ch *CommandHandler) ArrayToStrings(commands []*Command) []string {
	destination := make([]string, 0)
	for _, command := range commands {
		destination = append(destination, command.Aliases...)
	}

	return destination
}