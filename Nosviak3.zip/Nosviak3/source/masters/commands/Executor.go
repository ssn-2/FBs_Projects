package commands

import (
	"Nosviak3/source/masters/sessions"
)

/*
	Executor.go will implement all the required fields all
	executing each source
*/

// Execute will perform the execution route for the command
func (ch *CommandHandler) Execute(session *sessions.Session, args ...string) error {
	command, index, err := ch.Search(args...)
	if err != nil || command == nil {
		return ErrUnknownCommand
	}

	if command.Execute == nil {
		return nil
	}

	context, err := command.newContext(session, args[index:]...)
	if err != nil || context == nil {
		return err
	}

	if err := session.Terminal.WriteString("\r"); err != nil {
		return err
	}

	return command.Execute(session, context)
}