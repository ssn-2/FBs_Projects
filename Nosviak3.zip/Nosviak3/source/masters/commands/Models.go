package commands

import (
	"Nosviak3/source/masters/sessions"
	"errors"
)

var (
	// ErrUnknownCommand is triggered when the command presented is unknown
	ErrUnknownCommand error = errors.New("unknown command has been recv")
)

type BodyFunc func(*sessions.Session, *Context) error

// Command is the model which is responsible for handling and configuring each command
type Command struct {
	Aliases 		[]string
	Description	      string
	Commands	 	[]*Command
	Arguments	      []*Argument
	Execute	      BodyFunc
	AutoComplete	func(*sessions.Session, int) []string
}

// Context is the model used within the actual command body, this allows us to access the arguments within the command easily
type Context struct {
	args map[string]*contextArg
}

// contextArg is what is required within the structure args map
type contextArg struct {
	Type 		Type
	Value		[]any
}