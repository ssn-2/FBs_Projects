package registry

import (
	"Nosviak3/source/masters/commands"
	"Nosviak3/source/masters/sessions"
)

/*
	Users.go is the main package header for the
	users subcommand, this will store all the
	subcommands and the main command.
*/

func init() {
	commands.Handler.AddCommand(&commands.Command{
		Aliases: 		[]string{"users"},
		Description: 	"moderation & management of users",
		Execute: 		func(session *sessions.Session, ctx *commands.Context) error {
			

			return nil
		},
	})
}