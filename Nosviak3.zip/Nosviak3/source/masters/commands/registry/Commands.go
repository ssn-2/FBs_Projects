package registry

import (
	"Nosviak3/source/config"
	"Nosviak3/source/masters/commands"
	"Nosviak3/source/masters/sessions"
	"Nosviak3/source/packages/gotable"
	"strings"
)

/*
	Commands.go will return an array of all the commands registered
	within the index, this also allows indexing for subcommands.
*/

func init() {
	commands.Handler.AddCommand(&commands.Command{
		Aliases: 		[]string{"commands"},
		Description: 	"view all registered commands",
		Arguments: 		[]*commands.Argument{commands.NewArgument("command", commands.String, false, false, nil, nil)},
		Execute: 	 	func(session *sessions.Session, context *commands.Context) error {
			scope := commands.Handler.Commands
			if len(context.Get("command").Value) >= 1 {
				subcommand, _, err := commands.Handler.Search(context.Get("command").String(0))
				if err != nil {
					return session.ExecuteBranding(map[string]any{"command": context.Get("command").String(0)}, "commands", "invalid_command.kbm")
				}

				scope = subcommand.Commands
			}

			table := gotable.NewTable(nil)
			table.SetHeader(&gotable.Row{
				Columns: []gotable.Element{
					{Align: gotable.AlignCenter, Text: session.ExecuteBrandingToStringNoError(make(map[string]any), "commands", "alias.kbm")},
					{Align: gotable.AlignCenter, Text: session.ExecuteBrandingToStringNoError(make(map[string]any), "commands", "description.kbm")},
				},
			})

			// iterates throughout the scope appending each command onto the gotable
			for _, command := range scope {
				table.AppendRow(&gotable.Row{
					Columns: []gotable.Element{
						{Align: gotable.AlignCenter, Text: session.ExecuteBrandingToStringNoError(map[string]any{"alias": strings.Join(command.Aliases, ",")}, "commands", "value_alias.kbm")},
						{Align: gotable.AlignCenter, Text: session.ExecuteBrandingToStringNoError(map[string]any{"description": command.Description}, "commands", "value_description.kbm")},
					},
				})
			}

			return table.PrintWithOptions(config.Options, session, "commands")
		},


		// AutoComplete will introduce the auto-complete functionality for non-registered commands args
		AutoComplete: func(s *sessions.Session, index int) []string {
			if index != 2 {
				return make([]string, 0)
			}

			return commands.Handler.ArrayToStrings(commands.Handler.Commands)
		},
	})
}