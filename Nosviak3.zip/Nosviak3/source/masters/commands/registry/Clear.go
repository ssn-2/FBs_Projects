package registry

import (
	"Nosviak3/source/masters/commands"
	"Nosviak3/source/masters/sessions"
)

/*
	Clear.go will implement the required registry for
	the clear command, this allows us to clear the screen
	easily
*/

func init() {
	commands.Handler.AddCommand(&commands.Command{
		Aliases: 		[]string{"clear", "cls"},
		Description: 	"clears your terminal screen",
		Execute: 		func(s *sessions.Session, ctx *commands.Context) error {
			return s.ExecuteBranding(make(map[string]any), "clear_splash.kbm")
		},		
	})
}