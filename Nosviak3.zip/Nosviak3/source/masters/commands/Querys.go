package commands

import (
	"strings"

	"golang.org/x/exp/slices"
)

// find will attempt to index within the array to find the matches
func (ch *CommandHandler) find(cmds []*Command, alias string) *Command {
	for _, command := range cmds {
		if !slices.Contains(command.Aliases, strings.ToLower(alias)) {
			continue
		}

		return command
	}

	return nil
}

// search will attempt to search within the main array
func (ch *CommandHandler) Search(args ...string) (*Command, int,  error) {
	if len(args) == 0 {
		return nil, 0, nil
	}

	command := ch.find(ch.Commands, args[0])
	if command == nil {
		return nil, 0, ErrUnknownCommand
	}

	/* checks if we want to index subcommands */
	if command.Commands == nil || len(command.Commands) == 0 || len(args) == 1 {
		return command, 1, nil
	}

	subcommand := ch.find(command.Commands, args[1])
	if subcommand == nil {
		return command, 1, nil
	}

	return subcommand, 2, nil
}