package autocomplete

import (
	"Nosviak3/source/masters/sessions"
	"Nosviak3/source/masters/terminal"
	"strings"
)

/*
	Init.go is triggered when tab is executed
	this, will help with the execution and handling of tab
*/

// Used within the trigger mechanism
type AutoComplete struct {
	session	 	*sessions.Session
}

// NewAutoComplete creates a new AutoComplete object
func NewAutoComplete(s *sessions.Session) *AutoComplete {
	return &AutoComplete{
		session: s,
	}
}

// CompleteCallback is triggered when someone attempts to press the tab key
func (au *AutoComplete) Menus(reader *terminal.Reader) (bool, error) {
	matrix := au.produceMatrix(reader)
	if len(matrix) == 0 {
		return false, nil
	}

	var index int = 0

	au.renderItems(reader, matrix...)
	defer au.remove(reader, index, matrix...)
	if err := au.hover(reader, index, matrix...); err != nil {
		return false, err
	}

	for {
		buf := make([]byte, 1)
		if _, err := reader.Terminal.Channel().Read(buf); err != nil {
			return false, err
		}

		switch buf[0] {

		case 127: // Backspace
			if err := au.remove(reader, index, matrix...); err != nil {
				return false, err
			}

			return false, nil

		case 9: // Tab
			index++
			if index >= len(matrix) {
				index = 0
			}


			if err := au.hover(reader, index, matrix...); err != nil {
				return false, err
			}

		case 13: // Normal indentation (enter)
			if index == -1 {
				return false, nil
			}
		
			au.remove(reader, index, matrix...)
			au.session.Terminal.Write([]byte(matrix[index][len(strings.Split(string(reader.Destination), " ")[strings.Count(string(reader.Destination), " ")]):]))
			reader.Destination = append(reader.Destination, []byte(matrix[index][len(strings.Split(string(reader.Destination), " ")[strings.Count(string(reader.Destination), " ")]):])...)
			return true, au.session.Terminal.WriteString("\r\n\r")

		default: // Handles any default character
			if index == -1 {
				return false, nil
			}
		
			au.remove(reader, index, matrix...)
			au.session.Terminal.Write([]byte(matrix[index][len(strings.Split(string(reader.Destination), " ")[strings.Count(string(reader.Destination), " ")]):]))
			reader.Destination = append(reader.Destination, []byte(matrix[index][len(strings.Split(string(reader.Destination), " ")[strings.Count(string(reader.Destination), " ")]):])...)
			return reader.HandleBuf(buf)
		}
	}
}