package autocomplete

import (
	"Nosviak3/source/masters/commands"
	"Nosviak3/source/masters/terminal"
	"strings"

	"golang.org/x/exp/slices"
)

// produceMatrix will return an array of all possible options
func (au *AutoComplete) produceMatrix(read *terminal.Reader) []string {
	descriptor := commands.Handler.ArrayToStrings(commands.Handler.Commands)
	if len(read.Destination) == 0 {
		return descriptor
	}

	// Defers how many spaces are included to work out what matrix we should display
	switch len(strings.Split(string(read.Destination), " ")) {

	case 1: // Main command
		destination, word := make([]string, 0), strings.Split(string(read.Destination), " ")[0]
		for _, command := range descriptor {
			if strings.HasPrefix(strings.ToLower(command), strings.ToLower(word)) {
				destination = append(destination, command)
			}
		}

		return destination

	case 2: // Second command
		command, index, err := commands.Handler.Search(strings.Split(string(read.Destination), " ")[0])
		if err != nil || index != 1 || command.Commands == nil && command.AutoComplete == nil {
			return make([]string, 0)
		}

		descriptor = commands.Handler.ArrayToStrings(command.Commands)
		if command.AutoComplete != nil {
			descriptor = append(descriptor, command.AutoComplete(au.session, 2)...)
		}

		destination, word := make([]string, 0), strings.Split(string(read.Destination), " ")[1]
		for _, command := range descriptor {
			if strings.HasPrefix(strings.ToLower(command), strings.ToLower(word)) {
				destination = append(destination, command)
			}
		}

		return destination

	default: // Extra commands from subcommands
		command, _, err := commands.Handler.Search(strings.Split(string(read.Destination), " ")[:2]...)
		if err != nil  || command.AutoComplete == nil {
			return make([]string, 0)
		}

		/* Loops through checks for no duplicates etc */
		destination, word := make([]string, 0), strings.Split(string(read.Destination), " ")[strings.Count(string(read.Destination), " ")]
		for _, command := range command.AutoComplete(au.session, strings.Count(string(read.Destination), " ") + 1) {
			if strings.HasPrefix(strings.ToLower(command), strings.ToLower(word)) && !slices.Contains(strings.Split(string(read.Destination), " ")[2:], strings.ToLower(command)) {
				destination = append(destination, command)
			}
		}
		
		return destination
	}
}