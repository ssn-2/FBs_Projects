package autocomplete

import (
	"Nosviak3/source/masters/terminal"
	"fmt"
	"strings"
)

/*
	UI.go will implement the tab menus user interface onto the terminal, this
	is like the actual tab menu interface.
*/

// renderItems will print all the items within the list
func (au *AutoComplete) renderItems(reader *terminal.Reader, items ...string) error {
	length := longestLine(items) + 2
	for pos, texture := range items {
		element, err := au.session.ExecuteBrandingToString(map[string]any{"text": texture + strings.Repeat(" ", length - len(texture))}, "tab_menus", "tab_line.kbm")
		if err != nil {
			return err
		}
		

		spacer := len(strings.Split(string(reader.Destination), " ")[strings.Count(string(reader.Destination), " ")])
		if spacer == 0 {
			spacer = -1
		}

		format := fmt.Sprintf("\033[%dD\x1b[%dB%s\033[%dA\033[%dD\033[%dC", spacer, pos + 1, element, pos + 1, length, spacer)
		if _, err = au.session.Terminal.Channel().Write([]byte(format)); err != nil {
			return err
		}
	}

	return nil
}

// remove will remove all the item from the terminal
func (au *AutoComplete) remove(reader *terminal.Reader, index int, items ...string) error {
	for pos := range items {
		spacer := len(strings.Split(string(reader.Destination), " ")[strings.Count(string(reader.Destination), " ")])
		if spacer == 0 {
			spacer = -1
		}

		if _, err := au.session.Terminal.Channel().Write([]byte(fmt.Sprintf("\033[%dD\033[%dB\033[1D\x1b[K\033[%dA\033[1C\033[%dC", spacer, pos + 1, pos + 1, spacer))); err != nil {
			return err
		}
	}

	/* Writes said payload to the terminal */
	payload := []byte(fmt.Sprintf(strings.Repeat(" ", len(items[index])) + "\x1b[%dD", len(items[index])))
	if _, err := reader.Terminal.Channel().Write(payload); err != nil {
		return err
	}

	return nil
}

// hover is when the user moves the cursor around
func (au *AutoComplete) hover(reader *terminal.Reader, hover int, matrix ...string) error {
	element, err := au.session.ExecuteBrandingToString(map[string]any{"text": matrix[hover]}, "tab_menus", "tab_selected.kbm")
	if err != nil {
		return err
	}

	opti := matrix[hover][len(strings.Split(string(reader.Destination), " ")[strings.Count(string(reader.Destination), " ")]):]

	/* Builds the terminal */
	var payload string = fmt.Sprintf("\x1b[%dB%s\033[%dD\x1b[%dA", hover + 1, element, len(matrix[hover]), hover + 1)
	if len(strings.Split(string(reader.Destination), " ")[strings.Count(string(reader.Destination), " ")]) > 0 {
		payload = fmt.Sprintf("\x1b[%dD", len(strings.Split(string(reader.Destination), " ")[strings.Count(string(reader.Destination), " ")])) + payload + fmt.Sprintf("\x1b[%dC", len(strings.Split(string(reader.Destination), " ")[strings.Count(string(reader.Destination), " ")]))
	}

	/* Performs the rendering */
	au.renderItems(reader, matrix...)
	reader.Terminal.Channel().Write([]byte(payload + fmt.Sprintf("\x1b[K\x1b[38;5;240m%s\x1b[0m\x1b[%dD", opti, len(opti))))
	return nil
}

// longestLine will return the longest line in the list
func longestLine(items []string) int {
	destination := 0
	for _, source := range items {
		if len(source) > destination {
			destination = len(source)
		}
	}

	return destination
}