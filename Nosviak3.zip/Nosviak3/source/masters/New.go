package masters

import (
	"Nosviak3/source/config"
	"os"

	"golang.org/x/crypto/ssh"
)

// New will attempt to spawn a brand new server process
func New() error {
	configuration, err := OpenConfig()
	if err != nil || configuration == nil {
		return err
	}

	server := &ssh.ServerConfig{
		NoClientAuth: 	   	true,
		MaxAuthTries: 	 	configuration.MaximumAuthAttempts,
		ServerVersion: 	 	"SSH-2.0-Nosviak3 " + config.Version,
	}

	contents, err := os.ReadFile(configuration.Key)
	if err != nil || contents == nil {
		return err
	}

	sign, err := ssh.ParsePrivateKey(contents)
	if err != nil || sign == nil {
		return err
	}

	server.AddHostKey(sign)
	return NewListener(configuration, server)
}