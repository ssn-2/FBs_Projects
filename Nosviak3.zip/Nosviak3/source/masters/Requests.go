package masters

import (
	"Nosviak3/source/masters/terminal"
	
	"encoding/binary"
	"golang.org/x/crypto/ssh"
)

// NewHandler will create another routine to handle the pure requests
func Requests(handle, other <-chan *ssh.Request, term *terminal.Terminal) error {
	for {
		select {

		/* Disgards anything being sent through here */
		case req, ok := <-other:
			if !ok || req == nil {
				return nil
			} 

			if err := req.Reply(true, nil); err != nil {
				return err
			}

		/* handle will attempt to handle the incoming connections */
		case req, ok := <-handle:
			if !ok || req == nil {
				return nil
			}

			switch req.Type {

			// default requests are just ignored
			default:
				if err := req.Reply(false, nil); err != nil {
					return err
				}

			// main allowed terminal requests
			case "pty-req", "shell", "exec":
				if err := req.Reply(true, nil); err != nil {
					return err
				}

			case "window-change":
				term.X, term.Y = binary.BigEndian.Uint32(req.Payload), binary.BigEndian.Uint32(req.Payload[4:])
			}
		}
	}
}