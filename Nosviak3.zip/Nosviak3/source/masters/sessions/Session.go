package sessions

import (
	"Nosviak3/source/db"
	"Nosviak3/source/masters/terminal"
	"sync"
)

/*
	Session.go will help with monitoring of the incoming
	connections, it helps keep a count/map of all open
	sessions.
*/

var (
	// Sessions is the map which contains all the sessions
	Sessions map[int]*Session = make(map[int]*Session)
	mux	   sync.Mutex
)

// Session will help with the monitoring of the incoming sessions
type Session struct {
	ID	      	int
	User	  	*db.User
	Terminal	*terminal.Terminal

}

// NewSession will attempt to create a brand new session structure and insert it into the map
func NewSession(user *db.User, term *terminal.Terminal) *Session {
	var s *Session = &Session{
		User: 	    	user,
		Terminal: 		term,
	}

	/* Finds a free ID then opens the theme */
	s.ID = FindFreeID()


	mux.Lock()
	defer mux.Unlock()
	Sessions[s.ID] = s
	return s
}