package sessions

import "path/filepath"

/*
	Branding.go will implement the functions required for the kaboom
	indexing to be complete, this will implement all packages and
	variables which are default defined inside a session.
*/


func (s *Session) ExecuteBranding(el map[string]any, p ...string) error {
	return s.Terminal.ExecuteBranding(s.Append(el), append(filepath.SplitList(filepath.Join("assets", "branding")), p...)...)
}

func (s *Session) ExecuteString(str string, el map[string]any) error {
	return s.Terminal.ExecuteString(str, s.Append(el))
}

func (s *Session) ExecuteBrandingToString(el map[string]any, p ...string) (string, error) {
	return s.Terminal.ExecuteBrandingToString(s.Append(el), append(filepath.SplitList(filepath.Join("assets", "branding")), p...)...)
}

func (s *Session) ExecuteStringToString(str string, el map[string]any) (string, error) {
	return s.Terminal.ExecuteStringToString(str, s.Append(el))
}

func (s *Session) ExecuteBrandingToStringNoError(el map[string]any, p ...string) string {
	text, err := s.ExecuteBrandingToString(el, p...)
	if err != nil {
		return "branding not found"
	}

	return text
}