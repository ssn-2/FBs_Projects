package sessions

/*
	Kaboom.go will implement the var registering function
	"Append", this will function will invole a map which
	is passed an as argument and returned from the seq
*/


// Append will register all the session deflicted vars, objects & functions
func (s *Session) Append(el map[string]any) map[string]any {
	el["user"] = User{Username: s.User.Username}

	return el
}

// User is what we will use to handle the user information
type User struct {
	Username	string
}