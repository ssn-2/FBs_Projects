package sessions

import (
	"sort"

	"golang.org/x/crypto/ssh"
	"golang.org/x/exp/maps"
)

/*
	Index.go will implement the features which help with
	managing each individual session
*/

// FindFreeID will attempt to find a free session
func FindFreeID() int {
	ids := maps.Keys(Sessions)
	sort.Ints(ids)

	if len(ids) == 0 {
		return 0
	}

	for current := 0; current < ids[len(ids) - 1]; current++ {
		if _, ok := Sessions[current]; ok {
			continue
		}

		return current
	}

	return len(Sessions)
}

// FindSessionFromChannel will attempt to find a session via the channel
func FindSessionFromChannel(channel ssh.Channel) *Session {
	for _, i := range Sessions {
		if i.Terminal.Channel() == channel {
			return i
		}
	}

	return nil
}

// RemoveSessionViaChannel will attempt to find the session via the channel and close it
func RemoveSessionViaChannel(channel ssh.Channel) {
	s := FindSessionFromChannel(channel)
	if s == nil {
		return
	}

	defer delete(Sessions, s.ID)
	channel.Close()
}