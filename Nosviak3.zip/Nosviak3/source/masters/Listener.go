package masters

import (
	"log"
	"net"

	"golang.org/x/crypto/ssh"
)

// NewListener will attempt to create a brand new TCP server
func NewListener(config *Config, server *ssh.ServerConfig) error {
	listener, err := net.Listen("tcp", config.Listener)
	if err != nil {
		return err
	}

	for {
		/* Accept() will allow the connection to open the conn and then handles it */
		conn, err := listener.Accept()
		if err != nil {
			continue
		}

		log.Printf("New TCP connection established from %s", conn.RemoteAddr().String())
		go HandleConnection(server, config, conn)
	}
}