package terminal

import (
	"bytes"
	"sync"

	"golang.org/x/crypto/ssh"
)

// Terminal helps handle the required bounds for certain elements
type Terminal struct {
	X, Y	 	uint32
	channel 	ssh.Channel
	conn		*ssh.ServerConn
	mux	      sync.Mutex
	buf	 	bytes.Buffer
}

// NewTerminal creates a new Terminal structure with specified bounds
func NewTerminal(channel ssh.Channel, conn *ssh.ServerConn) *Terminal {
	return &Terminal{
		channel: channel,
		conn:    conn,
		buf:     *bytes.NewBuffer(nil),
	}
}

func (T *Terminal) Channel() ssh.Channel { 
	return T.channel 
}