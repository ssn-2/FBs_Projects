package terminal

import (
	"fmt"
	"strings"
	"unicode/utf8"
)

/*
	Menus.go is a test file for implementing tab menus
*/

// tab implements the menu controlling, this allows us to select via the tab
func (r *Reader) tab() (bool, error) {
	elements := []string{"clear", "credits", "help", "commands", "attack", "attacks", "history", "users", "usrs", "sessions", "session", "logins", "login"}
	r.renderItems(20, elements...)
	defer r.cleanup(elements...)

	var i int = -1

	for {
		buf := make([]byte, 1)
		if _, err := r.terminal.channel.Read(buf); err != nil {
			return false, err
		}

		if buf[0] == 9 {
			if i+1 >= len(elements) {
				i = -1
			}
			i++
			r.renderItems(20, elements...)
			r.terminal.channel.Write([]byte(fmt.Sprintf("\033[%dB\x1b[38;5;26;48;5;231;1m%s\x1b[0m\033[%dA\r\x1b[%dC", i+1, elements[i]+strings.Repeat(" ", 20-len(elements)), i+1, utf8.RuneCountInString(r.prompt)+len(r.destination))))
			continue
		} else if buf[0] == 13 {
			r.cleanup(elements...)
			r.terminal.channel.Write([]byte(elements[i]))
			r.destination = append(r.destination, string(elements[i])...)
			return false, nil
		}

		return r.handleBuf(buf)
	}
}

// renderItems should render all the items onto the terminal
func (r *Reader) renderItems(length int, items ...string) {
	for p, text := range items {
		r.terminal.channel.Write([]byte(fmt.Sprintf("\033[%dB\r\033[%dC\x1b[48;5;231;38;5;16m%s\x1b[0m\033[%dA\r\x1b[%dC", p+1, utf8.RuneCountInString(r.prompt)+len(r.destination), text+strings.Repeat(" ", length-len(text)), p+1, utf8.RuneCountInString(r.prompt)+len(r.destination))))
	}
}

func (r *Reader) cleanup(items ...string) {
	for p, _ := range items {
		r.terminal.channel.Write([]byte(fmt.Sprintf("\033[%dB\033[1D\x1b[K\033[%dA\033[1C", p+1, p+1)))
	}
}
