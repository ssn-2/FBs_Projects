package terminal

import "fmt"

/*
	Reader.go will implement the functions required for the custom reading
	process, this allows us to implement multiple different ideas/objects
	within it.
*/

// Reader could be classed as a child structure for the Terminal stream
type Reader struct {
	prompt		 string
	Maximum	 	 int
	position	 	 int
	Terminal	 	 *Terminal
	Destination	 	 []byte
	mask 			 string
	history		 []string
	TabMenu	       func(*Reader) (bool, error)
	KeyPress		 func(rune, *Reader) (bool, error)
}

// Reader will make a brand new Reader interface required for said interface
func (term *Terminal) Reader(prompt string, Maximum int) *Reader {
	return &Reader{
		prompt: 	 		prompt,
		Maximum: 	 		Maximum,
		history: 	 	 	make([]string, 0),
		Terminal: 			term,
	}
} 

// ModifyPrompt will change the prompt currently being displayed
func (read *Reader) ModifyPrompt(prompt string) {
	read.prompt = prompt
}

// ReadPassword will read in from the input as a password
func (read *Reader) ReadPassword(mask string) (string, error) {
	read.mask = mask
	password, err := read.ReadLine()
	if err != nil {
		return "", err
	}

	read.mask = ""
	return password, nil
}

// ReadLine is our implementation of the custom reader interface
func (read *Reader) ReadLine() (string, error) {
	read.Destination = make([]byte, 0)
	read.position    = 0

	if err := read.Terminal.WriteString(read.prompt); err != nil {
		return "", err
	}

	for {
		buf := make([]byte, 1)
		if _, err := read.Terminal.channel.Read(buf); err != nil {
			return "", err
		}

		if read.KeyPress != nil {
			if ok, err := read.KeyPress(rune(buf[0]), read); err != nil || ok {
				return string(read.Destination), err
			}
		}

		/* handleBuf helps with the character recv */
		ok, err := read.HandleBuf(buf)
		if err != nil {
			return "", err
		}

		/* Enter key pressed */
		if ok {
			text := string(read.Destination)
			if len(read.Destination) > 0 {
				read.history = append(read.history, text)
			}

			return text, nil
		}
	}
}

// handleBuf will attempt to handle the incoming buffer from the Terminal
func (read *Reader) HandleBuf(buf []byte) (bool, error) {
	switch buf[0] {

	case 9:
		if read.TabMenu != nil {
			return read.TabMenu(read)
		}

	// backspace key detection
	case 127:
		if len(read.Destination) - 1 < 0 || len(read.Destination) - read.position - 1 < 0 {
			return false, nil
		}

		read.Destination = append(read.Destination[:len(read.Destination) - read.position - 1], read.Destination[len(read.Destination) - read.position:]...)
		payload := append([]byte{8}, append(read.ClearAhead(), read.Destination[len(read.Destination) - read.position:]...)...)
		if read.position > 0 {
			payload = append(payload, []byte(fmt.Sprintf("\033[%dD", read.position))...)
		}

		read.Terminal.channel.Write(payload)

	// sequence event key press detected
	case 27:
		nbuf := make([]byte, 6)
		if _, err := read.Terminal.channel.Read(nbuf); err != nil {
			return false, err
		}

		// Delete key
		if nbuf[2] == 126 {
			return false, nil
		} else if nbuf[1] == 68 {
			if read.position + 1 > len(read.Destination) {
				return false, nil
			}

			read.position++
			read.Terminal.channel.Write(append(buf, nbuf...))
			return false, nil
		} else if nbuf[1] == 67 {
			if read.position - 1 < 0 {
				return false, nil
			}

			read.position--
			read.Terminal.channel.Write(append(buf, nbuf...))
			return false, nil
		} else if nbuf[1] == 65 {
			return read.UpHistory()
		} else if nbuf[1] == 66 {
			return read.DownHistory()
		}

	// Enter key pressed
	case 13:
		return true, read.Terminal.WriteString("\r\n")

	// The list of all characters
	case 32 ,96, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 45, 61, 194, 172, 33, 34, 163, 36, 37, 94, 38, 42, 40, 41, 95, 43, 113, 119, 101, 114, 116, 121, 117, 105, 111, 112, 91, 93, 81, 87, 69, 82, 84, 89, 85, 73, 79, 80, 123, 125, 97, 115, 100, 102, 103, 104, 106, 107, 108, 59, 39, 35, 65, 83, 68, 70, 71, 72, 74, 75, 76, 58, 64, 126, 92, 122, 120, 99, 118, 98, 110, 109, 44, 46, 47, 124, 90, 88, 67, 86, 66, 78, 77, 60, 62, 63:
		if len(read.Destination) >= read.Maximum + 1 && read.Maximum >= 0 {
			return false, nil
		}

		char := buf[0]
		if len(read.mask) > 0 {
			char = read.mask[0]
		}
		
		payload := []byte{char}
		if read.position > 0 {
			payload = append(append(read.ClearAhead(), char), append(read.Destination[len(read.Destination) - read.position:], []byte(fmt.Sprintf("\033[%dD", read.position))...)...)
		}
		
		read.Terminal.channel.Write(payload)
		read.Destination = append(read.Destination[:len(read.Destination) - read.position], append([]byte{buf[0]}, read.Destination[len(read.Destination) - read.position:]...)...)
	}

	return false, nil
}