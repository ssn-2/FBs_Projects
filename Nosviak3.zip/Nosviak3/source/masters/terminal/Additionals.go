package terminal

import (
	"fmt"
	"strings"
)

/*
	Additionals.go is an extra go file which is used for implementing certain
	features such as "Tab complete" & "cursor memory". they are both managed
	within this file
*/

// UpHistory is executed when the up arrow
func (read *Reader) UpHistory() (bool, error) {
	return false, nil
}

// DownHistory is executed when the down arrow
func (read *Reader) DownHistory() (bool, error) {
	return false, nil
}

// clearAhead will produce an array of bytes full of spaces which fill in the rest of the line
func (read *Reader) ClearAhead() []byte {
	if read.Maximum <= -1  {
		return []byte{27, 91, 75}
	} else if read.Maximum - len(read.Destination) - read.position - 1 <= -1 {
		return make([]byte, 0)
	}

	return append([]byte(strings.Repeat(" ", read.Maximum - len(read.Destination) - read.position - 1)), []byte(fmt.Sprintf("\x1b[%dD", read.Maximum - len(read.Destination) - read.position - 1))...)
}