package terminal

import (
	"Nosviak3/source/config"
	"Nosviak3/source/kaboom"
)

// ExecuteString will execute a string directly through the terminal package
func (t *Terminal) ExecuteString(str string, el map[string]any) error {
	return kaboom.ExecuteString(str, t, config.Append(el))
}

// ExecuteBranding will directly execute the branding file through kaboom
func (t *Terminal) ExecuteBranding(el map[string]any, p ...string) error {
	return t.ExecuteString(config.GetBranding(p...), config.Append(el))
}

// ExecuteStringToString will directly execute the string and return it as a string
func (t *Terminal) ExecuteStringToString(str string, el map[string]any) (string, error) {
	return kaboom.ExecuteToString(str, config.Append(el))
}

// ExecuteBrandingToString will directly execute the branding but return as a string
func (t *Terminal) ExecuteBrandingToString(el map[string]any, p ...string) (string, error) {
	return t.ExecuteStringToString(config.GetBranding(p...), config.Append(el))
}