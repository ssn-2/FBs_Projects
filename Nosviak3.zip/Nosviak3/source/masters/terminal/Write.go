package terminal 

// Write is the normal terminal writing operation.
func (t *Terminal) Write(p []byte) (int, error) {
	return t.channel.Write(p)
}

// Write will write directly to the terminal
func (t *Terminal) WriteBytes(b []byte) error {
	t.mux.Lock()
	defer t.mux.Unlock() 
	if _, err := t.channel.Write(b); err != nil {
		return err
	}

	t.buf.Write(b)
	return nil
}

// WriteString writes the string to the terminal via the Write function.
func (t *Terminal) WriteString(s string) error {
	return t.WriteBytes([]byte(s))
}