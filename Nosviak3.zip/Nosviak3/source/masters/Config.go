package masters

import (
	"Nosviak3/source/config"
)

/*
	Config.go will attempt to load the servers configuration
	which will be used when configuring the servers startup

	This file will include the configuration parser
*/

// Config is what stores the configuration for servers, "ssh"
type Config struct {
	Key                 string `toml:"key"`
	Listener            string `toml:"listener"`
	MaximumAuthAttempts int    `toml:"maximum_auth_attempts"`
}

// OpenConfig will attempt to marshal from the configuration structure
func OpenConfig() (*Config, error) {
	var c *Config = new(Config)
	if err := config.Options.MarshalFromPath(c, "ssh"); err != nil {
		return nil, err
	}

	return c, nil
}