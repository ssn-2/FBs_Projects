package kaboom

import (
	"Nosviak3/source/kaboom/evaluator"
	"Nosviak3/source/kaboom/formatter"
	"Nosviak3/source/kaboom/lexer"
	"Nosviak3/source/kaboom/parse"
	"io"
)

// ExecuteString is the mainly supported function for executing kaboom within nosviak3
func ExecuteString(source string, wr io.Writer, elements map[string]any) error {
	lex := lexer.NewLexer(source, "\n", true)
	if err := lex.Start(); err != nil {
		return err
	}

	par := parse.NewParser(lex)
	if err := par.Start(); err != nil {
		return err
	}

	f := formatter.NewFormat(par)
	if err := f.Format(); err != nil {
		return err
	}

	evaluator := evaluator.NewEvaluator(wr, f)
	for name, value := range elements {
		evaluator.Go2Kaboom(name, value)
	}

	_, err := evaluator.Execute(wr)
	return err
}

