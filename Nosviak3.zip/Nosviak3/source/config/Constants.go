package config

const (
	// Version is the current version of the application
	Version 	= "v1.0"
)