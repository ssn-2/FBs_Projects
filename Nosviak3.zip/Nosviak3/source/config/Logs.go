package config

/*
	Logs.go will implement the parsing of certain configuration within
	the logging directory, this allows for stat accessing and monitoring
*/

// LogFileEvent will execute when a .csv file event happens
func LogFileEvent(b []byte, s string, m map[string]any) error {
	return nil
}