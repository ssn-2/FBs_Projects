package config

import "path/filepath"

/*
	Branding.go will implement the entire branding opening anid closing events
	which allows us to open branding files and handle them independently.
*/

// branding will store all the related branding information in bulk
var branding map[string][]byte = make(map[string][]byte)

// BrandingEvent represents the function which is called when a branding file is opened
func BrandingEvent(b []byte, s string, m map[string]any) error {
	mux.Lock()
	defer mux.Unlock()
	branding[s] = b
	return nil
}

// GetBranding returns the branding peice from the maps
func GetBranding(s ...string) string {
	return string(branding[filepath.Join(s...)])
}

// Append will allow us to implement certains things as default
func Append(session map[string]any) map[string]any {
	session["version"] = Version
	session["app"]     = Options.String("app")
	session["clear"]   = func() string {
		return "\x1bc"
	}


	return session
}