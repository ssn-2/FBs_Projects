package config

import (
	"Nosviak3/source/config/module"
	"sync"
)

/*
	Module.go will implement the features for
	using the module/goconfig elements which
	allow for a more compact parsing routine
*/

var (
	// elements should be a list of all directories you wish to run goconfig on
	Elements []string = []string{"assets"}

	// options will store the entire configuration bundler
	Options *goconfig.Options = new(goconfig.Options)

	// manage read & write operations
	mux sync.Mutex
)

// NewModuleExecutor will attempt to create a brand new configuration module
func NewModuleExecutor() error {
	element := goconfig.NewConfig()
	element.NewInclusion(".csv", LogFileEvent)
	element.NewInclusion(".kbm", BrandingEvent)
	err := element.Parse(Elements...)
	if err != nil {
		return err
	}

	Options, err = element.Options()
	if err != nil {
		return err
	}

	return nil
}