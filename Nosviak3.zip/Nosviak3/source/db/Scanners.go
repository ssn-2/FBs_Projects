package db

import "database/sql"

// scanUser will attempt to find a user from sql
func (u *universal) scanUser(rows *sql.Rows) (*User, error) {
	usr := new(User)
	return usr, rows.Scan(&usr.Username, &usr.Password, &usr.Salt, &usr.Theme)
}