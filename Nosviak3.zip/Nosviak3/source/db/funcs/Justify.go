package funcs

/*
	Justify.go will implement the ignorance of certain args
	and just target the first argument.
*/

// Justify implements the disabling of certain fields
func Justify(i ...any) any {
	if len(i) == 0 {
		return nil
	}

	return i[len(i) - 1]
}