package funcs

import (
	"crypto/rand"

	"golang.org/x/crypto/argon2"
)

/*
	Hasher.go will implement the the hashing function for
	Nosviak3 to use for accessing/modifying passwords.
*/

// NewHash wil make a new hash from the given password byte
func NewHash(salt, password []byte) []byte {
	return argon2.IDKey(password, salt, 3, 1024 * 64, 2, 64)
}

// NewSalt will make a new salt which can be used for the hashing
func NewSalt(bit int) []byte {
	destination := make([]byte, bit)
	if _, err := rand.Read(destination); err != nil {
		return NewSalt(bit)
	}

	return destination
}