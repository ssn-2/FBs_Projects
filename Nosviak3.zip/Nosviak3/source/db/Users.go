package db

import (
	"Nosviak3/source/db/funcs"
)

/*
	Users.go contains anything about user management for
	the functions like promoting & demoting users.
*/

// User is the structure we require for creating/getting & modifing user
type User struct {
	Username	 	 string
	Password	       []byte
	Salt			 []byte
	Theme	 	 	 string
}

// user is the standard structure for the root user
var user *User = &User{
	Username: 		"root",
	Theme: 		"default",
}

// InsertUser will insert the user into the database, automatically implements the hashing interface.
func (u *universal) InsertUser(user *User) error {
	user.Salt = funcs.NewSalt(32)
	user.Password = funcs.NewHash(user.Salt, user.Password)
	index := funcs.Justify(u.DB.Exec("INSERT INTO `users` (`username`, `password`, `salt`, `theme`) VALUES (?, ?, ?, ?);", user.Username, user.Password, user.Salt, user.Theme))
	if index == nil {
		return nil

	}
	
	return index.(error)
}

// GetUser will attempt to retrive the user from the database
func (u *universal) GetUser(username string) (*User, error) {
	index, err := u.DB.Query("SELECT `username`, `password`, `salt`, `theme` FROM `users` WHERE `username` = ?", username)
	if err != nil {
		return nil, err
	}

	index.Next()
	defer index.Close()
	return u.scanUser(index)
}

// GetUsers will return all the users found within the database
func (u *universal) GetUsers() ([]*User, error) {
	index, err := u.DB.Query("SELECT `username`, `password`, `salt`, `theme` FROM `users`")
	if err != nil {
		return nil, err
	}

	destination := make([]*User, 0)

	defer index.Close()
	for index.Next() {
		user, err := u.scanUser(index)
		if err != nil {
			return nil, err
		}

		destination = append(destination, user)
	}

	return destination, nil
}

// DeleteUser will attempt to delete a user from the database
func (u *universal) DeleteUser(username string) error {
	index := funcs.Justify(u.DB.Exec("DELETE FROM `users` WHERE `username` = ?", username))
	if index == nil {
		return nil
	}

	return index.(error)
}