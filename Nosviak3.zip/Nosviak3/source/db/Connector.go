package db

import (
	"database/sql"
	"time"

	_ "github.com/mattn/go-sqlite3"
)

/*
	Connector.go will actually prepare the new connection
	directly to the database, this will allow us to control
	what databases we defaultly create within the database
*/

// Universal will allow to hold all our information about the current instance in one place
type universal struct {
	DB	    	*sql.DB
	Config	*Configuration
	Init		time.Time
}

// universal is the privatised version of Universal
var Universal *universal = new(universal)

// NewUniversal will attempt to create a brand new connection with the database
func NewUniversal() error {
	config, err := OpenConfig()
	if err != nil {
		return err
	}

	/* Appends our information which we require */
	Universal.Config, Universal.Init = config, time.Now()
	Universal.DB, err = sql.Open("sqlite3", config.Local)
	if err != nil {
		return err
	}

	if err := Universal.DB.Ping(); err != nil {
		return err
	}

	return Universal.withSchemas()
}