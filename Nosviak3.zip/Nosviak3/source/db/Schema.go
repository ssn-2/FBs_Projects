package db

import (
	"Nosviak3/source/db/funcs"
	"encoding/hex"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"time"
)

/*
	Schema.go will implement the auto insertation of database tables to
	the database. this allows users to make there own database tables
	and have the nosviak3 api check if they exist and if not insert them
*/

// withSchemas will open the schemas directory and check that all the table formulas exist within the code
func (u *universal) withSchemas() error {
	return filepath.Walk(u.Config.Schemas, func(path string, info fs.FileInfo, err error) error {
		if err != nil || info == nil || info.IsDir() {
			return err
		}

		/* contents allows us to access the required information */
		contents, err := os.ReadFile(path)
		if err != nil || strings.Count(string(contents), "`") <= 1 {
			return err
		}

		/* Actually tries to grab the table name*/
		name := strings.Split(string(contents), "`")[1:2][0]
		query, err := u.DB.Query(fmt.Sprintf("SELECT * FROM %s", name))
		if err == nil && query != nil {
			return query.Close()
		}

		/* Inserts said table into the database */
		if _, err := u.DB.Exec(string(contents)); err != nil {
			return err
		}

		switch strings.ToLower(name) {

		// users will execute when we are trying to insert a new user
		case "users":
			user.Password = []byte(hex.EncodeToString(funcs.NewSalt(8)))
			fmt.Printf("\x1b[0;1;48;5;105;38;5;16m %s \x1b[0m \x1b[38;5;11;1musername\x1b[0m: %s\n", time.Now().Format("2006-01-02 15:04:05"), user.Username)
			fmt.Printf("\x1b[0;1;48;5;105;38;5;16m %s \x1b[0m \x1b[38;5;11;1mpassword\x1b[0m: %s\n", time.Now().Format("2006-01-02 15:04:05"), string(user.Password))
			if err := u.InsertUser(user); err != nil {
				return err
			}		
		}
		return nil
	})
}