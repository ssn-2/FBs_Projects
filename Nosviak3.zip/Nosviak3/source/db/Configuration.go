package db

import "Nosviak3/source/config"

// Configuration will store the entire data required for the configuration module
type Configuration struct {
	Schemas string `toml:"schemas"`
	Local   string `toml:"local"`
}

// OpenConfig will attempt to open the configuration required
func OpenConfig() (*Configuration, error) {
	var C *Configuration = new(Configuration)
	err := config.Options.MarshalFromPath(&C, "database")
	if err != nil {
		return nil, err
	}

	return C, nil
}