package gotable

// Style will implement the custom theme interfaces
type Style struct {

	// Leave as nil if you wish not to use.
	AboveHeader		*AboveHeader
	BelowTable		*BelowTable
	BelowHeader     BelowHeader
	Header			Header
	Value			ValueSector
}

// AboveHeader spawns above the header line, Leave as nil if you wish not to use.
type AboveHeader struct {
	Horizontal		 	string
	TopLeft			string
	TopRight			string
	MidwayIntersection	string
}

// BelowTable spawns above the header line, Leave as nil if you wish not to use.
type BelowTable struct {
	Horizontal		 	string
	BottomLeft			string
	BottomRight			string
	MidwayIntersection	string
}

// Header spawns inline with the headers fields.
type Header struct {
	Right			 	string
	Left				string
	Seperator			string
}

// BelowHeader will implement the spawning method
type BelowHeader struct {
	BottomLeftIntersection  string
	BottomRightIntersection string
	MidwayIntersection 	string
	Horizontal			string
}

// ValueSector will implement the each independent value field
type ValueSector struct {
	Left	  			string
	Right	  			string
	MidwayIntersection 	string
}

var (
	// Theses are non-overwrittable table styles
	Styles map[string]*Style = map[string]*Style{
		"unicode": Unicode,
		"default": Standard,
		"basic": Basic,
	}

	Unicode *Style = &Style{
		AboveHeader: &AboveHeader{
			Horizontal: "═",
			TopLeft: "╔",
			TopRight: "╗",
			MidwayIntersection: "╦",
		},

		BelowTable: &BelowTable{
			Horizontal: "═",
			BottomLeft: "╚",
			BottomRight: "╝",
			MidwayIntersection: "╩",
		},

		Header: Header{
			Right: "║",
			Left: "║",
			Seperator: "║",
		},

		BelowHeader: BelowHeader{
			BottomLeftIntersection: "╠",
			BottomRightIntersection: "╣",
			MidwayIntersection: "╬",
			Horizontal: "═",
		},

		Value: ValueSector{
			Left: "║",
			Right: "║",
			MidwayIntersection: "║",
		},
	}

	Standard *Style = &Style{
		Header: Header{
			Right: " ",
			Left: "",
			Seperator: " ",
		},

		BelowHeader: BelowHeader{
			BottomLeftIntersection: "",
			BottomRightIntersection: "➤",
			MidwayIntersection: "─",
			Horizontal: "─",
		},

		Value: ValueSector{
			Right: "",
			MidwayIntersection: " ",
		},
	}

	Basic *Style = &Style{
		AboveHeader: &AboveHeader{
			Horizontal: "─",
			TopLeft: "┌",
			TopRight: "┐",
			MidwayIntersection: "┬",
		},

		BelowTable: &BelowTable{
			Horizontal: "─",
			BottomLeft: "└",
			BottomRight: "┘",
			MidwayIntersection: "┴",
		},

		Header: Header{
			Right: "│",
			Left: "│",
			Seperator: "│",
		},

		BelowHeader: BelowHeader{
			BottomLeftIntersection: "├",
			BottomRightIntersection: "┤",
			MidwayIntersection: "┼",
			Horizontal: "─",
		},

		Value: ValueSector{
			Left: "│",
			Right: "│",
			MidwayIntersection: "│",
		},
	}
)