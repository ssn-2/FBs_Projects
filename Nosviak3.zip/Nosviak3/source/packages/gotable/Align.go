package gotable

// Align will decided where we render said value
type Align int

const (
	AlignCenter Align = 0
	AlignLeft   Align = 1
	AlignRight  Align = 2
)

// Return will ensure that the value returned is padding properly
func (E *Element) Return(i int) string {
	switch E.Align {

	/* Shifts the entire column across as much as possible */
	case AlignRight:
		shift := i - length(E.Text)
		return repeater(" ", shift) + E.Text
	
	/* AlignCenter will center the incoming text into the center of the screen */
	case AlignCenter:
		if length(E.Text) == i {
			return E.Text
		}

		left := (i / 2) - (length(E.Text) / 2)
		right := (i / 2) - (length(E.Text) / 2)
		if left + right + length(E.Text) > i {
			left--
		} else if left + right + length(E.Text) < i {
			right++
		}


		return repeater(" ", left) + E.Text + repeater(" ", right)

	/* Same as the AlignLeft function*/
	case AlignLeft:
		return E.Text + repeater(" ", i - length(E.Text))

	/* Same as the AlignLeft function*/
	default:
		return E.Text + repeater(" ", i - length(E.Text))
	}
}

// repeater will repeat a certian character a number of times
func repeater(char string, times int) string {
	destination := ""

	for i := 0; i < times; i++ {
		destination += char
	}

	return destination
}

func (t *Table) pad(c *Row, p int) {
	for r, i := range c.Columns {
		c.Columns[r].Text  = repeater(" ", p) + i.Text + repeater(" ", p)
	}
}