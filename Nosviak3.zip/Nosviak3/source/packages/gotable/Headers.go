package gotable

import "strings"

// buildHeaders will implement the entire header building process required.
func (t *Table) buildHeaders(dst []string, elements []int) ([]string, error) {

	// Checks if the instance wants header. 
	if t.Style.AboveHeader != nil || t.Style.AboveHeader != nil && len(t.Style.AboveHeader.Horizontal) > 0 && len(t.Style.AboveHeader.MidwayIntersection) > 0 && len(t.Style.AboveHeader.TopLeft) > 0 && len(t.Style.AboveHeader.TopRight) > 0 {
		dst = append(dst, "")
		dst[len(dst) - 1] += t.Style.AboveHeader.TopLeft
		for i := 0; i < len(elements); i++ {
			dst[len(dst) - 1] += strings.Repeat(t.Style.AboveHeader.Horizontal, t.columnVectors[i])
			if i + 1 < len(elements) {
				dst[len(dst) - 1] += t.Style.AboveHeader.MidwayIntersection
			}
		}
		
		/* Appends the end settings */
		dst[len(dst) - 1] += t.Style.AboveHeader.TopRight
	}

	/* Implements the building of each independent header. */
	dst = append(dst, "")
	dst[len(dst) - 1] += t.Style.Header.Left
	for i := 0; i < len(elements); i++ {
		dst[len(dst) - 1] += t.header.Columns[i].Return(t.columnVectors[i])
		if i + 1 < len(elements) {
			dst[len(dst) - 1] += t.Style.Header.Seperator
		}
	}

	/* Implements the the right field then creates the next element*/
	dst[len(dst) - 1] += t.Style.Header.Right
	dst = append(dst, "")
	dst[len(dst) - 1] += t.Style.BelowHeader.BottomLeftIntersection
	for i := 0; i < len(elements); i++ {
		dst[len(dst) - 1] += strings.Repeat(t.Style.BelowHeader.Horizontal, t.columnVectors[i])
		if i + 1 < len(elements) {
			dst[len(dst) - 1] += t.Style.BelowHeader.MidwayIntersection
		}
	}

	dst[len(dst) - 1] += t.Style.BelowHeader.BottomRightIntersection
	return dst, nil
}

// BelowTable will implement the bottom line of the table required
func (t *Table) BelowTable(dst []string, elements []int) []string {
	if t.Style.BelowTable == nil {
		return make([]string, 0)
	}

	dst = append(dst, t.Style.BelowTable.BottomLeft)
	for i := 0; i < len(elements); i++ {
		dst[len(dst) - 1] += strings.Repeat(t.Style.BelowTable.Horizontal, t.columnVectors[i])
		if i + 1 < len(elements) {
			dst[len(dst) - 1] += t.Style.BelowTable.MidwayIntersection
		}
	}

	dst[len(dst) - 1] += t.Style.BelowTable.BottomRight
	return dst
}