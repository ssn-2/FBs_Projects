package gotable


// Row is stored with an array of elements also know as columns.
type Row struct {
	Columns		 	[]Element
}

// Element represents each individual columns
type Element struct {
	Text	 	string
	Align		Align
}


// sort will implement the updating of the longest element feature.
func (t *Table) sort(r *Row) {
	if len(t.columnVectors) == 0 {
		t.columnVectors = make(map[int]int)
		for i := 0; i < len(r.Columns); i++ {
			t.columnVectors[i] = 0
		}
	}

	for proc, text := range t.columnVectors {
		indexed := r.Columns[proc].Text

		/* Checks if its longer than the current and updates it */
		if length(indexed) > text {
			t.columnVectors[proc] = length(indexed)
		}
	}
}