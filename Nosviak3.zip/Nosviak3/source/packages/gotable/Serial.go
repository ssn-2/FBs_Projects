package gotable

import (
	"regexp"
	"strings"
	"unicode/utf8"
)

// regular will ignore all ansi escapes which can be found within the string
const regular = "[\u001B\u009B][[\\]()#;?]*(?:(?:(?:[a-zA-Z\\d]*(?:;[a-zA-Z\\d]*)*)?\u0007)|(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PRZcf-ntqry=><~]))"

// length will work out the true length of the said indexation
func length(s string) int {
	return utf8.RuneCountInString(regexp.MustCompile(regular).ReplaceAllString(strings.ReplaceAll(s, "<i>", ""), ""))
}