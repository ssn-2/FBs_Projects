package gotable

import (
	"Nosviak3/source/config/module"
	"Nosviak3/source/masters/sessions"
	"strings"
)

// Print will render the current table to the terminal.
func (t *Table) Print(session *sessions.Session) error {
	contents, err := t.String()
	if err != nil {
		return err
	}

	lines := strings.Split(contents, "\n")
	if len(lines) >= int(session.Terminal.Y) && session.Terminal.Y > 0 {
		return nil
	}

	return session.Terminal.WriteString(contents + "\r\n")
}

// PrintWithOptions will implement certain items within the fields
func (t *Table) PrintWithOptions(options *goconfig.Options, session *sessions.Session, name string) error {
	if err := t.OpenTableConfig(options, name); err != nil {
		return err
	}

	return t.Print(session)
}