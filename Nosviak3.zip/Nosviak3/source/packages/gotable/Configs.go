package gotable

import (
	"Nosviak3/source/config/module"


	"encoding/json"
	"errors"
	"path/filepath"
	"strings"

	"github.com/BurntSushi/toml"
)

/*
	Configs.go is a builtin Nosviak3 package which allows us to open
	a specific configuration file to decided on the current table style
*/

// TableConfig will load from a goconfig structure
type TableConfig struct {
	Style		string 	`json:"style"`
	Cache	 	string  `json:"cache"`
}

// OpenTableConfig will load from a goconfig structure and helps decidied on which style to used on said tables
func (t *Table) OpenTableConfig(options *goconfig.Options, name string) error {
	contents, ok := options.Back().Files()[filepath.Join("assets", "commands", name + ".toml")]
	if !ok || contents == nil || len(contents) == 0 {
		return errors.New("unable to find assets (1)")
	}

	var config *TableConfig = new(TableConfig)
	if err := toml.Unmarshal(contents, &config); err != nil {
		return err
	}

	element, ok := options.Back().Files()[config.Cache]
	if !ok || len(contents) == 0 || contents == nil {
		return errors.New("unable to find assets (2)")
	}

	var styles map[string]*Style = make(map[string]*Style)
	if err := json.Unmarshal(element, &styles); err != nil {
		return err
	}

	/* Implements the required default theme */
	for name, structure := range Styles {
		styles[name] = structure
	}

	t.Style = Styles[strings.ToLower(config.Style)]
	if t.Style == nil {
		t.Style = Standard
	}

	return nil
}