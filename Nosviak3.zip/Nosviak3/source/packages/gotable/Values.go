package gotable

// RenderValues will implement the entire required system functionality
func (t *Table) RenderValues(dst []string, elements []int) []string {
	for _, element := range t.lines {

		dst = append(dst, t.Style.Value.Left)
		for i := 0; i < len(elements); i++ {
			dst[len(dst) - 1] += element.Columns[i].Return(t.columnVectors[i])
			if i + 1 < len(elements) {
				dst[len(dst) - 1] += t.Style.Value.MidwayIntersection
			}
		}

		dst[len(dst) - 1] += t.Style.Value.Right
	}

	return dst
}