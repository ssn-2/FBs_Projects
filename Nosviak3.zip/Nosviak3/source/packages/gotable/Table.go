package gotable

import (
	"sort"
	"strings"

	"golang.org/x/exp/maps"
)

// Table will actually prepare to render the signal to the said output
type Table struct {
	header		 	*Row
	lines			[]*Row

	/* Style allows for custom styles */
	Style			*Style

	// columnVectors will store all the longest line for each header field.
	columnVectors 	map[int]int
}

// NewTable will create a new table structure
func NewTable(style *Style) *Table {
	return &Table{
		Style: 		   style,
		header: 	   new(Row),
		lines: 		   make([]*Row, 0),
		columnVectors: make(map[int]int),
	}
}

// String will return the string representation of the table. 
func (t *Table) String() (string, error) {
	elements := maps.Keys(t.columnVectors)
	sort.Ints(elements)

	/* Compiles the headers into the string array passed */
	headers, err := t.buildHeaders(make([]string, 0), elements)
	if err != nil {
		return "", err
	}

	/* Compiles all the required values properly */
	out := t.RenderValues(make([]string, 0), elements)
	headers = append(headers, out...)
	headers = append(headers ,t.BelowTable(make([]string, 0), elements)...)
	return strings.Join(headers, "\r\n"), nil
}

// SetHeader will take in the header which has been given.
func (t *Table) SetHeader(r *Row) {
	t.pad(r, 4)
	t.sort(r)
	t.header = r
}

// AppendRow will attempt to take in the array into the lines field.
func (t *Table) AppendRow(r *Row) {
	t.pad(r, 4)
	t.sort(r)
	t.lines = append(t.lines, r)
}