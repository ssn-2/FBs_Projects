package glamour

/*
	Glamour.go will implement the pretty terminal interface
*/