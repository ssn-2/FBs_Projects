package main

import (
	"Nosviak3/source/config"
	"Nosviak3/source/db"
	"Nosviak3/source/masters"

	"fmt"
	"strings"
	"time"
)

func main() {
	fmt.Printf("\x1b[0;1;48;5;105;38;5;16m %s \x1b[0m \x1b[1;38;5;10mStarting\x1b[0m Nosviak3: %s\n", time.Now().Format("2006-01-02 15:04:05"), config.Version)

	/* Actually parses the configurations */
	if err := config.NewModuleExecutor(); err != nil {
		fmt.Printf("\x1b[0;1;48;5;105;38;5;16m %s \x1b[0m \x1b[1;38;5;9mError\x1b[0m occurred while trying to parse configuration: %v", time.Now().Format("2006-01-02 15:04:05"), err)
		return
	}

	fmt.Printf("\x1b[0;1;48;5;105;38;5;16m %s \x1b[0m \x1b[1;38;5;10mSuccessfully\x1b[0m parsed all (\x1b[38;5;11m%d\x1b[0m) configurations found within \"\x1b[38;5;9m%s\x1b[0m\"\n", time.Now().Format("2006-01-02 15:04:05"), len(config.Options.Back().Files()), strings.Join(config.Elements, ", "))

	/* Actually connects to the database */
	if err := db.NewUniversal(); err != nil {
		fmt.Printf("\x1b[0;1;48;5;105;38;5;16m %s \x1b[0m \x1b[1;38;5;9mError\x1b[0m occurred while trying to open the database: %v", time.Now().Format("2006-01-02 15:04:05"), err)
		return
	}

	fmt.Printf("\x1b[0;1;48;5;105;38;5;16m %s \x1b[0m \x1b[1;38;5;10mSuccessfully\x1b[0m opened the database (\"\x1b[0;38;5;9m%s\x1b[0m\")\n", time.Now().Format("2006-01-02 15:04:05"), config.Options.String("database", "local"))

	/* Actually tries to spawn the server */
	if err := masters.New(); err != nil {
		fmt.Printf("\x1b[0;1;48;5;105;38;5;16m %s \x1b[0m \x1b[1;38;5;9mError\x1b[0m occurred while trying to start the server: %v", time.Now().Format("2006-01-02 15:04:05"), err)
		return
	}
}
