# Nosviak3 

Nosviak3, the advance for the best

## Features

1. custom Configuration loader [goconfig](https://github.com/TheNosviak/goconfig)
2. SQLite driver support
3. Custom Schema support (modify existing tables and also have Nosviak3 insert your tables when missing)
4. Extremely efficient yet effective *SSH* server handler
5. Kaboom custom language package `lexer`, `parser`, `formatter` & `evaluator`
6. Customizable SSH login
7. Custom SSH input reader
8. SwingTab (customizable Tab menus editable within the kaboom language)
9. Advance type recognition command handle