
CREATE TABLE `users` (
      `username`  TEXT NOT NULL,
      `password`  BLOB NOT NULL,
      `salt`      BLOB NOT NULL,
      `theme`     TEXT NOT NULL
);