package lexer

import "errors"

var (
	// ErrNotImplemented for unimplemented types
	ErrNotImplemented = errors.New("not implemented")
)