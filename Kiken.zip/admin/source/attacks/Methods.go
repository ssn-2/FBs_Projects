package attacks

import (
	"fmt"
	"strings"
)

type Method struct {
	Name        string
	ID          int
	Description string
}

var Methods []Method = []Method{
	Method{
		ID:          0,
		Name:        "udpflood",
		Description: "generic UDP flood modified for increased performance",
	},

	Method{
		ID:          1,
		Name:        "udppps",
		Description: "generic UDP flood modified for increased packets per second",
	},

	Method{
		ID:          2,
		Name:        "tcpflood",
		Description: "generic TCP flood modified for increased performance",
	},

	Method{
		ID:          3,
		Name:        "tlsflood",
		Description: "TLS flood modified for bypassing",
	},
}

func init() {
	for _, flood := range Methods {
		fmt.Printf("[FLOOD] Registered (%s):(%d)\r\n", flood.Name, flood.ID)
	}
}

// IsMethod checks if a method is found
func IsMethod(name string) (*Method, bool) {
	for _, method := range Methods {
		if strings.ToLower(method.Name) == name {
			return &method,true
		}
	}

	return nil, false
}