package database

import (
	"database/sql"

	_ "github.com/mattn/go-sqlite3"
)

var ( 
	DB *sql.DB = nil
)

func OpenDatabase(db string) error {
	database, err := sql.Open("sqlite3", db)
	if err != nil {
		return err
	}

	if err := database.Ping(); err != nil {
		return err
	}

	DB = database
	return VerifyTables()
}