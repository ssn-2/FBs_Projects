package database

import "fmt"

var (
	// Holds all tables needed for kiken admin
	Tables map[string]string = map[string]string{
		"users": "CREATE TABLE `users` (`id` INTEGER PRIMARY KEY AUTOINCREMENT,`username` TEXT NOT NULL,`password` TEXT NOT NULL,`admin` INTEGER NOT NULL,`maxtime` INTEGER NOT NULL);",
	}

	HasUserTable bool = true
)

func VerifyTables() error {
	for table, contents := range Tables {
		query, err := DB.Query("SELECT * FROM " + table)
		if err == nil || query != nil {
			query.Close()
			continue
		}

		if table == "users" {
			HasUserTable = false
		}

		// Prepares the statement
		statement, err := DB.Prepare(contents)
		if err != nil {
			return err
		}

		// Executes the statement
		if _, err := statement.Exec(); err != nil {
			return err
		}

		fmt.Printf("[SQL] Created `%s` table\r\n", table)

		continue
	}

	if HasUserTable {
		return nil
	}

	// Creates the user inside the database
	if err := CreateUser(&User{Username: "root", Password: "root", MaxTime: 3000, Admin: 1}); err != nil {
		return err
	}

	fmt.Printf("[SQL] Created user (root:root)\r\n")

	return nil
}