package database


type User struct {
	ID       int
	Username string
	Password string
	Admin    int
	MaxTime  int
}

// GetUser gets the user via username and returns
func GetUser(username string) (*User, error) {
	prepared, err := DB.Prepare("SELECT `id`, `username`, `password`, `admin`, `maxtime` FROM `users` WHERE `username` = ?")
	if err != nil {
		return nil, err
	}

	result := prepared.QueryRow(username)
	if result.Err() != nil {
		return nil, result.Err()
	}

	var User User
	if err := result.Scan(&User.ID, &User.Username, &User.Password, &User.Admin, &User.MaxTime); err != nil {
		return nil, err
	}

	return &User, nil
}

// Make a user in the database
func CreateUser(user *User) error {
	_, err := DB.Exec("INSERT INTO `users` (`username`, `password`, `admin`, `maxtime`) VALUES (?, ?, ?, ?)", user.Username, user.Password, user.Admin, user.MaxTime)
	return err
}

// Delete user from the database
func DeleteUser(user *User) error {
	_, err := DB.Exec("DELETE FROM `users` WHERE `username` = ? AND `password` = ?", user.Username, user.Password)
	return err
}


// Promote user to admin
func PromoteUser(user *User) error {
	_, err := DB.Exec("UPDATE `users` SET `admin` = 1 WHERE `username` = ? AND `password` = ?", user.Username, user.Password)
	return err
}

// Demote user from admin
func DemoteUser(user *User) error {
	_, err := DB.Exec("UPDATE `users` SET `admin` = 0 WHERE `username` = ? AND `password` = ?", user.Username, user.Password)
	return err
}

// Demote user from admin
func ModifyMaxtime(user *User, maxtime int) error {
	_, err := DB.Exec("UPDATE `users` SET `maxtime` = ? WHERE `username` = ? AND `password` = ?", maxtime, user.Username, user.Password)
	return err
}

// GetUsers will return all users in the database
func GetUsers() ([]*User, error) {
	statement, err := DB.Prepare("SELECT `username` FROM `users`")
	if err != nil {
		return nil, err
	}

	query, err := statement.Query()
	if err != nil {
		return nil, err
	}

	defer query.Close()
	var users []*User = make([]*User, 0)

	for query.Next() {
		var username string = ""
		if err := query.Scan(&username); err != nil {
			return nil, err
		}

		user, err := GetUser(username)
		if err != nil {
			return nil, err
		}

		users = append(users, user)
	}

	return users, nil
}