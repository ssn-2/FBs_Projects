package commands

import "fmt"

func RegisterCommand(command *Command) {
	commands[command.Name] = command

	fmt.Printf("[COMMAND] Registered (%s)\r\n", command.Name)
}