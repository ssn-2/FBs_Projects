package commands

import (
	"strings"
	"sync"

	"golang.org/x/crypto/ssh"
	"golang.org/x/exp/slices"
	"golang.org/x/exp/maps"

	"admin/source/terminal"
)

var (
	commands map[string]*Command = make(map[string]*Command)
	mutex    sync.Mutex
)

type Command struct {
	Name			string
	Prefix      	string	// if len == 0 ignores this
	Admin	 		bool
	Description 	string
	ColoursControl  bool
	Execute     	func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error
}

// IndexCommand will find the command and if the session can execute it
func IndexCommand(commandWanted string, permissions *ssh.Permissions) (*Command, error) {
	if len(commandWanted) <= 0 {
		return nil, nil
	}

	// Ranges through all commands
	for name, command := range commands {
		if len(command.Prefix) > 0 && strings.Join(strings.Split(commandWanted, "")[:len(command.Prefix)], "") != command.Prefix || strings.Join(strings.Split(commandWanted, "")[len(command.Prefix):], "") != name {
			continue
		}

		// Checks if command is admin
		if command.Admin && !slices.Contains(maps.Keys(permissions.CriticalOptions), "admin") {
			return nil, nil
		}
		
		return command, nil
	}

	return nil, nil
}