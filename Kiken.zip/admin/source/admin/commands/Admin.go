package commands

import (
	"admin/source/database"
	"admin/source/terminal"
	"strconv"

	"golang.org/x/crypto/ssh"
)

var Lockdown bool = false

func init() {
	// Promote command
	RegisterCommand(&Command{
		Name:        "promote",
		Prefix:      "",
		Admin:       true,
		Description: "Promote a user to admin",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			if len(args) <= 0 {
				return term.Write([]byte("\x1b[38;5;15mpromote requires a user argument!\x1b[0m\r\n"))
			}

			// Tries to fetch the user from the database
			user, err := database.GetUser(args[0]); if err != nil {
				return term.Write([]byte("\x1b[38;5;15m\""+args[0]+"\" doesnt exist in the database!\x1b[0m\r\n"))
			}

			if err := database.PromoteUser(user); err != nil {
				return term.Write([]byte("\x1b[38;5;15mfailed to promote \""+args[0]+"\" in the database!\x1b[0m\r\n"))
			}

			return term.Write([]byte("\x1b[38;5;15m\""+args[0]+"\" has been promoted to admin!\x1b[0m\r\n"))
		},
	})

	// Demote command
	RegisterCommand(&Command{
		Name:        "demote",
		Prefix:      "",
		Admin:       true,
		Description: "demote a user from admin",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			if len(args) <= 0 {
				return term.Write([]byte("\x1b[38;5;15mdemote requires a user argument!\x1b[0m\r\n"))
			}

			// Tries to fetch the user from the database
			user, err := database.GetUser(args[0]); if err != nil {
				return term.Write([]byte("\x1b[38;5;15m\""+args[0]+"\" doesnt exist in the database!\x1b[0m\r\n"))
			}

			if err := database.DemoteUser(user); err != nil {
				return term.Write([]byte("\x1b[38;5;15mfailed to demote \""+args[0]+"\" in the database!\x1b[0m\r\n"))
			}

			return term.Write([]byte("\x1b[38;5;15m\""+args[0]+"\" has been demoted from admin!\x1b[0m\r\n"))
		},
	})

	// Lock command
	RegisterCommand(&Command{
		Name:        "lock",
		Prefix:      "",
		Admin:       true,
		Description: "puts the cnc in lockdown mode",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			Lockdown = true
			return term.Write([]byte("\x1b[38;5;15mLockdown mode has been enabled globally! Admin only mode\x1b[0m\r\n"))
		},
	})

	// Unlock command
	RegisterCommand(&Command{
		Name:        "unlock",
		Prefix:      "",
		Admin:       true,
		Description: "unlocks the cnc from lockdown",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			Lockdown = false
			return term.Write([]byte("\x1b[38;5;15mLockdown mode has been disabled globally! Any role mode\x1b[0m\r\n"))
		},
	})

	// Remove user command
	RegisterCommand(&Command{
		Name:        "remove",
		Prefix:      "",
		Admin:       true,
		Description: "removes a user from the database",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			if len(args) <= 0 {
				return term.Write([]byte("\x1b[38;5;15mremove requires a user argument!\x1b[0m\r\n"))
			}

			// Tries to fetch the user from the database
			user, err := database.GetUser(args[0]); if err != nil {
				return term.Write([]byte("\x1b[38;5;15m\""+args[0]+"\" doesnt exist in the database!\x1b[0m\r\n"))
			}

			if err := database.DeleteUser(user); err != nil {
				return term.Write([]byte("\x1b[38;5;15mfailed to remove \""+args[0]+"\" from database!\x1b[0m\r\n"))
			}

			return term.Write([]byte("\x1b[38;5;15m\""+args[0]+"\" has been removed from the database!\x1b[0m\r\n"))
		},
	})

	// Remove user command
	RegisterCommand(&Command{
		Name:        "create",
		Prefix:      "",
		Admin:       true,
		Description: "<username> <password> <maxtime>",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			if len(args) <= 2 {
				return term.Write([]byte("\x1b[38;5;15mcreate requires arguments! <username> <password> <maxtime>\x1b[0m\r\n"))
			}

			if usr, err := database.GetUser(args[0]); err == nil || usr != nil {
				return term.Write([]byte("\x1b[38;5;15m\""+args[0]+"\" already exists in database!\x1b[0m\r\n"))
			}

			maxtime, err := strconv.Atoi(args[2])
			if err != nil || maxtime <= 0 {
				return term.Write([]byte("\x1b[38;5;15mMaxtime must be an int!\x1b[0m\r\n"))
			}

			if err := database.CreateUser(&database.User{Username: args[0], Password: args[1], MaxTime: maxtime}); err != nil {
				return term.Write([]byte("\x1b[38;5;15mfailed to create \""+args[0]+"\" in database!\x1b[0m\r\n"))
			}

			return term.Write([]byte("\x1b[38;5;15m\""+args[0]+"\" has been created\x1b[0m\r\n"))
		},
	})

		// Remove user command
		RegisterCommand(&Command{
			Name:        "maxtime",
			Prefix:      "",
			Admin:       true,
			Description: "Modify a users maxtime",
			Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
				if len(args) <= 1 {
					return term.Write([]byte("\x1b[38;5;15mmaxtime requires arguments!\x1b[0m\r\n"))
				}
	
				usr, err := database.GetUser(args[0]); if err != nil || usr == nil {
					return term.Write([]byte("\x1b[38;5;15m\""+args[0]+"\" already exists in database!\x1b[0m\r\n"))
				}
	
				maxtime, err := strconv.Atoi(args[1])
				if err != nil || maxtime <= 0 {
					return term.Write([]byte("\x1b[38;5;15mMaxtime must be an int!\x1b[0m\r\n"))
				}
	
				if err := database.ModifyMaxtime(usr, maxtime); err != nil {
					return term.Write([]byte("\x1b[38;5;15mfailed to modify \""+args[0]+"\" maxtime in database!\x1b[0m\r\n"))
				}
	
				return term.Write([]byte("\x1b[38;5;15m\""+args[0]+"\" maxtime has been changed\x1b[0m\r\n"))
			},
		})
}