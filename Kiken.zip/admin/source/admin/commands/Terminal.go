package commands

import (
	"admin/source/terminal"

	"golang.org/x/crypto/ssh"
)

func init() {
	RegisterCommand(&Command{
		Name:        "cls",
		Prefix:      "",
		Admin:       false,
		Description: "clears your screen",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			return term.Write([]byte("\033c"))
		},
				
		ColoursControl: true,
	})

	RegisterCommand(&Command{
		Name:        "green",
		Prefix:      "",
		Admin:       false,
		Description: "Changes colour mode to green",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			term.Colour = "\x1b[38;5;10m"
			return term.Write([]byte("\x1b[38;5;15mColour has been changed to green\x1b[0m\r\n"))
		},
				
		ColoursControl: true,
	})

	RegisterCommand(&Command{
		Name:        "navy",
		Prefix:      "",
		Admin:       false,
		Description: "Changes colour mode to navy",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			term.Colour = "\x1b[38;5;105m"
			return term.Write([]byte("\x1b[38;5;15mColour has been changed to navy\x1b[0m\r\n"))
		},
				
		ColoursControl: true,
	})

	RegisterCommand(&Command{
		Name:        "darkblue",
		Prefix:      "",
		Admin:       false,
		Description: "Changes colour mode to darkblue",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			term.Colour = "\x1b[38;5;26m"
			return term.Write([]byte("\x1b[38;5;15mColour has been changed to darkblue\x1b[0m\r\n"))
		},
				
		ColoursControl: true,
	})

	RegisterCommand(&Command{
		Name:        "blue",
		Prefix:      "",
		Admin:       false,
		Description: "Changes colour mode to blue",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			term.Colour = "\x1b[38;5;4m"
			return term.Write([]byte("\x1b[38;5;15mColour has been changed to blue\x1b[0m\r\n"))
		},
				
		ColoursControl: true,
	})


	RegisterCommand(&Command{
		Name:        "white",
		Prefix:      "",
		Admin:       false,
		Description: "Changes colour mode to white",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			term.Colour = "\x1b[38;5;15m"
			return term.Write([]byte("\x1b[38;5;15mColour has been changed to white\x1b[0m\r\n"))
		},
				
		ColoursControl: true,
	})

	RegisterCommand(&Command{
		Name:        "pink",
		Prefix:      "",
		Admin:       false,
		Description: "Changes colour mode to pink",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			term.Colour = "\x1b[38;5;213m"
			return term.Write([]byte("\x1b[38;5;15mColour has been changed to pink\x1b[0m\r\n"))
		},
				
		ColoursControl: true,
	})

	RegisterCommand(&Command{
		Name:        "yellow",
		Prefix:      "",
		Admin:       false,	
		Description: "Changes colour mode to yellow",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			term.Colour = "\x1b[38;5;11m"
			return term.Write([]byte("\x1b[38;5;15mColour has been changed to yellow\x1b[0m\r\n"))
		},

		ColoursControl: true,
	})

	RegisterCommand(&Command{
		Name:        "grey",
		Prefix:      "",
		Admin:       false,
		Description: "Changes colour mode to grey",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			term.Colour = "\x1b[38;5;240m"
			return term.Write([]byte("\x1b[38;5;15mColour has been changed to grey\x1b[0m\r\n"))
		},

		ColoursControl: true,
	})
}