package commands

import (
	"admin/source/config"
	"admin/source/terminal"
	"fmt"

	"golang.org/x/crypto/ssh"
)

func init() {
	RegisterCommand(&Command{
		Name:        "credits",
		Prefix:      "",
		Admin:       false,
		Description: "Credits for this project",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			return term.Write([]byte(fmt.Sprintf("\x1b[0mбудущее CNC %s - FB & Cupid\r\n", config.Version)))
		},
	})
}