package commands

import (
	"admin/source/attacks"
	"admin/source/terminal"
	"fmt"
	"strings"

	"golang.org/x/crypto/ssh"
	"golang.org/x/exp/maps"
	"golang.org/x/exp/slices"
)

func init() {
	RegisterCommand(&Command{
		Name:        "help",
		Prefix:      "",
		Admin:       false,
		Description: "View all commands in the index",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {

			// Only show methods
			if strings.Contains(strings.Join(args, " "), "-m") {
				for _, method := range attacks.Methods { // Displays the current method
					if err := term.Write([]byte(fmt.Sprintf(""+term.Colour+"%s\x1b[38;5;15m: %s\r\n", method.Name, method.Description))); err != nil {
						return err
					}
				}
				return nil
			// Only show commands which they can access (NO METHODS)
			} else if strings.Contains(strings.Join(args, " "), "-c") {
				for name, control := range commands { // Ranges through commands checking then printing
					if control.Admin && !slices.Contains(maps.Keys(conn.Permissions.CriticalOptions), "admin") || control.ColoursControl {
						continue
					}
	
					// Writes information
					if err := term.Write([]byte(fmt.Sprintf(""+term.Colour+"%s%s\x1b[38;5;15m: %s\r\n", control.Prefix, name, control.Description))); err != nil {
						return err
					}
				}
				return nil
			} else if strings.Contains(strings.Join(args, " "), "-t") {
				for name, control := range commands { // Ranges through commands checking then printing
					if control.Admin && !slices.Contains(maps.Keys(conn.Permissions.CriticalOptions), "admin") || !control.ColoursControl {
						continue
					}
	
					// Writes information
					if err := term.Write([]byte(fmt.Sprintf(""+term.Colour+"%s%s\x1b[38;5;15m: %s\r\n", control.Prefix, name, control.Description))); err != nil {
						return err
					}
				}
				return nil
			}

			// NewLine
			if err := term.Write([]byte("\r\n")); err != nil {
				return err
			}

			// Ranges through all methods registered
			for _, method := range attacks.Methods {
				if err := term.Write([]byte(fmt.Sprintf(""+term.Colour+"%s\x1b[38;5;15m: %s\r\n", method.Name, method.Description))); err != nil {
					return err
				}
			}

			// NewLine
			if err := term.Write([]byte("\r\n")); err != nil {
				return err
			}

			// Ranges through all commands registered
			for name, control := range commands {
				if control.Admin && !slices.Contains(maps.Keys(conn.Permissions.CriticalOptions), "admin") || control.ColoursControl {
					continue
				}

				if err := term.Write([]byte(fmt.Sprintf(""+term.Colour+"%s%s\x1b[38;5;15m: %s\r\n", control.Prefix, name, control.Description))); err != nil {
					return err
				}
			}

			// NewLine
			return term.Write([]byte("\r\n"))
		},
	})
}