package commands

import (
	"admin/source/database"
	"admin/source/terminal"
	"strconv"
	"strings"

	"github.com/alexeyco/simpletable"
	"golang.org/x/crypto/ssh"
)

func init() {
	RegisterCommand(&Command{
		Name:        "users",
		Prefix:      "",
		Admin:       true,
		Description: "View users in databases",
		Execute: func(conn *ssh.ServerConn, term *terminal.Terminal, args []string) error {
			table := simpletable.New()

			term.Write([]byte(term.Colour))

			table.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[38;5;15m#"+term.Colour},
					{Align: simpletable.AlignCenter, Text: "\x1b[38;5;15mUsername"+term.Colour},
					{Align: simpletable.AlignCenter, Text: "\x1b[38;5;15mAdmin"+term.Colour},
					{Align: simpletable.AlignCenter, Text: "\x1b[38;5;15mMaxtime"+term.Colour},
				},
			}

			users, err := database.GetUsers()
			if err != nil {
				return err
			}

			for _, information := range users {
				r := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[38;5;15m"+strconv.Itoa(information.ID)+term.Colour},
					{Align: simpletable.AlignCenter, Text: "\x1b[38;5;15m"+information.Username+term.Colour},
					{Align: simpletable.AlignCenter, Text: "\x1b[38;5;15m"+parse(information.Admin>=1)+term.Colour},
					{Align: simpletable.AlignCenter, Text: "\x1b[38;5;15m"+strconv.Itoa(information.MaxTime)+term.Colour},
				}
		
				table.Body.Cells = append(table.Body.Cells, r)
			}


			table.SetStyle(simpletable.StyleUnicode)
			return term.Write([]byte(strings.ReplaceAll(table.String(), "\n", "\r\n")+"\r\n\x1b[0m"))
		},
	})
}

func parse(str bool) string {
	if str {
		return "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m"
	}
	return "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m"
}