package admin

import (
	"admin/source/config"
	"fmt"
	"log"
	"net"

	"golang.org/x/crypto/ssh"
)

// NewListener creates a new listener
func NewListener(configs ssh.ServerConfig) error {
	listener, err := net.Listen("tcp", config.Options.GetString("master", "master.listener"))
	if err != nil {
		return err
	}

	fmt.Printf("[MASTER] Listener started (%s)\r\n", config.Options.GetString("master", "master.listener"))

	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Printf("Err handshake from %s: %v\r\n", conn.RemoteAddr().String(), err); continue
		}

		// New routine for the connection
		go NewHandleFunc(conn, configs)
	}
}