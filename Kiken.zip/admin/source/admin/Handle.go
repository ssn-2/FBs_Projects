package admin

import (
	"net"

	"golang.org/x/crypto/ssh"
)

func NewHandleFunc(connection net.Conn, server ssh.ServerConfig) error {
	conn, channels, _, err := ssh.NewServerConn(connection, &server)
	if err != nil {
		return err
	}

	// Ranges through all open channels
	for chans := range channels {
		if chans.ChannelType() != "session" { // Only accept `session`
			return chans.Reject(ssh.UnknownChannelType, "UnknownChannelType")
		}
	
		// Accepts the channel type
		channel, _, err := chans.Accept()
		if err != nil {
			return err
		}
	
		return NewAdminPage(channel, conn)
	}
	return nil
}