package admin

import (
	"admin/source/config"
	"admin/source/database"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"fmt"

	"golang.org/x/crypto/ssh"
)

func Master() error {
	settings := ssh.ServerConfig{
		PasswordCallback: func(conn ssh.ConnMetadata, password []byte) (*ssh.Permissions, error) {
			user, err := database.GetUser(conn.User())
			if err != nil {
				return nil, err
			}

			// Compares the password information
			if user.Password != string(password) {
				return nil, fmt.Errorf("Password does not match")
			}

			var perms map[string]string = make(map[string]string)
			if user.Admin >= 1 {
				perms["admin"] = "true"
			}

			// default colour set
			perms["colour"] = config.DefaultColour

			// Auth successful
			return &ssh.Permissions{CriticalOptions: perms}, nil
		},

		ServerVersion: "SSH-2.0-OpenSSH_8.6p1",
	}

	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return err
	}

	signer, err := ssh.NewSignerFromKey(key)
	if err != nil {
		return err
	}

	settings.AddHostKey(signer)
	return NewListener(settings)
}
