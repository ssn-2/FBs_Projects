package config

const (
	Version string = "v1.0"

	DefaultColour string = "\x1b[38;5;9m"
)