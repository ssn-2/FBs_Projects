package config

import "admin/source/config/options"

var (
	// Holds all the configuration options available
	Options options.Options = options.Options{Objects: make(map[string]any)}
)