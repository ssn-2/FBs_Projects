package options

import (
	"log"
	"reflect"
	"strings"
)

// Indexes object as an string
func (o *Options) GetString(path ...string) string {
	return o.index(reflect.String, path...).(string)
}

// Indexes object as an bool
func (o *Options) GetBool(path ...string) bool {
	return o.index(reflect.Bool, path...).(bool)
}

// Indexes object as an int
func (o *Options) GetInt(path ...string) int {
	return o.index(reflect.Int, path...).(int)
}

// Indexes object as an float64
func (o *Options) GetFloat64(path ...string) float64 {
	return o.index(reflect.Float64, path...).(float64)
}

// Indexes object as an Slices
func (o *Options) GetINTSlices(path ...string) []int {
	return o.index(reflect.Slice, path...).([]int)
}

// Indexes object as an Slices
func (o *Options) GetFloatSlices(path ...string) []float64 {
	return o.index(reflect.Slice, path...).([]float64)
}

// Indexes object as an Slices
func (o *Options) GetAnySlices(path ...string) []any {
	return o.index(reflect.Slice, path...).([]any)
}

// index will index the object given inside the objects map
func (o *Options) index(t reflect.Kind, p ...string) any {
	var current map[string]any = make(map[string]any)
	current = o.Objects

	// Ranges through the path
	for _, object := range p {

		switch reflect.ValueOf(current[object]).Kind() {

		case t:
			return current[object]
		case reflect.Map: // Multiple objects
			current = current[object].(map[string]any)
		default:
			log.Fatalf("Unknown type for index: [%s] when looking for [%s] with (%s)", reflect.ValueOf(current[object]).Kind().String(), t.String(), strings.Join(p, "."))
		}
	}


	return nil
}