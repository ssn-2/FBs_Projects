package options

import (
	"io/ioutil"
	"path/filepath"
)

type Options struct {
	Objects 		map[string]any 		`json:"objects"`
}

// OptionsFromFile will read the entire directory
func OptionsFromFile(src *Options, path ...string) (*Options, error) {
	joined := filepath.Join(path...)

	// Opens the directory for config reading
	directory, err := ioutil.ReadDir(joined)
	if err != nil {
		return nil, err
	}

	// Ranges through the directory
	for _, file := range directory {
		PathToFile := filepath.Join(joined, file.Name())
		switch filepath.Ext(file.Name()) {

		case ".json": // Json parsing file
			if err := src.json(PathToFile); err != nil {
				return nil, err
			}

		case ".toml": // Toml parsing file
			if err := src.toml(PathToFile); err != nil {
				return nil, err
			}
		}
	}

	return src, nil
}