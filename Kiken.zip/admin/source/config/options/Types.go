package options

import (
	"encoding/json"
	"os"

	"github.com/naoina/toml"
	"golang.org/x/exp/maps"
)

func (o *Options) json(path string) error {
	var temp map[string]any = make(map[string]any)
	bytes, err := os.Open(path)
	if err != nil {
		return err
	}

	// Decodes the JSON into the map
	if err := json.NewDecoder(bytes).Decode(&temp); err != nil {
		return err
	}

	// Merges the maps into one
	maps.Copy(o.Objects, temp)
	return nil
}

func (o *Options) toml(path string) error {
	var temp map[string]any = make(map[string]any)
	bytes, err := os.Open(path)
	if err != nil {
		return err
	}

	// Decodes the JSON into the map
	if err := toml.NewDecoder(bytes).Decode(&temp); err != nil {
		return err
	}

	// Merges the maps into one
	maps.Copy(o.Objects, temp)
	return nil
}