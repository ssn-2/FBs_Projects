package terminal



//Clears the current terminal
func (T *Terminal) Clear() {
	T.channel.Write([]byte("\033c"))
}


//Write shall write the bytes to the channel
func (T *Terminal) Write(b []byte) error {
	if _, err := T.channel.Write(b); err != nil {
		return err
	}

	return nil
}