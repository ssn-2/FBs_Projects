package terminal

import (
	"fmt"
	"strings"
)

// ReadLine will read any ASCII characters from the channel and format into a string
func (T *Terminal) ReadLine(prompt string, length int, masking bool, maskCharater string) (string, error) {
	if err := T.Write([]byte("\x1b[s" + prompt)); err != nil {
		return "", err
	}

	var (
		// Holds the current readin bytes ASCII
		collection []byte = make([]byte, 0)
		PositionInLine int 		= 0					 	// Index of the position in line
		Horizontal     int 		= len(T.taken)  	// Index of the history
		Cache          string							// Temp cache for text
	)

	for {
		buf := make([]byte, 1)
		if _, err := T.channel.Read(buf); err != nil {
			return "", err
		}

		switch buf[0] {
		case 16, 3, 2, 1, 11, 12, 5, 8, 31:
			continue

		case 127: // Backspace
			if len(collection) == 0 {
				continue
			}

			if PositionInLine > 0 {
				collection = append(collection[:len(collection)-PositionInLine-1], collection[len(collection)-PositionInLine-1+1:]...)
				
				if masking { // If masking we write masked charater
					if _, err := T.channel.Write([]byte(fmt.Sprintf("\x1b[u\x1b[K%s%s\033[%dD", prompt, strings.Repeat(maskCharater, len(string(collection))), len(collection)-PositionInLine-1))); err != nil {return "", err}
				} else { // Writes the character without masking
					if _, err := T.channel.Write([]byte(fmt.Sprintf("\x1b[u\x1b[K%s%s\033[%dD", prompt, string(collection), len(collection)-PositionInLine-1))); err != nil {return "", err}
				}
				continue
			}

			collection = collection[:len(collection)-1]
			if _, err := T.channel.Write([]byte{127}); err != nil {
				return "", err
			}

		case 13: // Enter key
			if err := T.Write([]byte("\r\n")); err != nil {
				return "", err
			}

			// Checks if masking is disabled, if so save into the save array
			if !masking {T.taken = append(T.taken, string(collection))}
			return string(collection), nil

		case 27: // Unsafe sequences
			inlined := make([]byte, 5)
			if _, err := T.channel.Read(inlined); err != nil {
				return "", err
			}

			switch inlined[1] {
			case 65: // Up arrow
				if Horizontal <= 0 {
					continue
				} else if Horizontal == len(T.taken) {
					Cache = string(collection)
				}

				Horizontal--
				collection = []byte(T.taken[Horizontal])
				if _, err := T.channel.Write([]byte(fmt.Sprintf("\x1b[u\x1b[K%s%s", prompt, T.taken[Horizontal]))); err != nil {
					return "", err
				}
			case 66: // Down arrow
				if Horizontal + 1 > len(T.taken) {
					continue
				} else if Horizontal + 1 == len(T.taken) {
					collection = []byte(Cache)
					if _, err := T.channel.Write([]byte(fmt.Sprintf("\x1b[u\x1b[K%s%s", prompt, string(collection)))); err != nil {
						return "", err
					}

					continue
				}

				Horizontal++
				collection = []byte(T.taken[Horizontal])
				if _, err := T.channel.Write([]byte(fmt.Sprintf("\x1b[u\x1b[K%s%s", prompt, T.taken[Horizontal]))); err != nil {
					return "", err
				}
			case 67: // Right arrow
				if len(collection) == 0 || PositionInLine == 0 {
					continue
				}

				PositionInLine--
				T.channel.Write([]byte{27,91,67})
 			case 68: // Left arrow
				if len(collection) == 0 || PositionInLine >= len(collection){
					continue
				}


				PositionInLine++
				T.channel.Write([]byte{27,91,68})
			}

		default: // Safe ASCII charater
			if len(collection) + 1 > length {
				continue
			}

			// Checks for the position of the cursor
			if PositionInLine > 0 {
				after := strings.Split(string(collection), "")[len(collection)-PositionInLine:]
				before := strings.Split(string(collection), "")[:len(collection)-PositionInLine]
				collection = append([]byte(strings.Join(before, "")), []byte(string(buf[0])+strings.Join(after, ""))...)

				if masking { // If masking we write masked charater
					if _, err := T.channel.Write([]byte(fmt.Sprintf("\x1b[u\x1b[K%s%s\033[%dD", prompt, strings.Repeat(maskCharater, len(string(collection))), len(collection)-len(before)-1))); err != nil {return "", err}
				} else { // Writes the character without masking
					if _, err := T.channel.Write([]byte(fmt.Sprintf("\x1b[u\x1b[K%s%s\033[%dD", prompt, string(collection), len(collection)-len(before)-1))); err != nil {return "", err}
				}
				continue
			}

			// Saves into the collection
			collection = append(collection, buf[0])

			if masking { // If masking we write masked charater
				if _, err := T.channel.Write([]byte(maskCharater)); err != nil {return "", err}
			} else { // Writes the character without masking
				if _, err := T.channel.Write([]byte(string(buf[0]))); err != nil {return "", err}
			}
		}
	}
}

func RemoveIndex(s []byte, index int) []byte {
    return append(s[:index], s[index+1:]...)
}