package terminal

import (
	"admin/source/config"

	"golang.org/x/crypto/ssh"
)

type Terminal struct {
	channel ssh.Channel
	conn    *ssh.ServerConn

	taken  []string
	Colour string
}

//NewTerminal creates a new Terminal structure
func NewTerminal(channel ssh.Channel, conn *ssh.ServerConn) *Terminal {
	return &Terminal{
		channel: channel,
		conn:    conn,
		taken:   make([]string, 0),
		Colour:  config.DefaultColour,
	}
}
